import 'package:minibites/main.dart';
import 'package:minibites/views/screens/on_boarding_page/on_boarding_page_widget.dart';
import 'package:minibites/views/screens/seller_welcome_screen.dart';
import 'package:get/get.dart';
import 'package:minibites/routes/routes_name.dart';
import 'package:minibites/views/screens/splash_screen.dart';
import 'package:minibites/views/screens/seller_welcome_screen.dart';

class AppRoutes {
  static appRoutes() =>
      [
        GetPage(
          name: RoutesName.splashScreen,
          page: () => SplashScreen(),
          transitionDuration: Duration(milliseconds: 250),
          transition: Transition.rightToLeftWithFade,
        ),

        GetPage(
          name: RoutesName.welcomeScreen,
          page: () => SellerWelcomeScreen(),
          transitionDuration: Duration(milliseconds: 250),
          transition: Transition.rightToLeftWithFade,
        ),

      ];
}

