
class RoutesName {

  static const String splashScreen = '/' ;

  static const String welcomeScreen = '/WelcomeScreen';
}