import 'package:cloud_firestore/cloud_firestore.dart';

class Review {
  final String reviewText;
  final double rating;
  final Timestamp createdAt;

  Review({
    required this.reviewText,
    required this.rating,
    required this.createdAt,
  });

  // Factory method to create a Review instance from Firestore document
  factory Review.fromDocument(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;

    return Review(
      reviewText: data['reviewText'] ?? '',
      rating: data['rating']?.toDouble() ?? 0.0,
      createdAt: data['createdAt'] as Timestamp,
    );
  }

  // Convert Review instance to a Map for Firestore storage (if needed)
  Map<String, dynamic> toMap() {
    return {
      'reviewText': reviewText,
      'rating': rating,
      'createdAt': createdAt,
    };
  }
}
