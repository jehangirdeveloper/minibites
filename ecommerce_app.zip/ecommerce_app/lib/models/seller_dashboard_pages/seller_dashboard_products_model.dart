class Product {
  String name;
  String price;
  String imageUrl;
  String? originalPrice;
  bool isAvailable;

  Product({
    required this.name,
    required this.price,
    required this.imageUrl,
    this.originalPrice,
    required this.isAvailable,
  });
}
