class LanguageModel {
  final String code;
  final String name;

  LanguageModel(this.code, this.name);
}
