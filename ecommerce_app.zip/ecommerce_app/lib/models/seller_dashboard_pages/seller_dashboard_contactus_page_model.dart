class ContactFormModel {
  String name;
  String email;
  String message;

  ContactFormModel({
    required this.name,
    required this.email,
    required this.message,
  });
}
