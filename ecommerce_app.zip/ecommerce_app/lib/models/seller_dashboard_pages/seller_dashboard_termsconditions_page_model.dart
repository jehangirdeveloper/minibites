// lib/models/terms_conditions_model.dart
import 'package:get/get.dart';

class SellerDashboardTermsconditionsPageModel extends GetxController {
  var isAccepted = false.obs;

  void toggleAccept() {
    isAccepted.value = !isAccepted.value;
  }

  void acceptTerms() {
    if (isAccepted.value) {
      // Perform action on acceptance
      Get.snackbar('Accepted', 'Terms & Conditions accepted');
    }
  }
}
