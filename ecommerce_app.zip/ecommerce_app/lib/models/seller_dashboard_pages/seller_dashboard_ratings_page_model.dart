class Rating {
  final String customer;
  final int rating;
  final String comment;

  Rating({required this.customer, required this.rating, required this.comment});
}
