// lib/models/seller_dashboard_pages/add_on_add_your_menu_page_model.dart

class AddOn {
  String title; // Make sure this is not null
  double price;
  double calories;
  String shortDescription; // Make sure this is not null

  AddOn({
    required this.title,
    required this.price,
    required this.calories,
    required this.shortDescription,
  });
}
