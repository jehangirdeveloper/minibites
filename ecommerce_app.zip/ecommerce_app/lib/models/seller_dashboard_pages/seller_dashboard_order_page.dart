import 'package:get/get.dart';

class Order {
  final RxInt orderNo;
  final RxString status;
  final RxString customerName;
  final RxString customerPhone;
  final RxDouble payable;
  final RxString paymentMethod;
  final Rx<DateTime> orderDate;

  Order({
    required int orderNo,
    required String status,
    required String customerName,
    required String customerPhone,
    required double payable,
    required String paymentMethod,
    required DateTime orderDate,
  })  : orderNo = orderNo.obs,
        status = status.obs,
        customerName = customerName.obs,
        customerPhone = customerPhone.obs,
        payable = payable.obs,
        paymentMethod = paymentMethod.obs,
        orderDate = orderDate.obs;
}
