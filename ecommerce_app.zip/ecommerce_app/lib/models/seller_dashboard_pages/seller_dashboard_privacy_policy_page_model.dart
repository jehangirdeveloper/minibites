class PrivacyPolicyModel {
  final String content;

  PrivacyPolicyModel(this.content);
}
