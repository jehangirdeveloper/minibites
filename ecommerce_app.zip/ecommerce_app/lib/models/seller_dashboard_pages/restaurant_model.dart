import 'package:cloud_firestore/cloud_firestore.dart';

class RestaurantModel {
  String name;
  String category;
  String image; // Image field
  final String sellerId;

  RestaurantModel({
    required this.name,
    required this.category,
    required this.image,  // Image field initialized
    required this.sellerId,  // Seller ID initialized
  });

  // Firestore se document ko Restaurant object me convert karna
  factory RestaurantModel.fromDocument(DocumentSnapshot doc) {
    return RestaurantModel(
      name: doc['name'],
      category: doc['category'],
      image: doc['image'],  // Image field ko initialize kiya
      sellerId: doc['sellerId'],  // Seller ID ko initialize kiya
    );
  }

  // Restaurant object ko Map me convert karna for Firestore
  Map<String, dynamic> toMap() {
    return {
      'name': name,
      'category': category,
      'image': image,
      'sellerId': sellerId,
    };
  }
}
