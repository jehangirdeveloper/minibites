class Wallet {
  final double currentBalance;
  final double amount;
  final String date;
  final int id;
  final String paymentAddress;
  final String paymentType;
  final String status;

  Wallet({
    required this.currentBalance,
    required this.amount,
    required this.date,
    required this.id,
    required this.paymentAddress,
    required this.paymentType,
    required this.status,
  });
}
