class Tag {
  String name;

  Tag(this.name);
}
