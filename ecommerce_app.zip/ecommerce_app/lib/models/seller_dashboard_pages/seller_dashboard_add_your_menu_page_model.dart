// seller_dashboard_add_your_menu_page_model.dart
import 'package:minibites/models/seller_dashboard_pages/add_on_add_your_menu_page_model.dart';

class Product {
  String name;
  String shortDescription;
  String highlights;
  String? selectedTax;
  String? selectedIndicator;
  int? totalAllowedQuantity;
  int? minimumOrderQuantity;
  int? calories;
  String selectedCategory;
  bool isCodAllowed;
  bool isTaxIncluded;
  String typeOfProduct; // New field for Type of Product
  List<AddOn> addOns;

  Product({
    required this.name,
    required this.shortDescription,
    required this.highlights,
    this.selectedTax,
    this.selectedIndicator,
    this.totalAllowedQuantity,
    this.minimumOrderQuantity,
    this.calories,
    required this.selectedCategory,
    this.isCodAllowed = false,
    this.isTaxIncluded = false,
    this.typeOfProduct = '',  // Initialize the new field with an empty string or default value
    this.addOns = const [],
  });
}
