class Transaction {
  final String amount;
  final String date;
  final String orderId;
  final String paymentMethod;
  final String message;

  Transaction({
    required this.amount,
    required this.date,
    required this.orderId,
    required this.paymentMethod,
    required this.message,
  });
}
