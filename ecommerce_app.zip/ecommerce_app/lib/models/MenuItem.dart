import 'package:flutter/material.dart';
import 'package:minibites/models/buyer_dashboard_pages_models/checkout_page_screen_model.dart';

class MenuItem {
  final String id;
  final String name;
  final String imageUrl;
  final double price;
  final double dealPrice;
  int quantity;
  final String category;

  MenuItem({
    required this.id,
    required this.name,
    required this.imageUrl,
    required this.price,
    required this.dealPrice,
    this.quantity = 1,
    required this.category,
  });

  // Factory method to create a MenuItem from a map (useful for Firestore)
  factory MenuItem.fromMap(Map<String, dynamic> map) {
    return MenuItem(
      id: map['id'] ?? '',
      name: map['name'] ?? '',
      imageUrl: map['imageUrl'] ?? '',
      price: map['price']?.toDouble() ?? 0.0,
      dealPrice: map['dealPrice']?.toDouble() ?? 0.0,
      quantity: map['quantity'] ?? 1,
      category: map['category'] ?? '',
    );
  }

  // Convert MenuItem to a map (useful for Firestore)
  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'imageUrl': imageUrl,
      'price': price,
      'dealPrice': dealPrice,
      'quantity': quantity,
      'category': category,
    };
  }

  // Method to create a copy of the MenuItem with updated values
  MenuItem copyWith({
    String? id,
    String? name,
    String? imageUrl,
    double? price,
    double? dealPrice,
    int? quantity,
    String? category,
  }) {
    return MenuItem(
      id: id ?? this.id,
      name: name ?? this.name,
      imageUrl: imageUrl ?? this.imageUrl,
      price: price ?? this.price,
      dealPrice: dealPrice ?? this.dealPrice,
      quantity: quantity ?? this.quantity,
      category: category ?? this.category,
    );
  }

  // Method to convert MenuItem to CheckoutPageScreenModel
  CheckoutPageScreenModel toCheckoutPageScreenModel() {
    return CheckoutPageScreenModel(
      name: name,
      price: price,
      image: imageUrl, // Use imageUrl as a String if CheckoutPageScreenModel expects a URL
      quantity: quantity,
    );
  }
}
