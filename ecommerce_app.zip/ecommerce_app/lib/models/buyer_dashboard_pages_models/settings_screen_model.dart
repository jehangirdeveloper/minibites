// settings_model.dart
import 'package:get/get.dart';

class SettingsScreenModel extends RxController {
  var name = ''.obs;
  var email = ''.obs;
  var address = ''.obs;
  var mobileNumber = ''.obs;
}
