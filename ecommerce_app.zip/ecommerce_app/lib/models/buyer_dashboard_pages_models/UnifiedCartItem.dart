// import 'package:flutter/material.dart';
// import 'package:get/get.dart';
// import 'package:minibites/models/buyer_dashboard_pages_models/Crafted%20Cuisine_all_type_foods_menu_models/pulao_menu_model.dart' as pulao;
// import 'package:minibites/models/buyer_dashboard_pages_models/Crafted%20Cuisine_all_type_foods_menu_models/biryani_page_menu_model.dart' as biryani;
// import 'package:minibites/models/buyer_dashboard_pages_models/Crafted%20Cuisine_all_type_foods_menu_models/fast_food_menu_model.dart' as fastFood;
// import 'package:minibites/models/buyer_dashboard_pages_models/Crafted%20Cuisine_all_type_foods_menu_models/pizza_page_menu_model.dart' as pizza;
// import 'package:minibites/models/buyer_dashboard_pages_models/Crafted%20Cuisine_all_type_foods_menu_models/pasta_page_menu_model.dart' as pasta;
// import 'package:minibites/models/buyer_dashboard_pages_models/Crafted%20Cuisine_all_type_foods_menu_models/paratha_page_menu_model.dart' as paratha;
// import 'package:minibites/models/buyer_dashboard_pages_models/Crafted%20Cuisine_all_type_foods_menu_models/bbq_page_menu_model.dart' as bbq;
// import 'package:minibites/models/buyer_dashboard_pages_models/Crafted%20Cuisine_all_type_foods_menu_models/burgers_page_menu_model.dart' as burgers;
// import 'package:minibites/models/buyer_dashboard_pages_models/Crafted%20Cuisine_all_type_foods_menu_models/shawarma_page_menu_model.dart' as shawarma;
// import 'package:minibites/models/buyer_dashboard_pages_models/Crafted%20Cuisine_all_type_foods_menu_models/pakistani_page_menu_model.dart' as pakistani;
// import 'package:minibites/models/buyer_dashboard_pages_models/Crafted%20Cuisine_all_type_foods_menu_models/icecream_page_menu_model.dart' as icecream;
// import 'package:minibites/models/buyer_dashboard_pages_models/Crafted%20Cuisine_all_type_foods_menu_models/chinese_page_menu_model.dart' as chinese;
// import 'package:minibites/models/buyer_dashboard_pages_models/Crafted%20Cuisine_all_type_foods_menu_models/samosa_page_menu_model.dart' as samosa;
// import 'package:minibites/models/buyer_dashboard_pages_models/Crafted%20Cuisine_all_type_foods_menu_models/desserts_page_menu_model.dart' as desserts;
// import 'package:minibites/models/buyer_dashboard_pages_models/Crafted%20Cuisine_all_type_foods_menu_models/fish_page_menu_model.dart' as fish;
// import 'package:minibites/models/buyer_dashboard_pages_models/Crafted%20Cuisine_all_type_foods_menu_models/sweetdish_page_menu_model.dart' as sweetdish;
// import 'package:minibites/models/buyer_dashboard_pages_models/checkout_page_screen_model.dart';
//
// class UnifiedCartItem {
//   final String name;
//   final double price;
//   final AssetImage image;
//   RxInt quantity;  // RxInt banaya gaya hai
//   final String restaurantName;
//
//   UnifiedCartItem({
//     required this.name,
//     required this.price,
//     required this.image,
//     int quantity = 1,  // int ki default value
//     required this.restaurantName,
//   }) : quantity = quantity.obs;  // Initialize as RxInt
//
//   // PizzaPageMenuModel se convert karne ka method
//   static UnifiedCartItem fromPizzaPageMenuModel(pizza.MenuItem item, String restaurantName) {
//     return UnifiedCartItem(
//       name: item.name,
//       price: item.price,
//       image: item.image,
//       quantity: item.quantity,  // RxInt initialize nahi karna, quantity already int hai
//       restaurantName: restaurantName,
//     );
//   }
//
//   // FastFoodMenuModel se convert karne ka method
//   static UnifiedCartItem fromFastFoodMenuModel(fastFood.MenuItem item, String restaurantName) {
//     return UnifiedCartItem(
//       name: item.name,
//       price: item.price,
//       image: item.image,
//       quantity: item.quantity,  // RxInt initialize nahi karna, quantity already int hai
//       restaurantName: restaurantName,
//     );
//   }
//
//   // PulaoMenuModel se convert karne ka method
//   static UnifiedCartItem fromPulaoMenuModel(pulao.MenuItem item, String restaurantName) {
//     return UnifiedCartItem(
//       name: item.name,
//       price: item.price,
//       image: item.image,
//       quantity: item.quantity,  // RxInt initialize nahi karna, quantity already int hai
//       restaurantName: restaurantName,
//     );
//   }
//
//   // BiryaniMenuModel se convert karne ka method
//   static UnifiedCartItem fromBiryaniPageMenuModel(biryani.MenuItem item, String restaurantName) {
//     return UnifiedCartItem(
//       name: item.name,
//       price: item.price,
//       image: item.image,
//       quantity: item.quantity,  // RxInt initialize nahi karna, quantity already int hai
//       restaurantName: restaurantName,
//     );
//   }
//
//   // PastaMenuModel se convert karne ka method
//   static UnifiedCartItem fromPastaPageMenuModel(pasta.MenuItem item, String restaurantName) {
//     return UnifiedCartItem(
//       name: item.name,
//       price: item.price,
//       image: item.image,
//       quantity: item.quantity,  // RxInt initialize nahi karna, quantity already int hai
//       restaurantName: restaurantName,
//     );
//   }
//
//   // ParathaMenuModel se convert karne ka method
//   static UnifiedCartItem fromParathaPageMenuModel(paratha.MenuItem item, String restaurantName) {
//     return UnifiedCartItem(
//       name: item.name,
//       price: item.price,
//       image: item.image,
//       quantity: item.quantity,  // RxInt initialize nahi karna, quantity already int hai
//       restaurantName: restaurantName,
//     );
//   }
//
//   // BBQMenuModel se convert karne ka method
//   static UnifiedCartItem fromBbqPageMenuModel(bbq.MenuItem item, String restaurantName) {
//     return UnifiedCartItem(
//       name: item.name,
//       price: item.price,
//       image: item.image,
//       quantity: item.quantity,  // RxInt initialize nahi karna, quantity already int hai
//       restaurantName: restaurantName,
//     );
//   }
//
//   // BurgersMenuModel se convert karne ka method
//   static UnifiedCartItem fromBurgersPageMenuModel(burgers.MenuItem item, String restaurantName) {
//     return UnifiedCartItem(
//       name: item.name,
//       price: item.price,
//       image: item.image,
//       quantity: item.quantity,  // RxInt initialize nahi karna, quantity already int hai
//       restaurantName: restaurantName,
//     );
//   }
//
//   // ShawarmaMenuModel se convert karne ka method
//   static UnifiedCartItem fromShawarmaPageMenuModel(shawarma.MenuItem item, String restaurantName) {
//     return UnifiedCartItem(
//       name: item.name,
//       price: item.price,
//       image: item.image,
//       quantity: item.quantity,  // RxInt initialize nahi karna, quantity already int hai
//       restaurantName: restaurantName,
//     );
//   }
//
//   // PakistaniMenuModel se convert karne ka method
//   static UnifiedCartItem fromPakistaniPageMenuModel(pakistani.MenuItem item, String restaurantName) {
//     return UnifiedCartItem(
//       name: item.name,
//       price: item.price,
//       image: item.image,
//       quantity: item.quantity,  // RxInt initialize nahi karna, quantity already int hai
//       restaurantName: restaurantName,
//     );
//   }
//
//   // IcecreamMenuModel se convert karne ka method
//   static UnifiedCartItem fromIcecreamPageMenuModel(icecream.MenuItem item, String restaurantName) {
//     return UnifiedCartItem(
//       name: item.name,
//       price: item.price,
//       image: item.image,
//       quantity: item.quantity,  // RxInt initialize nahi karna, quantity already int hai
//       restaurantName: restaurantName,
//     );
//   }
//
//   // ChineseMenuModel se convert karne ka method
//   static UnifiedCartItem fromChinesePageMenuModel(chinese.MenuItem item, String restaurantName) {
//     return UnifiedCartItem(
//       name: item.name,
//       price: item.price,
//       image: item.image,
//       quantity: item.quantity,  // RxInt initialize nahi karna, quantity already int hai
//       restaurantName: restaurantName,
//     );
//   }
//
//   // SamosaMenuModel se convert karne ka method
//   static UnifiedCartItem fromSamosaPageMenuModel(samosa.MenuItem item, String restaurantName) {
//     return UnifiedCartItem(
//       name: item.name,
//       price: item.price,
//       image: item.image,
//       quantity: item.quantity,  // RxInt initialize nahi karna, quantity already int hai
//       restaurantName: restaurantName,
//     );
//   }
//
//   // DessertsMenuModel se convert karne ka method
//   static UnifiedCartItem fromDessertsPageMenuModel(desserts.MenuItem item, String restaurantName) {
//     return UnifiedCartItem(
//       name: item.name,
//       price: item.price,
//       image: item.image,
//       quantity: item.quantity,  // RxInt initialize nahi karna, quantity already int hai
//       restaurantName: restaurantName,
//     );
//   }
//
//   // FishMenuModel se convert karne ka method
//   static UnifiedCartItem fromFishPageMenuModel(fish.MenuItem item, String restaurantName) {
//     return UnifiedCartItem(
//       name: item.name,
//       price: item.price,
//       image: item.image,
//       quantity: item.quantity,  // RxInt initialize nahi karna, quantity already int hai
//       restaurantName: restaurantName,
//     );
//   }
//
//   // SweetdishMenuModel se convert karne ka method
//   static UnifiedCartItem fromSweetdishPageMenuModel(sweetdish.MenuItem item, String restaurantName) {
//     return UnifiedCartItem(
//       name: item.name,
//       price: item.price,
//       image: item.image,
//       quantity: item.quantity,  // RxInt initialize nahi karna, quantity already int hai
//       restaurantName: restaurantName,
//     );
//   }
//
//   // CheckoutPageScreenModel mein convert karne ka method
//   CheckoutPageScreenModel toCheckoutPageScreenModel() {
//     return CheckoutPageScreenModel(
//       name: name,
//       quantity: quantity.value,  // RxInt se value access karna
//       price: price,
//       image: image,
//     );
//   }
//
//   // PizzaPageMenuItem mein convert karna
//   // pizza.MenuItem toPizzaMenuItem() {
//   //   return pizza.MenuItem(
//   //     name: this.name,
//   //     price: this.price,
//   //     image: this.image,
//   //     quantity: this.quantity.value,  // RxInt se value access karna
//   //   );
//   // }
//
//   // FastFoodMenuItem mein convert karna
//   fastFood.MenuItem toFastFoodMenuItem() {
//     return fastFood.MenuItem(
//       name: this.name,
//       price: this.price,
//       image: this.image,
//       quantity: this.quantity.value,  // RxInt se value access karna
//     );
//   }
//   // PulaoMenuItem mein convert karna
//   pulao.MenuItem toPulaoMenuItem() {
//     return pulao.MenuItem(
//       name: this.name,
//       price: this.price,
//       image: this.image,
//       quantity: this.quantity.value,  // RxInt se value access karna
//     );
//   }
//   // BiryaniMenuItem mein convert karna
//   biryani.MenuItem toBiryaniMenuItem() {
//     return biryani.MenuItem(
//       name: this.name,
//       price: this.price,
//       image: this.image,
//       quantity: this.quantity.value,  // RxInt se value access karna
//     );
//   }
//   // PastaMenuItem mein convert karna
//   pasta.MenuItem toPastaMenuItem() {
//     return pasta.MenuItem(
//       name: this.name,
//       price: this.price,
//       image: this.image,
//       quantity: this.quantity.value,  // RxInt se value access karna
//     );
//   }
//   // ParathaMenuItem mein convert karna
//   paratha.MenuItem toParathaMenuItem() {
//     return paratha.MenuItem(
//       name: this.name,
//       price: this.price,
//       image: this.image,
//       quantity: this.quantity.value,  // RxInt se value access karna
//     );
//   }
//   // ParathaMenuItem mein convert karna
//   bbq.MenuItem toBbqMenuItem() {
//     return bbq.MenuItem(
//       name: this.name,
//       price: this.price,
//       image: this.image,
//       quantity: this.quantity.value,  // RxInt se value access karna
//     );
//   }
//   // BurgersMenuItem mein convert karna
//   burgers.MenuItem toBurgersMenuItem() {
//     return burgers.MenuItem(
//       name: this.name,
//       price: this.price,
//       image: this.image,
//       quantity: this.quantity.value,  // RxInt se value access karna
//     );
//   }
//   // ShawarmaMenuItem mein convert karna
//   shawarma.MenuItem toShawarmaMenuItem() {
//     return shawarma.MenuItem(
//       name: this.name,
//       price: this.price,
//       image: this.image,
//       quantity: this.quantity.value,  // RxInt se value access karna
//     );
//   }
//   // PakistaniMenuItem mein convert karna
//   pakistani.MenuItem toPakistaniMenuItem() {
//     return pakistani.MenuItem(
//       name: this.name,
//       price: this.price,
//       image: this.image,
//       quantity: this.quantity.value,  // RxInt se value access karna
//     );
//   }
//   // IcecreamMenuItem mein convert karna
//   icecream.MenuItem toIcecreamMenuItem() {
//     return icecream.MenuItem(
//       name: this.name,
//       price: this.price,
//       image: this.image,
//       quantity: this.quantity.value,  // RxInt se value access karna
//     );
//   }
//   // ChineseMenuItem mein convert karna
//   chinese.MenuItem toChineseMenuItem() {
//     return chinese.MenuItem(
//       name: this.name,
//       price: this.price,
//       image: this.image,
//       quantity: this.quantity.value,  // RxInt se value access karna
//     );
//   }
//   // SamosaMenuItem mein convert karna
//   samosa.MenuItem toSamosaMenuItem() {
//     return samosa.MenuItem(
//       name: this.name,
//       price: this.price,
//       image: this.image,
//       quantity: this.quantity.value,  // RxInt se value access karna
//     );
//   }
//   // DessertsMenuItem mein convert karna
//   desserts.MenuItem toDessertsMenuItem() {
//     return desserts.MenuItem(
//       name: this.name,
//       price: this.price,
//       image: this.image,
//       quantity: this.quantity.value,  // RxInt se value access karna
//     );
//   }
//   // FishMenuItem mein convert karna
//   fish.MenuItem toFishMenuItem() {
//     return fish.MenuItem(
//       name: this.name,
//       price: this.price,
//       image: this.image,
//       quantity: this.quantity.value,  // RxInt se value access karna
//     );
//   }
//   // SweetdishMenuItem mein convert karna
//   sweetdish.MenuItem toSweetdishMenuItem() {
//     return sweetdish.MenuItem(
//       name: this.name,
//       price: this.price,
//       image: this.image,
//       quantity: this.quantity.value,  // RxInt se value access karna
//     );
//   }
// }
//
//
//
