// lib/models/cart_item.dart
import 'package:flutter/material.dart';
import 'package:minibites/models/buyer_dashboard_pages_models/checkout_page_screen_model.dart';

class CartItem {
  final Item item;
  int quantity;

  CartItem({
    required this.item,
    this.quantity = 1,
  });

  // Method to convert CartItem to CheckoutPageScreenModel
  CheckoutPageScreenModel toCheckoutPageScreenModel() {
    return CheckoutPageScreenModel(
      name: item.name,
      price: item.price,
      image: item.image.assetName, // Passing assetName as a String
      quantity: quantity,
    );
  }
}

class Item {
  final String name;
  final double price;
  final ImageData image; // Now using ImageData for image

  Item({
    required this.name,
    required this.price,
    required this.image,
  });
}

class ImageData {
  final String assetName;

  ImageData({
    required this.assetName,
  });
}
