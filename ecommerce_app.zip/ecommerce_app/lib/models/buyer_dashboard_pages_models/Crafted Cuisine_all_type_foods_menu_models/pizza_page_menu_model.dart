// import 'package:minibites/models/buyer_dashboard_pages_models/checkout_page_screen_model.dart';
// import 'package:flutter/material.dart';
//
// // Define PizzaPageMenuModel
// class PizzaPageMenuModel {
//   final String name;
//   final int quantity;
//   final double price;
//   final AssetImage image;
//
//   PizzaPageMenuModel({
//     required this.name,
//     required this.quantity,
//     required this.price,
//     required this.image,
//   });
// }
//
// // Define CartItem
// class CartItem {
//   final MenuItem item;
//   int quantity; // Mutable quantity
//   final String restaurantName; // Add this field
//
//   CartItem({
//     required this.item,
//     this.quantity = 1, // Default quantity to 1
//     required this.restaurantName,
//   });
//
//   // Getters for name and price
//   String get name => item.name;
//   double get price => item.price;
//
//   // Define the toCheckoutPageScreenModel method
//   CheckoutPageScreenModel toCheckoutPageScreenModel() {
//     return CheckoutPageScreenModel(
//       name: item.name,
//       quantity: quantity,
//       price: price,
//       image: item.image,
//     );
//   }
// }
//
// // Define MenuItem
// class MenuItem {
//   final String name;
//   final double price;
//   final AssetImage image;
//   final bool isPopular;
//   int quantity; // Quantity field added
//
//   MenuItem({
//     required this.name,
//     required this.price,
//     required this.image,
//     this.isPopular = false,
//     this.quantity = 1, // Initialize quantity with default value
//   });
// }
//
// // Define Category
// class Category {
//   final String name;
//   final List<MenuItem> items;
//
//   Category({
//     required this.name,
//     required this.items,
//   });
// }
