// lib/models/cart_item.dart
import 'package:flutter/material.dart';

class CartItem {
  final MenuItem item;
  int quantity;  // Mutable quantity
  final String restaurantName;  // Restaurant name field

  CartItem({
    required this.item,
    this.quantity = 1,  // Default quantity
    required this.restaurantName,
  });

  // Getter for item name
  String get name => item.name;

  // Getter for item price
  double get price => item.price;
}

// MenuItem class
class MenuItem {
  final String name;
  final double price;
  final AssetImage image;
  final bool isPopular;
  int quantity;  // Mutable quantity

  MenuItem({
    required this.name,
    required this.price,
    required this.image,
    this.isPopular = false,  // Default value for isPopular
    this.quantity = 1,  // Default quantity
  });
}

// Category class
class Category {
  final String name;
  final List<MenuItem> items;

  Category({
    required this.name,
    required this.items,
  });
}
