import 'package:flutter/material.dart';
import 'package:get/get.dart';

class Cuisine extends StatelessWidget {
  final String name;
  final String imageUrl;

  Cuisine({required this.name, required this.imageUrl});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Image.asset(imageUrl, height: 40, width: 50), // Example dimensions
        SizedBox(width: 10),
        Text(name),
      ],
    );
  }
}

class Restaurant {
  final String name;
  final double rating;
  final int reviews;
  final double minOrder;
  final String category;
  final int deliveryTime;
  final double deliveryFee;
  final Rxn<AssetImage> image;

  Restaurant({
    required this.name,
    required this.rating,
    required this.reviews,
    required this.minOrder,
    required this.category,
    required this.deliveryTime,
    required this.deliveryFee,
    required this.image,
  });
}

