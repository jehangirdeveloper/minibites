// lib/models/buyer_dashboard_pages_models/checkout_page_screen_model.dart
import 'package:flutter/material.dart';

class CheckoutPageScreenModel {
  final String name;
  final double price;
  int quantity;
  final String image; // Image as a String URL or asset name

  CheckoutPageScreenModel({
    required this.name,
    required this.price,
    this.quantity = 1, // Default value for quantity
    required this.image, // Image URL or asset name
  });

  double get totalPrice => price * quantity;
}

class Order {
  final String restaurantName;
  final List<CheckoutPageScreenModel> items;

  Order({
    required this.restaurantName,
    required this.items,
  });

  double get total => items.fold(0, (sum, item) => sum + item.totalPrice);
}
