import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:geocoding/geocoding.dart'; // Import geocoding package

class SellerMultiStepFormController extends GetxController {
  var currentStep = 0.obs;
  var businessName = ''.obs;
  var businessType = ''.obs;
  var businessCategory = ''.obs;
  var branches = ''.obs;
  var phone = ''.obs;
  var selectedLocation = LatLng(33.6844, 73.0479).obs; // Default location
  var selectedProvince = ''.obs;
  var selectedCity = ''.obs;
  var searchController = TextEditingController();

  var hasSntn = false.obs;
  var hasOperatingLicense = false.obs;
  var isListedCompany = false.obs;
  var isSanctionedCountry = false.obs;
  var isRegisteredWithFbr = false.obs;

  // Step 4 fields
  var bankName = ''.obs;
  var bankAccountOwner = ''.obs;
  var AccountNumber = ''.obs;

  // Step 5 variables
  var selectedOption = ''.obs;
  var hasSpecialOffers = false.obs;

  GoogleMapController? mapController;

  @override
  void onInit() {
    super.onInit();
    _getCurrentLocation();
  }

  Future<void> _getCurrentLocation() async {
    bool serviceEnabled;
    LocationPermission permission;

    serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      // Get.snackbar('Error', 'Location services are not enabled.');
      return;
    }

    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission != LocationPermission.whileInUse && permission != LocationPermission.always) {
        Get.snackbar('Error', 'Location permissions are denied.');
        return;
      }
    }

    try {
      Position position = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
      selectedLocation.value = LatLng(position.latitude, position.longitude);
      updateMapLocation();
    } catch (e) {
      Get.snackbar('Error', 'Failed to get current location.');
    }
  }

  void updateMapLocation() {
    if (mapController != null) {
      mapController!.animateCamera(CameraUpdate.newLatLng(selectedLocation.value));
    }
  }

  void updateLocation(LatLng newLocation) {
    selectedLocation.value = newLocation;
    updateMapLocation();
  }

  Future<void> updateAddress(String address) async {
    try {
      List<Location> locations = await locationFromAddress(address);
      if (locations.isNotEmpty) {
        final latLng = LatLng(locations.first.latitude, locations.first.longitude);
        updateLocation(latLng);
      } else {
        // Get.snackbar('Error', 'No location found for this address.');
      }
    } catch (e) {
      // Get.snackbar('Error', 'Could not fetch location for this address. Please check the address and try again.');
    }
  }

  void updateProvince(String province) {
    selectedProvince.value = province;
    selectedCity.value = '';
  }

  void updateCity(String city) {
    selectedCity.value = city;
  }

  bool validateStep1() {
    return businessName.value.isNotEmpty &&
        businessType.value.isNotEmpty &&
        businessCategory.value.isNotEmpty &&
        branches.value.isNotEmpty &&
        phone.value.isNotEmpty;
  }

  void nextStep() {
    if (currentStep.value < 4) {
      currentStep.value++;
    }
  }

  void previousStep() {
    if (currentStep.value > 0) {
      currentStep.value--;
    }
  }


  void saveAndContinue() {
    if (currentStep.value < 4) {
      currentStep.value++;
    } else {
      // Final step, submit the form or perform final action
      submitForm();
    }
  }

  void submitForm() {
    // Add your form submission logic here
    print('Form submitted successfully');
  }
}
