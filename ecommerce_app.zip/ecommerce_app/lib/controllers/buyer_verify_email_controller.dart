// controllers/verify_email_controller.dart
import 'package:get/get.dart';

class BuyerVerifyEmailController extends GetxController {
  var email = 'Email Address '.obs;

  void resendEmail() {
    // Logic to resend email
  }

  void changeEmail(String newEmail) {
    email.value = newEmail;
    // Logic to change email
  }
}
