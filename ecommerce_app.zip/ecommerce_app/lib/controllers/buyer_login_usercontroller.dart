import 'package:flutter/material.dart';
import 'package:get/get.dart';


class BuyerLoginUsercontroller extends GetxController {
  var email = ''.obs;
  var password = ''.obs;

  void login() {
    // Signup logic here
  }
}
