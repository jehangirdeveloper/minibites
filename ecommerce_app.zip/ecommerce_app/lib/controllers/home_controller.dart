import 'package:get/get.dart';

class HomeController extends GetxController {
  // Add your controller properties and methods here
}
