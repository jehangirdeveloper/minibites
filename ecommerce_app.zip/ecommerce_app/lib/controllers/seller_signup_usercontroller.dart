import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class UserController extends GetxController {
  final formKey = GlobalKey<FormState>();

  var fullName = 'Default fullName'.obs;
  var businessName = 'Default businessName'.obs;
  var email = 'example@example.com'.obs;
  var phoneNumber = '0000000000'.obs;
  var password = 'DefaultPassword123'.obs;
  var selectedRole = 'Restaurant'.obs;
  var selectedCountry = 'Pakistan'.obs;
  var cityName = 'Default City'.obs;

  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Future<void> signup() async {
    if (formKey.currentState!.validate()) {
      try {
        // Firebase Authentication
        UserCredential userCredential = await _auth.createUserWithEmailAndPassword(
          email: email.value,
          password: password.value,
        );

        // Firestore database
        await _firestore.collection('users').doc(userCredential.user!.uid).set({
          'fullName': fullName.value,
          'businessName': businessName.value,
          'email': email.value,
          'role': selectedRole.value,
          'country': selectedCountry.value,
          'city': cityName.value,
          'phoneNumber': phoneNumber.value,
        });

        // Handle successful signup
        // You can navigate to another screen or show a success message here
        Get.offNamed('/email-verification'); // Example route
      } catch (e) {
        // Handle errors
        Get.snackbar('Error', e.toString(), backgroundColor: Colors.red, colorText: Colors.white);
      }
    }
  }
}
