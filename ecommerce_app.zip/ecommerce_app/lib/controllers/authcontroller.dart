import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';

class Authcontroller extends GetxController {
  RxBool isLoggedIn = false.obs;
  RxBool isBuyer = false.obs;

  @override
  void onInit() {
    super.onInit();
    checkLoginStatus();
  }

  void checkLoginStatus() async {
    final prefs = await SharedPreferences.getInstance();
    isLoggedIn.value = prefs.getBool('isLoggedIn') ?? false;
    isBuyer.value = prefs.getBool('isBuyer') ?? false;
  }

  void login(bool buyer) async {
    final prefs = await SharedPreferences.getInstance();
    isLoggedIn.value = true;
    isBuyer.value = buyer;
    await prefs.setBool('isLoggedIn', true);
    await prefs.setBool('isBuyer', buyer);
  }

  void logout() async {
    final prefs = await SharedPreferences.getInstance();
    isLoggedIn.value = false;
    isBuyer.value = false;
    await prefs.remove('isLoggedIn');
    await prefs.remove('isBuyer');
  }

  // bool isBuyer() => isBuyer.value;
  bool isSeller() => !isBuyer.value;
}
