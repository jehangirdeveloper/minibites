import 'package:get/get.dart';

class UserController extends GetxController {
  var fullName = 'Default fullName'.obs;
  var username = 'Default Username'.obs;
  var email = 'default@example.com'.obs;
  var phoneNumber = '0000000000'.obs;
  var password = 'DefaultPassword'.obs;
  var city = 'Default City'.obs; // Added city field
  RxString selectedCountry = 'Pakistan'.obs;

  void signup() {
    // Signup logic here
  }
}
