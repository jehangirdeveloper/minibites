import 'package:flutter/material.dart';
import 'package:get/get.dart';


class SellerLoginController extends GetxController {
  var email = ''.obs;
  var password = ''.obs;

  void login() {
    // Signup logic here
  }
}
