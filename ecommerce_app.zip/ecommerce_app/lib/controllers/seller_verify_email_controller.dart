// controllers/verify_email_controller.dart
import 'package:get/get.dart';

class SellerVerifyEmailController extends GetxController {
  var email = ''.obs;

  void resendEmail() {
    // Logic to resend email
  }

  void changeEmail(String newEmail) {
    email.value = newEmail;
    // Logic to change email
  }
}
