import 'package:get/get.dart';

class HelpCenterPageController extends GetxController {
  var name = ''.obs;
  var email = ''.obs;
  var message = ''.obs;

  void submitForm() {
    if (name.value.isNotEmpty && email.value.isNotEmpty && message.value.isNotEmpty) {
      // Aap yahan form submit logic ko implement kar sakte hain
      print('Form Submitted: Name: ${name.value}, Email: ${email.value}, Message: ${message.value}');
    } else {
      print('Please fill all fields.');
    }
  }
}
