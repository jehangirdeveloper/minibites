import 'dart:async';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class OrderTrackingController extends GetxController {

  var totalAmount = 0.0.obs;
  var minTime = 35.obs; // Start with 35 minutes
  var orderStatus = 'Anytime, your order has arrived at your door'.obs;

  @override
  void onInit() {
    super.onInit();
    // Listen to the totalAmount changes
    ever(totalAmount, (value) {
      // Perform actions when totalAmount updates
    });
    _startCountdown();
  }

  void _startCountdown() {
    Timer.periodic(Duration(seconds: 60), (Timer timer) {
      if (minTime.value > 0) {
        minTime.value--;
      } else {
        timer.cancel();
        orderStatus.value = 'Anytime, your order has arrived at your door'; // Final status update
      }
    });
  }
}
