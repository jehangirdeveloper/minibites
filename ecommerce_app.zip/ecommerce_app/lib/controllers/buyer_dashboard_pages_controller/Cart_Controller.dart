import 'package:get/get.dart';
import 'package:minibites/models/MenuItem.dart';

class CartController extends GetxController {
  var cartItems = <MenuItem>[].obs;

  int get totalItems => cartItems.length;

  double getSubTotalPrice() {
    return cartItems.fold(0.0, (total, item) => total + (item.price * item.quantity));
  }

  double getTotalPrice() {
    double subTotal = getSubTotalPrice();
    double platformFee = cartItems.isNotEmpty ? 20.0 : 0.0; // Platform fee added only if cart is not empty
    double deliveryFee = cartItems.isNotEmpty ? 50.0 : 0.0; // Delivery fee added only if cart is not empty
    return subTotal + platformFee + deliveryFee;
  }

  void addToCart(MenuItem item) {
    var existingItem = cartItems.firstWhereOrNull((i) => i.id == item.id);
    if (existingItem != null) {
      existingItem.quantity += 1;
      cartItems.refresh();
    } else {
      cartItems.add(item.copyWith(quantity: 1));
    }
  }

  void incrementQuantity(String id) {
    var item = cartItems.firstWhereOrNull((i) => i.id == id);
    if (item != null) {
      item.quantity += 1;
      cartItems.refresh();
    }
  }

  void decrementQuantity(String id) {
    var item = cartItems.firstWhereOrNull((i) => i.id == id);
    if (item != null) {
      if (item.quantity > 1) {
        item.quantity -= 1;
      } else {
        cartItems.remove(item);
      }
      cartItems.refresh();
    }
  }

  void removeItem(String id) {
    cartItems.removeWhere((item) => item.id == id);
    cartItems.refresh();
  }
}
