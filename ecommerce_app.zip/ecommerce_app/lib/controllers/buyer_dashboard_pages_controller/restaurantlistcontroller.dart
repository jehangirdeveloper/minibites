import 'package:get/get.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:minibites/models/seller_dashboard_pages/restaurant_model.dart';

class Restaurantlistcontroller extends GetxController {
  var restaurants = <RestaurantModel>[].obs;

  void fetchRestaurants(String category) async {
    final querySnapshot = await FirebaseFirestore.instance
        .collection('restaurants')
        .where('category', isEqualTo: category)
        .get();
    restaurants.value = querySnapshot.docs.map((doc) => RestaurantModel.fromDocument(doc)).toList();
  }
}
