import 'package:minibites/models/buyer_dashboard_pages_models/buyer_dashboard_model.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class PastaPageController extends GetxController {
  var cuisines = <Cuisine>[].obs;

// Biryani Page Controller
  var restaurant4 = Restaurant(
    name: 'Pasta Hotel',
    rating: 4.5,
    reviews: 500,
    minOrder: 180,
    category: 'Pasta',
    deliveryTime: 25,
    deliveryFee: 70,
    image: Rxn<AssetImage>(AssetImage('images/Pasta-image-1.jpg')),
  ).obs;

  var restaurant5 = Restaurant(
    name: 'Karachi Pasta',
    rating: 4.5,
    reviews: 500,
    minOrder: 190,
    category: 'Pasta',
    deliveryTime: 30,
    deliveryFee: 75,
    image: Rxn<AssetImage>(AssetImage('images/Pasta-image-2.jpg')),
  ).obs;

  var restaurant6 = Restaurant(
    name: 'Lahore Pasta',
    rating: 4,
    reviews: 50,
    minOrder: 195,
    category: 'Pasta',
    deliveryTime: 32,
    deliveryFee: 79,
    image: Rxn<AssetImage>(AssetImage('images/Pasta-image-3.jpg')),
  ).obs;

}