// import 'package:get/get.dart';
// import 'package:minibites/models/seller_dashboard_pages/restaurant_model.dart';
//
// class PizzaPageController extends GetxController {
//   var restaurant4 = Rx<Restaurant>(Restaurant(
//     name: '',
//     category: '',
//     image: '', // Initialize image
//   ));
//
//   void setRestaurant(Restaurant restaurant) {
//     restaurant4.value = restaurant;
//   }
// }
