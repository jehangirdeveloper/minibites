import 'package:minibites/models/buyer_dashboard_pages_models/buyer_dashboard_model.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class BiryaniPageController extends GetxController {
  var cuisines = <Cuisine>[].obs;

// Biryani Page Controller
  var restaurant4 = Restaurant(
    name: 'Peshawar Hotel',
    rating: 4.5,
    reviews: 500,
    minOrder: 180,
    category: 'Biryani',
    deliveryTime: 25,
    deliveryFee: 70,
    image: Rxn<AssetImage>(AssetImage('images/biryani-image-1.jpg')),
  ).obs;

  var restaurant5 = Restaurant(
    name: 'Biryani Hotel',
    rating: 4.5,
    reviews: 500,
    minOrder: 190,
    category: 'Biryani',
    deliveryTime: 30,
    deliveryFee: 75,
    image: Rxn<AssetImage>(AssetImage('images/biryani-image-2.jpg')),
  ).obs;

  var restaurant6 = Restaurant(
    name: 'Multani Biryani',
    rating: 4,
    reviews: 50,
    minOrder: 195,
    category: 'Biryani',
    deliveryTime: 32,
    deliveryFee: 79,
    image: Rxn<AssetImage>(AssetImage('images/biryani-image-3.jpg')),
  ).obs;

}