import 'package:minibites/models/buyer_dashboard_pages_models/buyer_dashboard_model.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class IcecreamPageController extends GetxController {
  var cuisines = <Cuisine>[].obs;

// Icecream Page Controller

  var restaurant4 = Restaurant(
    name: ' Famous Icecream',
    rating: 4.5,
    reviews: 500,
    minOrder: 180,
    category: 'Icecream',
    deliveryTime: 25,
    deliveryFee: 70,
    image: Rxn<AssetImage>(AssetImage('images/Icecream-image-1.jpg')),
  ).obs;

  var restaurant5 = Restaurant(
    name: 'Karachi Icecream',
    rating: 4.5,
    reviews: 500,
    minOrder: 190,
    category: 'Icecream',
    deliveryTime: 30,
    deliveryFee: 75,
    image: Rxn<AssetImage>(AssetImage('images/Icecream-image-2.jpg')),
  ).obs;

  var restaurant6 = Restaurant(
    name: 'Lahore Icecream',
    rating: 4,
    reviews: 50,
    minOrder: 195,
    category: 'Icecream',
    deliveryTime: 32,
    deliveryFee: 79,
    image: Rxn<AssetImage>(AssetImage('images/Icecream-image-3.jpg')),
  ).obs;

}