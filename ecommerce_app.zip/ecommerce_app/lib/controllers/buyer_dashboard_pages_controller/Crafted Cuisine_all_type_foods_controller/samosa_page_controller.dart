import 'package:minibites/models/buyer_dashboard_pages_models/buyer_dashboard_model.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class SamosaPageController extends GetxController {
  var cuisines = <Cuisine>[].obs;

// Samosa Page Controller

  var restaurant4 = Restaurant(
    name: ' Famous Samosa',
    rating: 4.5,
    reviews: 500,
    minOrder: 180,
    category: 'Samosa',
    deliveryTime: 25,
    deliveryFee: 70,
    image: Rxn<AssetImage>(AssetImage('images/Samosa-image-1.jpg')),
  ).obs;

  var restaurant5 = Restaurant(
    name: 'Karachi Samosa',
    rating: 4.5,
    reviews: 500,
    minOrder: 190,
    category: 'Samosa',
    deliveryTime: 30,
    deliveryFee: 75,
    image: Rxn<AssetImage>(AssetImage('images/Samosa-image-2.jpg')),
  ).obs;

  var restaurant6 = Restaurant(
    name: 'Lahore Samosa',
    rating: 4,
    reviews: 50,
    minOrder: 195,
    category: 'Samosa',
    deliveryTime: 32,
    deliveryFee: 79,
    image: Rxn<AssetImage>(AssetImage('images/Samosa-image-3.jpg')),
  ).obs;

}