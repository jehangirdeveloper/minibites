import 'package:minibites/models/buyer_dashboard_pages_models/buyer_dashboard_model.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class SweetdishPageController extends GetxController {
  var cuisines = <Cuisine>[].obs;

// Sweetdish Page Controller

  var restaurant4 = Restaurant(
    name: ' Famous Sweetdish',
    rating: 4.5,
    reviews: 500,
    minOrder: 180,
    category: 'Sweetdish',
    deliveryTime: 25,
    deliveryFee: 70,
    image: Rxn<AssetImage>(AssetImage('images/Sweetdish-image-1.jpg')),
  ).obs;

  var restaurant5 = Restaurant(
    name: 'Karachi Sweetdish',
    rating: 4.5,
    reviews: 500,
    minOrder: 190,
    category: 'Sweetdish',
    deliveryTime: 30,
    deliveryFee: 75,
    image: Rxn<AssetImage>(AssetImage('images/Sweetdish-image-2.jpg')),
  ).obs;

  var restaurant6 = Restaurant(
    name: 'Lahore Sweetdish',
    rating: 4,
    reviews: 50,
    minOrder: 195,
    category: 'Sweetdish',
    deliveryTime: 32,
    deliveryFee: 79,
    image: Rxn<AssetImage>(AssetImage('images/Sweetdish-image-3.jpg')),
  ).obs;

}