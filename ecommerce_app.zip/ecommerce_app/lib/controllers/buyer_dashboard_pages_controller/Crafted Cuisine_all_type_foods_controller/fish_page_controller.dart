import 'package:minibites/models/buyer_dashboard_pages_models/buyer_dashboard_model.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class FishPageController extends GetxController {
  var cuisines = <Cuisine>[].obs;

// Fish Page Controller

  var restaurant4 = Restaurant(
    name: ' Famous Fish',
    rating: 4.5,
    reviews: 500,
    minOrder: 180,
    category: 'Fish',
    deliveryTime: 25,
    deliveryFee: 70,
    image: Rxn<AssetImage>(AssetImage('images/Fish-image-1.jpg')),
  ).obs;

  var restaurant5 = Restaurant(
    name: 'Karachi Fish',
    rating: 4.5,
    reviews: 500,
    minOrder: 190,
    category: 'Fish',
    deliveryTime: 30,
    deliveryFee: 75,
    image: Rxn<AssetImage>(AssetImage('images/Fish-image-2.jpg')),
  ).obs;

  var restaurant6 = Restaurant(
    name: 'Lahore Fish',
    rating: 4,
    reviews: 50,
    minOrder: 195,
    category: 'Fish',
    deliveryTime: 32,
    deliveryFee: 79,
    image: Rxn<AssetImage>(AssetImage('images/Fish-image-3.jpg')),
  ).obs;

}