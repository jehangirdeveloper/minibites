import 'package:minibites/models/buyer_dashboard_pages_models/buyer_dashboard_model.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class FastFoodPageController extends GetxController {
  var cuisines = <Cuisine>[].obs;

// FastFood Page Controller
  var restaurant4 = Restaurant(
    name: 'Fast Food',
    rating: 4.5,
    reviews: 500,
    minOrder: 180,
    category: 'Fast Food',
    deliveryTime: 25,
    deliveryFee: 70,
    image: Rxn<AssetImage>(AssetImage('images/fast-food-image-1.jpg')),
  ).obs;

  var restaurant5 = Restaurant(
    name: 'Loaded',
    rating: 4.5,
    reviews: 500,
    minOrder: 190,
    category: 'Fast Food',
    deliveryTime: 30,
    deliveryFee: 75,
    image: Rxn<AssetImage>(AssetImage('images/fast-food-image-2.jpg')),
  ).obs;

  var restaurant6 = Restaurant(
    name: 'NFC',
    rating: 4,
    reviews: 50,
    minOrder: 195,
    category: 'Fast Food',
    deliveryTime: 32,
    deliveryFee: 79,
    image: Rxn<AssetImage>(AssetImage('images/fast-food-image-3.jpg')),
  ).obs;

}