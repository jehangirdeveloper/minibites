import 'package:minibites/models/buyer_dashboard_pages_models/buyer_dashboard_model.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class BbqPageController extends GetxController {
  var cuisines = <Cuisine>[].obs;

// BBQ Page Controller
  
  var restaurant4 = Restaurant(
    name: 'BBQ Hotel',
    rating: 4.5,
    reviews: 500,
    minOrder: 180,
    category: 'BBQ',
    deliveryTime: 25,
    deliveryFee: 70,
    image: Rxn<AssetImage>(AssetImage('images/BBQ-image-1.jpg')),
  ).obs;

  var restaurant5 = Restaurant(
    name: 'Karachi BBQ',
    rating: 4.5,
    reviews: 500,
    minOrder: 190,
    category: 'BBQ',
    deliveryTime: 30,
    deliveryFee: 75,
    image: Rxn<AssetImage>(AssetImage('images/BBQ-image-2.jpg')),
  ).obs;

  var restaurant6 = Restaurant(
    name: 'Lahore BBQ',
    rating: 4,
    reviews: 50,
    minOrder: 195,
    category: 'BBQ',
    deliveryTime: 32,
    deliveryFee: 79,
    image: Rxn<AssetImage>(AssetImage('images/BBQ-image-3.jpg')),
  ).obs;

}