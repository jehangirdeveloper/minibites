import 'package:minibites/models/buyer_dashboard_pages_models/buyer_dashboard_model.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class BurgersPageController extends GetxController {
  var cuisines = <Cuisine>[].obs;

// Burgers Page Controller

  var restaurant4 = Restaurant(
    name: 'Famous Burger',
    rating: 4.5,
    reviews: 500,
    minOrder: 180,
    category: 'Burgers',
    deliveryTime: 25,
    deliveryFee: 70,
    image: Rxn<AssetImage>(AssetImage('images/Burgers-image-3.jpg')),
  ).obs;

  var restaurant5 = Restaurant(
    name: 'Karachi Burgers',
    rating: 4.5,
    reviews: 500,
    minOrder: 190,
    category: 'Burgers',
    deliveryTime: 30,
    deliveryFee: 75,
    image: Rxn<AssetImage>(AssetImage('images/Burgers-image-2.jpg')),
  ).obs;

  var restaurant6 = Restaurant(
    name: 'Lahore Burgers',
    rating: 4,
    reviews: 50,
    minOrder: 195,
    category: 'Burgers',
    deliveryTime: 32,
    deliveryFee: 79,
    image: Rxn<AssetImage>(AssetImage('images/Burgers-image-1.jpg')),
  ).obs;

}