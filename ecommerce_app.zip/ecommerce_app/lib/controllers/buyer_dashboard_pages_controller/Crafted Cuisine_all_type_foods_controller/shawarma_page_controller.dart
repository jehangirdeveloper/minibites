import 'package:minibites/models/buyer_dashboard_pages_models/buyer_dashboard_model.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class ShawarmaPageController extends GetxController {
  var cuisines = <Cuisine>[].obs;

// Shawarma Page Controller

  var restaurant4 = Restaurant(
    name: 'Famous Shawarma',
    rating: 4.5,
    reviews: 500,
    minOrder: 180,
    category: 'Shawarma',
    deliveryTime: 25,
    deliveryFee: 70,
    image: Rxn<AssetImage>(AssetImage('images/Shawarma-image-1.jpg')),
  ).obs;

  var restaurant5 = Restaurant(
    name: 'Karachi Shawarma',
    rating: 4.5,
    reviews: 500,
    minOrder: 190,
    category: 'Shawarma',
    deliveryTime: 30,
    deliveryFee: 75,
    image: Rxn<AssetImage>(AssetImage('images/Shawarma-image-2.jpg')),
  ).obs;

  var restaurant6 = Restaurant(
    name: 'Lahore Shawarma',
    rating: 4,
    reviews: 50,
    minOrder: 195,
    category: 'Shawarma',
    deliveryTime: 32,
    deliveryFee: 79,
    image: Rxn<AssetImage>(AssetImage('images/Shawarma-image-3.jpg')),
  ).obs;

}