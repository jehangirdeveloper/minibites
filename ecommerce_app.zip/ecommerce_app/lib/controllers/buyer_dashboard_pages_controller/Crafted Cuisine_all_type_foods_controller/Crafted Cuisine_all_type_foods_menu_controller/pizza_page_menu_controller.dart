// import 'package:flutter/material.dart';
// import 'package:minibites/models/buyer_dashboard_pages_models/UnifiedCartItem.dart';
// import 'package:get/get.dart';
// import '../../../../models/buyer_dashboard_pages_models/Crafted Cuisine_all_type_foods_menu_models/pizza_page_menu_model.dart';
//
// class PizzaPageMenuController extends GetxController {
//   var categories = <Category>[].obs;
//   var cartItems = <UnifiedCartItem>[].obs; // Updated type
//   var subTotal = 0.0.obs;
//   var deliveryFee = 49.0;
//   var platformFee = 9.99;
//   var totalAmount = 0.0.obs;
//   var cartItemCount = 0.obs;
//
//   @override
//   void onInit() {
//     super.onInit();
//     fetchMenu();
//   }
//
//   void fetchMenu() {
//     categories.value = [
//       Category(name: 'Popular Deals', items: [
//         MenuItem(name: 'Grilled Chicken Pizza1', price: 650, image: AssetImage('images/pizza-page-menu-images/popular-deal-image-1.png'), isPopular: true),
//         MenuItem(name: 'Chicken Tikka Pizza2', price: 800, image: AssetImage('images/pizza-page-menu-images/popular-deal-image-2.png'), isPopular: true),
//       ]),
//       Category(name: 'Chicken Pizza', items: [
//         MenuItem(name: 'Chicken Pizza3', price: 1200, image: AssetImage('images/pizza-page-menu-images/pizza-image-1.jpg')),
//         MenuItem(name: 'Chicken Tikka Pizza4', price: 1500, image: AssetImage('images/pizza-page-menu-images/pizza-image-2.jpg')),
//       ]),
//       Category(name: 'Grilled Pizza', items: [
//         MenuItem(name: 'Grilled Chicken Pizza5', price: 1500, image: AssetImage('images/pizza-page-menu-images/grilled-pizza-image-1.png')),
//       ]),
//     ];
//   }
//
//   void addToCart(MenuItem item, String restaurantName) {
//     var existingItem = cartItems.firstWhereOrNull((cartItem) => cartItem.name == item.name);
//     if (existingItem != null) {
//       existingItem.quantity.value++; // Update quantity using .value
//     } else {
//       cartItems.add(UnifiedCartItem(
//         name: item.name,
//         price: item.price,
//         image: item.image,
//         quantity: 1, // Initialize as int
//         restaurantName: restaurantName,
//       ));
//     }
//     updateCart();
//   }
//
//   void removeFromCart(MenuItem item) {
//     var existingItem = cartItems.firstWhereOrNull((cartItem) => cartItem.name == item.name);
//     if (existingItem != null) {
//       if (existingItem.quantity.value > 1) { // Use .value to read RxInt
//         existingItem.quantity.value--;
//       } else {
//         cartItems.remove(existingItem);
//       }
//       updateCart();
//     }
//   }
//
//   void updateQuantity(MenuItem item, int quantity) {
//     var cartItem = cartItems.firstWhereOrNull((cartItem) => cartItem.name == item.name);
//     if (cartItem != null) {
//       if (quantity > 0) {
//         cartItem.quantity.value = quantity; // Use .value to update RxInt
//       } else {
//         cartItems.remove(cartItem);
//       }
//       updateCart();
//     }
//   }
//
//   void updateCart() {
//     cartItemCount.value = cartItems.length;
//     subTotal.value = cartItems.fold(0.0, (sum, cartItem) => sum + cartItem.price * cartItem.quantity.value); // Use .value to get int
//     totalAmount.value = subTotal.value + deliveryFee + platformFee;
//   }
// }
