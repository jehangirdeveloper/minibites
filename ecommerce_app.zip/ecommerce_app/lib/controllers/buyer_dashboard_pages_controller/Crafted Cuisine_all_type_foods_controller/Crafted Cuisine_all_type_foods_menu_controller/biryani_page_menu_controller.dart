// import 'package:flutter/material.dart';
// import 'package:minibites/models/buyer_dashboard_pages_models/UnifiedCartItem.dart';
// import 'package:get/get.dart';
// import '../../../../models/buyer_dashboard_pages_models/Crafted Cuisine_all_type_foods_menu_models/biryani_page_menu_model.dart';
//
// class BiryaniPageMenuController extends GetxController {
//   var categories = <Category>[].obs;
//   var cartItems = <UnifiedCartItem>[].obs; // Updated type
//   var subTotal = 0.0.obs;
//   var deliveryFee = 49.0;
//   var platformFee = 9.99;
//   var totalAmount = 0.0.obs;
//   var cartItemCount = 0.obs;
//
//   @override
//   void onInit() {
//     super.onInit();
//     fetchMenu();
//   }
//
//   void fetchMenu() {
//     categories.value = [
//       Category(name: 'Biryani 1', items: [
//         MenuItem(name: 'Biryani 1', price: 860, image: AssetImage('images/biryani-page-menu-images/biryani-page-menu-images-2.png'), isPopular: true),
//         MenuItem(name: 'Biryani 2', price: 960, image: AssetImage('images/biryani-page-menu-images/biryani-page-menu-images-3.png'), isPopular: true),
//         // Add more items here...
//       ]),
//       Category(name: 'Biryani 2', items: [
//         MenuItem(name: 'Biryani 3', price: 1360, image: AssetImage('images/biryani-page-menu-images/biryani-page-menu-images-4.png')),
//         MenuItem(name: 'Biryani 4', price: 1660, image: AssetImage('images/biryani-page-menu-images/biryani-page-menu-images-5.png')),
//         // Add more items here...
//       ]),
//       Category(name: 'Biryani 3', items: [
//         MenuItem(name: 'Biryani 5', price: 1860, image: AssetImage('images/biryani-page-menu-images/biryani-page-menu-images-6.png')),
//       ]),
//     ];
//   }
//
//   void addToCart(MenuItem item, String restaurantName) {
//     var existingItem = cartItems.firstWhereOrNull((cartItem) => cartItem.name == item.name);
//     if (existingItem != null) {
//       existingItem.quantity.value++; // Update quantity using .value
//     } else {
//       cartItems.add(UnifiedCartItem(
//         name: item.name,
//         price: item.price,
//         image: item.image,
//         quantity: 1, // Initialize as int
//         restaurantName: restaurantName,
//       ));
//     }
//     updateCart();
//   }
//
//   void removeFromCart(MenuItem item) {
//     var existingItem = cartItems.firstWhereOrNull((cartItem) => cartItem.name == item.name);
//     if (existingItem != null) {
//       if (existingItem.quantity.value > 1) {
//         existingItem.quantity.value--;
//       } else {
//         cartItems.remove(existingItem);
//       }
//       updateCart();
//     }
//   }
//
//   void updateQuantity(MenuItem item, int quantity) {
//     var cartItem = cartItems.firstWhereOrNull((cartItem) => cartItem.name == item.name);
//     if (cartItem != null) {
//       if (quantity > 0) {
//         cartItem.quantity.value = quantity; // Use .value to update RxInt
//       } else {
//         cartItems.remove(cartItem);
//       }
//       updateCart();
//     }
//   }
//
//   void updateCart() {
//     cartItemCount.value = cartItems.length;
//     subTotal.value = cartItems.fold(0.0, (sum, cartItem) => sum + cartItem.price * cartItem.quantity.value); // Use .value to get int
//     totalAmount.value = subTotal.value + deliveryFee + platformFee;
//   }
// }
