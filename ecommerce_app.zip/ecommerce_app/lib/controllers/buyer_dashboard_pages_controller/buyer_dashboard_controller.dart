import 'package:minibites/models/buyer_dashboard_pages_models/buyer_dashboard_model.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class BuyerDashboardController extends GetxController {
  var cuisines = <Cuisine>[].obs;
  var searchResults = <Cuisine>[].obs;

  var restaurant = Restaurant(
    name: 'Famous Chinese',
    rating: 4.9,
    reviews: 4000,
    minOrder: 149,
    category: 'Fast Food',
    deliveryTime: 20,
    deliveryFee: 49,
    image: Rxn<AssetImage>(AssetImage('images/top-restaurants-image-1.jpg')),
  ).obs;

  var restaurant2 = Restaurant(
    name: 'BBQ Hotel',
    rating: 5.0,
    reviews: 1000,
    minOrder: 220,
    category: 'BBQ',
    deliveryTime: 20,
    deliveryFee: 100,
    image: Rxn<AssetImage>(AssetImage('images/top-restaurants-image-2.jpeg')),
  ).obs;

  var restaurant3 = Restaurant(
    name: 'Famous Sweetdish',
    rating: 4.5,
    reviews: 500,
    minOrder: 180,
    category: 'Sweetdish',
    deliveryTime: 25,
    deliveryFee: 70,
    image: Rxn<AssetImage>(AssetImage('images/sweetdish.jpg')),
  ).obs;

  @override
  void onInit() {
    fetchCuisines();
    super.onInit();
  }

  void fetchCuisines() {
    cuisines.assignAll([
      Cuisine(name: 'Pizza', imageUrl: 'images/pizza.png'),
      Cuisine(name: 'Burgers', imageUrl: 'images/burgers.png'),
      Cuisine(name: 'Shawarma', imageUrl: 'images/shurma.png'),
      Cuisine(name: 'Haleem', imageUrl: 'images/haleem.png'),
      Cuisine(name: 'Pulao', imageUrl: 'images/pulao.png'),
      Cuisine(name: 'Biryani', imageUrl: 'images/biryani.png'),
      Cuisine(name: 'Pasta', imageUrl: 'images/pasta.png'),
      Cuisine(name: 'Paratha Roll', imageUrl: 'images/paratha.png'),
      Cuisine(name: 'BBQ', imageUrl: 'images/bbq.png'),
      Cuisine(name: 'Pak Food', imageUrl: 'images/Pakistani-Food.png'),
      Cuisine(name: 'Ice Cream', imageUrl: 'images/ice-cream.png'),
      Cuisine(name: 'Chinese', imageUrl: 'images/Chinese.png'),
      Cuisine(name: 'Samosa', imageUrl: 'images/samosa.png'),
      Cuisine(name: 'Desserts', imageUrl: 'images/desert.png'),
      Cuisine(name: 'Fish', imageUrl: 'images/fish.png'),
      Cuisine(name: 'Sweet Dish', imageUrl: 'images/sweet-dish.png'),
    ]);
    searchResults.assignAll(cuisines);
  }

  void searchCuisine(String query) {
    if (query.isEmpty) {
      searchResults.assignAll(cuisines);
    } else {
      searchResults.assignAll(
        cuisines.where((cuisine) => cuisine.name.toLowerCase().contains(query.toLowerCase())).toList(),
      );
    }
  }
}
