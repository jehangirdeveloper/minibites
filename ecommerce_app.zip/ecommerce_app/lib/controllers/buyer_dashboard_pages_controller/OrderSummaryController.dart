import 'package:get/get.dart';

// Controller for the third image (Order Summary)
class OrderSummaryController extends GetxController {
  var itemName = 'Chicken Piece'.obs;
  var itemPrice = 'Rs. 325.00'.obs;
  var subtotal = 'Rs. 325.00'.obs;
  var deliveryFee = 'Rs. 49.00'.obs;
  var platformFee = 'Rs. 9.99'.obs;
  var totalAmount = 'Rs. 383.99'.obs;
  var paymentMethod = 'cash on delivery'.obs;
}