import 'package:get/get.dart';

// Controller for the second image (Order Details)
class OrderDetailsController extends GetxController {
  var orderNumber = '#plsf-2433-ud2y'.obs;
  var restaurantName = 'NFC - The Pizza Expert'.obs;
  var deliveryAddress =
      'Building House No 324-D Mehr Pura Sharkhi Near Khalid Sead Hospital Rawalpindi'
          .obs;
  var totalAmount = 'Rs. 383.99'.obs;
}