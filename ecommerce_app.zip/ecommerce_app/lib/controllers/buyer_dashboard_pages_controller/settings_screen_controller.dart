// settings_controller.dart
import 'package:minibites/models/buyer_dashboard_pages_models/settings_screen_model.dart';
import 'package:get/get.dart';

class SettingsScreenController extends GetxController {
  final SettingsScreenModel settings = SettingsScreenModel();

  void updateName(String newName) {
    settings.name.value = newName;
  }

  void updateEmail(String newEmail) {
    settings.email.value = newEmail;
  }

  void updateAddress(String newAddress) {
    settings.address.value = newAddress;
  }

  void updateMobileNumber(String newNumber) {
    settings.mobileNumber.value = newNumber;
  }
}
