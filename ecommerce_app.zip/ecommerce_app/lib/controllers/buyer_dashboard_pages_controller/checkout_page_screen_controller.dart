// lib/controllers/buyer_dashboard_pages_controller/checkout_page_screen_controller.dart
import 'package:get/get.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:minibites/models/buyer_dashboard_pages_models/checkout_page_screen_model.dart';

class CheckoutPageScreenController extends GetxController {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  // Method to fetch restaurant name from Firestore
  Future<String> fetchRestaurantName(String restaurantId) async {
    try {
      DocumentSnapshot restaurantSnapshot =
      await _firestore.collection('restaurants').doc(restaurantId).get();

      if (restaurantSnapshot.exists) {
        return restaurantSnapshot['name']; // Assuming the restaurant's name is stored under the 'name' field
      } else {
        return 'Unknown Restaurant'; // In case restaurant not found
      }
    } catch (e) {
      print('Error fetching restaurant name: $e');
      return 'Error fetching name';
    }
  }

  // Method to convert Item to CheckoutPageScreenModel
  CheckoutPageScreenModel toCheckoutPageScreenModel(Item item, int quantity) {
    return CheckoutPageScreenModel(
      name: item.name,
      price: item.price,
      image: item.image.assetName,
      quantity: quantity,
    );
  }
}


class Item {
  final String name;
  final double price;
  final ImageData image; // Now using ImageData for image

  Item({
    required this.name,
    required this.price,
    required this.image,
  });
}

class ImageData {
  final String assetName;

  ImageData({
    required this.assetName,
  });
}

class Order {
  List<CheckoutPageScreenModel> items;
  String restaurantName;

  Order({
    required this.items,
    required this.restaurantName,
  });
}
