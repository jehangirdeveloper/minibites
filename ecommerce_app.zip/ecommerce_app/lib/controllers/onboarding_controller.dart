import 'package:get/get.dart';
import 'package:liquid_swipe/PageHelpers/LiquidController.dart';

class OnboardingController extends GetxController {
  var currentPage = 0.obs;

  void onPageChanged(int index) {
    currentPage.value = index;
  }

  void nextPage(LiquidController controller) {
    if (currentPage.value < 2) {
      controller.animateToPage(page: currentPage.value + 1);
    } else {
      // Navigate to home or login screen
    }
  }
}
