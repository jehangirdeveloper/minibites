import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:get/get.dart';

class Restaurant {
  final String id;
  final String category;
  final String city;
  final String closingTime;
  final String country;
  final String imageUrl;
  final String name;

  Restaurant({
    required this.id,
    required this.category,
    required this.city,
    required this.closingTime,
    required this.country,
    required this.imageUrl,
    required this.name,
  });
}

class Order {
  final String orderId;
  final String orderDetails;
  final String customerName;
  final double totalAmount;
  final String orderNumber;
  final String paymentMethod;
  final String paymentStatus;
  final double platformFee;
  final List<double> prices; // Prices list
  final List<int> quantities; // Quantities list
  final String restaurantName;
  final String status;
  final double subtotal;
  final DateTime timestamp;
  final List<String> items; // Items list
  final String deliveryAddress;

  Order({
    required this.orderId,
    required this.orderDetails,
    required this.totalAmount,
    required this.customerName,
    required this.orderNumber,
    required this.paymentMethod,
    required this.paymentStatus,
    required this.platformFee,
    required this.prices,
    required this.quantities,
    required this.restaurantName,
    required this.status,
    required this.subtotal,
    required this.timestamp,
    required this.items,
    required this.deliveryAddress,
  });
}

class RestaurantController extends GetxController {
  var restaurantsList = <Restaurant>[].obs;
  var ordersList = <Order>[].obs;

  // Additional list to store all restaurants
  List<Restaurant> allRestaurantsList = [];

  @override
  void onInit() {
    fetchRestaurants();
    super.onInit();
  }

  // Fetch restaurants from Firestore
  void fetchRestaurants() async {
    try {
      var restaurantsCollection = FirebaseFirestore.instance.collection('restaurants');
      var snapshot = await restaurantsCollection.get();

      allRestaurantsList = snapshot.docs.map((doc) {
        return Restaurant(
          id: doc.id,
          category: doc.data()['category'] ?? 'No category',
          city: doc.data()['city'] ?? 'No city',
          closingTime: doc.data()['closingTime'] ?? 'No closing time',
          country: doc.data()['country'] ?? 'No country',
          imageUrl: doc.data()['imageUrl'] ?? 'No image URL',
          name: doc.data()['name'] ?? 'No Name',
        );
      }).toList();

      // Initially, show all restaurants
      restaurantsList.value = allRestaurantsList;
    } catch (e) {
      print("Error fetching restaurants: $e");
    }
  }

  // Filter restaurants based on selected country and city
  void filterRestaurants({required String country, required String city}) {
    List<Restaurant> filtered = allRestaurantsList.where((restaurant) {
      bool countryMatch = (country == 'All') || (restaurant.country.toLowerCase() == country.toLowerCase());
      bool cityMatch = (city == 'All') || (restaurant.city.toLowerCase() == city.toLowerCase());
      return countryMatch && cityMatch;
    }).toList();

    restaurantsList.value = filtered;
  }

  // New: Search restaurants based on a query (name or category)
  void searchRestaurants(String query) {
    query = query.toLowerCase();

    // Filter based on the query
    List<Restaurant> filtered = allRestaurantsList.where((restaurant) {
      return restaurant.name.toLowerCase().contains(query) ||
          restaurant.category.toLowerCase().contains(query);
    }).toList();

    restaurantsList.value = filtered; // Update the observable list
  }

  // Fetch orders for a specific restaurant
  void fetchOrders(String restaurantId) async {
    try {
      var ordersCollection = FirebaseFirestore.instance
          .collection('restaurants')
          .doc(restaurantId)
          .collection('orders');

      var snapshot = await ordersCollection.get();

      ordersList.value = snapshot.docs.map((doc) {
        return Order(
          orderId: doc.id,
          orderDetails: doc.data()['details'] ?? 'No details available',
          customerName: doc.data()['customerName'] ?? 'No name available',
          totalAmount: (doc.data()['totalAmount'] ?? 0).toDouble(),
          orderNumber: doc.data()['orderNumber'] ?? 'No order number',
          paymentMethod: doc.data()['paymentMethod'] ?? 'No payment method',
          paymentStatus: doc.data()['paymentStatus'] ?? 'Pending',
          platformFee: (doc.data()['platformFee'] ?? 0.0).toDouble(),
          prices: List<double>.from(doc.data()['prices'] ?? []),
          quantities: List<int>.from(doc.data()['quantities'] ?? []),
          restaurantName: doc.data()['restaurantName'] ?? 'No restaurant name',
          status: doc.data()['status'] ?? 'Pending',
          subtotal: (doc.data()['subtotal'] ?? 0.0).toDouble(),
          timestamp: (doc.data()['timestamp'] as Timestamp).toDate(),
          items: List<String>.from(doc.data()['items'] ?? []),
          deliveryAddress: doc.data()['deliveryAddress'] ?? 'No delivery address',
        );
      }).toList();
    } catch (e) {
      print("Error fetching orders: $e");
    }
  }

  // Stream for real-time order updates
  Stream<List<Order>> getOrderStream(String restaurantId) {
    var ordersCollection = FirebaseFirestore.instance
        .collection('restaurants')
        .doc(restaurantId)
        .collection('orders')
        .orderBy('timestamp', descending: true); // Latest orders first

    return ordersCollection.snapshots().map((snapshot) {
      return snapshot.docs.map((doc) {
        return Order(
          orderId: doc.id,
          orderDetails: doc.data()['details'] ?? 'No details available',
          customerName: doc.data()['customerName'] ?? 'No name available',
          totalAmount: (doc.data()['totalAmount'] ?? 0).toDouble(),
          orderNumber: doc.data()['orderNumber'] ?? 'No order number',
          paymentMethod: doc.data()['paymentMethod'] ?? 'No payment method',
          paymentStatus: doc.data()['paymentStatus'] ?? 'Pending',
          platformFee: (doc.data()['platformFee'] ?? 0.0).toDouble(),
          prices: List<double>.from(doc.data()['prices'] ?? []),
          quantities: List<int>.from(doc.data()['quantities'] ?? []),
          restaurantName: doc.data()['restaurantName'] ?? 'No restaurant name',
          status: doc.data()['status'] ?? 'Pending',
          subtotal: (doc.data()['subtotal'] ?? 0.0).toDouble(),
          timestamp: (doc.data()['timestamp'] as Timestamp).toDate(),
          items: List<String>.from(doc.data()['items'] ?? []),
          deliveryAddress: doc.data()['deliveryAddress'] ?? 'No delivery address',
        );
      }).toList();
    });
  }

  // Refresh orders by date range
  Future<void> refreshOrdersByDate(String restaurantId, DateTime startDate, DateTime endDate) async {
    try {
      var ordersCollection = FirebaseFirestore.instance
          .collection('restaurants')
          .doc(restaurantId)
          .collection('orders')
          .where('timestamp', isGreaterThanOrEqualTo: Timestamp.fromDate(startDate))
          .where('timestamp', isLessThanOrEqualTo: Timestamp.fromDate(endDate))
          .orderBy('timestamp', descending: true);

      var snapshot = await ordersCollection.get();

      ordersList.value = snapshot.docs.map((doc) {
        return Order(
          orderId: doc.id,
          orderDetails: doc.data()['details'] ?? 'No details available',
          customerName: doc.data()['customerName'] ?? 'No name available',
          totalAmount: (doc.data()['totalAmount'] ?? 0).toDouble(),
          orderNumber: doc.data()['orderNumber'] ?? 'No order number',
          paymentMethod: doc.data()['paymentMethod'] ?? 'No payment method',
          paymentStatus: doc.data()['paymentStatus'] ?? 'Pending',
          platformFee: (doc.data()['platformFee'] ?? 0.0).toDouble(),
          prices: List<double>.from(doc.data()['prices'] ?? []),
          quantities: List<int>.from(doc.data()['quantities'] ?? []),
          restaurantName: doc.data()['restaurantName'] ?? 'No restaurant name',
          status: doc.data()['status'] ?? 'Pending',
          subtotal: (doc.data()['subtotal'] ?? 0.0).toDouble(),
          timestamp: (doc.data()['timestamp'] as Timestamp).toDate(),
          items: List<String>.from(doc.data()['items'] ?? []),
          deliveryAddress: doc.data()['deliveryAddress'] ?? 'No delivery address',
        );
      }).toList();
    } catch (e) {
      print("Error fetching orders by date: $e");
    }
  }

  // Refresh orders method
  void refreshOrders(String restaurantId) {
    fetchOrders(restaurantId);
  }
}
