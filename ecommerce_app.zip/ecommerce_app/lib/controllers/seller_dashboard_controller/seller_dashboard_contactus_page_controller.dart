import 'package:get/get.dart';
import 'package:minibites/models/seller_dashboard_pages/seller_dashboard_contactus_page_model.dart';

class SellerDashboardContactusPageController extends GetxController {
  var contactForm = ContactFormModel(name: '', email: '', message: '').obs;

  void updateName(String name) {
    contactForm.update((form) {
      form?.name = name;
    });
  }

  void updateEmail(String email) {
    contactForm.update((form) {
      form?.email = email;
    });
  }

  void updateMessage(String message) {
    contactForm.update((form) {
      form?.message = message;
    });
  }

  void submitForm() {
    // Form submission logic
    print('Name: ${contactForm.value.name}');
    print('Email: ${contactForm.value.email}');
    print('Message: ${contactForm.value.message}');
  }
}
