import 'package:get/get.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class MenuController extends GetxController {
  var menuItems = <MenuItem>[].obs;
  var filteredItems = <MenuItem>[].obs;
  var menuCategories = <Category>[].obs; // Add this line

  Future<void> fetchMenuItemsForRestaurant(String restaurantId) async {
    try {
      final querySnapshot = await FirebaseFirestore.instance
          .collection('restaurants')
          .doc(restaurantId)
          .collection('menus')
          .get();

      menuItems.value = querySnapshot.docs.map((doc) => MenuItem.fromFirestore(doc)).toList();
      filteredItems.value = menuItems; // Initialize filteredItems with all items

      // Update categories
      updateCategories();
    } catch (e) {
      print("Error fetching menu items: $e");
    }
  }

  void searchMenuItems(String query) {
    if (query.isEmpty) {
      filteredItems.value = menuItems;
    } else {
      filteredItems.value = menuItems.where((item) {
        return item.name.toLowerCase().contains(query.toLowerCase());
      }).toList();
    }
  }

  void updateCategories() {
    // Create a set of unique categories from menuItems
    final uniqueCategories = <Category>{};
    for (var item in menuItems) {
      uniqueCategories.add(Category(name: item.category, imageUrl: item.imageUrl));
    }
    menuCategories.value = uniqueCategories.toList();
  }
}

class MenuItem {
  final String id;
  final String name;
  final double price;
  final double dealPrice;
  final String imageUrl;
  final String category;

  MenuItem({
    required this.id,
    required this.name,
    required this.price,
    required this.dealPrice,
    required this.imageUrl,
    required this.category,
  });

  factory MenuItem.fromFirestore(DocumentSnapshot doc) {
    var data = doc.data() as Map<String, dynamic>;
    return MenuItem(
      id: doc.id,
      name: data['menuName'] ?? '',
      price: (data['price'] ?? 0.0).toDouble(),
      dealPrice: (data['dealPrice'] ?? 0.0).toDouble(),
      imageUrl: data['menuImageUrl'] ?? '',
      category: data['category'] ?? '',
    );
  }
}

class Category {
  final String name;
  final String imageUrl;

  Category({
    required this.name,
    required this.imageUrl,
  });
}
