import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:get/get.dart';

class SellerDashboardRatingsController extends GetxController {
  final String sellerId;
  RxList<Review> reviews = RxList<Review>();

  SellerDashboardRatingsController({required this.sellerId});

  @override
  void onInit() {
    super.onInit();
    fetchReviews();
  }

  void fetchReviews() async {
    try {
      var snapshot = await FirebaseFirestore.instance
          .collection('restaurants')
          .where('sellerId', isEqualTo: sellerId)
          .get();

      reviews.clear();
      for (var doc in snapshot.docs) {
        var reviewsSnapshot = await FirebaseFirestore.instance
            .collection('restaurants')
            .doc(doc.id)
            .collection('reviews')
            .get();

        for (var reviewDoc in reviewsSnapshot.docs) {
          var review = Review.fromFirestore(reviewDoc);
          reviews.add(review);
        }
      }
    } catch (e) {
      print("Error fetching reviews: $e");
    }
  }
}

class Review {
  final String review;  // Updated from reviews to review (match Firestore field)
  final int rating;
  final DateTime createdAt;

  Review({required this.review, required this.rating, required this.createdAt});

  factory Review.fromFirestore(DocumentSnapshot doc) {
    var data = doc.data() as Map<String, dynamic>;
    return Review(
      review: data['review'] ?? 'No review',  // Match Firestore field 'review'
      rating: (data['rating'] as num).toInt(),
      createdAt: (data['createdAt'] as Timestamp).toDate(),
    );
  }
}

