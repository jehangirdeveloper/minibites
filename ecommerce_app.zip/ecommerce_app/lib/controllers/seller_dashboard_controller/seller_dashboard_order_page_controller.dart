import 'package:get/get.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:intl/intl.dart';
import 'package:minibites/models/MenuItem.dart'; // Import MenuItem for access to its properties

class SellerDashboardOrderPageController extends GetxController {
  RxList<Order> orders = <Order>[].obs;

  @override
  void onInit() {
    super.onInit();
    fetchOrders(); // Fetch orders when the controller initializes
  }

  // Fetch orders based on date range
  Future<void> fetchOrders({DateTime? startDate, DateTime? endDate}) async {
    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) return; // Handle user not signed in

      final sellerId = user.uid; // Current logged-in seller's ID
      final restaurantQuery = FirebaseFirestore.instance
          .collection('restaurants')
          .where('sellerId', isEqualTo: sellerId);

      final restaurantSnapshot = await restaurantQuery.get();
      final restaurantIds = restaurantSnapshot.docs.map((doc) => doc.id).toList();

      List<Order> allOrders = [];
      for (String restaurantId in restaurantIds) {
        // Fetch orders for each restaurant associated with this seller
        final ordersQuery = FirebaseFirestore.instance
            .collection('restaurants')
            .doc(restaurantId)
            .collection('orders')
            .orderBy('timestamp', descending: true); // Fetch orders sorted by timestamp

        // Apply date range filter if provided
        if (startDate != null && endDate != null) {
          ordersQuery
              .where('timestamp', isGreaterThanOrEqualTo: startDate)
              .where('timestamp', isLessThanOrEqualTo: endDate);
        }

        final ordersSnapshot = await ordersQuery.get();
        allOrders.addAll(ordersSnapshot.docs.map((doc) => Order.fromDocument(doc)).toList());
      }

      // Set fetched orders to the observable orders list
      orders.value = allOrders;
    } catch (e) {
      print("Error fetching orders: $e");
    }
  }

  double getSubTotalPrice(List<MenuItem> cartItems) {
    return cartItems.fold(0.0, (total, item) => total + (item.price * item.quantity));
  }

  Future<void> updateOrderStatus(String orderId, String newStatus) async {
    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) return; // Handle user not signed in

      final sellerId = user.uid; // Current logged-in seller's ID
      final restaurantQuery = FirebaseFirestore.instance
          .collection('restaurants')
          .where('sellerId', isEqualTo: sellerId);

      final restaurantSnapshot = await restaurantQuery.get();
      final restaurantIds = restaurantSnapshot.docs.map((doc) => doc.id).toList();

      for (String restaurantId in restaurantIds) {
        final ordersQuery = FirebaseFirestore.instance
            .collection('restaurants')
            .doc(restaurantId)
            .collection('orders')
            .where(FieldPath.documentId, isEqualTo: orderId)
            .limit(1);

        final ordersSnapshot = await ordersQuery.get();
        if (ordersSnapshot.docs.isNotEmpty) {
          final orderRef = ordersSnapshot.docs.first.reference;
          await orderRef.update({'status': newStatus});
        }
      }

      // Refresh the orders list after updating the status
      fetchOrders();
    } catch (e) {
      print("Error updating order status: $e");
    }
  }

  Future<void> updatePaymentStatus(String orderId, String newPaymentStatus) async {
    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) return; // Handle user not signed in

      final sellerId = user.uid; // Current logged-in seller's ID
      final restaurantQuery = FirebaseFirestore.instance
          .collection('restaurants')
          .where('sellerId', isEqualTo: sellerId);

      final restaurantSnapshot = await restaurantQuery.get();
      final restaurantIds = restaurantSnapshot.docs.map((doc) => doc.id).toList();

      for (String restaurantId in restaurantIds) {
        final ordersQuery = FirebaseFirestore.instance
            .collection('restaurants')
            .doc(restaurantId)
            .collection('orders')
            .where(FieldPath.documentId, isEqualTo: orderId)
            .limit(1);

        final ordersSnapshot = await ordersQuery.get();
        if (ordersSnapshot.docs.isNotEmpty) {
          final orderRef = ordersSnapshot.docs.first.reference;
          await orderRef.update({'paymentStatus': newPaymentStatus});
        }
      }

      // Refresh the orders list after updating the payment status
      fetchOrders();
    } catch (e) {
      print("Error updating payment status: $e");
    }
  }
}

class Order {
  final String id;
  final String orderNumber;
  final String restaurantName;
  final double totalAmount;
  final List<String> items;
  final List<int> quantities;
  final List<double> prices;
  final DateTime timestamp; // Changed from Timestamp to DateTime
  final String status; // Added status field
  final String paymentStatus; // Added payment status field

  Order({
    required this.id,
    required this.orderNumber,
    required this.restaurantName,
    required this.totalAmount,
    required this.items,
    required this.quantities,
    required this.prices,
    required this.timestamp, // Changed from Timestamp to DateTime
    required this.status, // Added status field
    required this.paymentStatus, // Added payment status field
  });

  // Convert DateTime to readable date
  String get formattedDate {
    final formatter = DateFormat('yyyy-MM-dd');
    return formatter.format(timestamp);
  }

  factory Order.fromDocument(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return Order(
      id: doc.id,
      orderNumber: data['orderNumber'] ?? '',
      restaurantName: data['restaurantName'] ?? '',
      totalAmount: (data['totalAmount'] as num).toDouble(),
      items: List<String>.from(data['items'] ?? []),
      quantities: List<int>.from(data['quantities'] ?? []),
      prices: List<double>.from(data['prices'] ?? []),
      timestamp: (data['timestamp'] as Timestamp).toDate(), // Convert Timestamp to DateTime
      status: data['status'] ?? '', // Added status field
      paymentStatus: data['paymentStatus'] ?? 'Unpaid', // Added payment status field
    );
  }
}
