import 'package:get/get.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:intl/intl.dart';

class SellerDashboardEarningsPageController extends GetxController {
  RxList<Order> orders = <Order>[].obs;

  @override
  void onInit() {
    super.onInit();
    fetchOrders();
  }

  /// Fetches all orders from Firestore for the authenticated seller's restaurants.
  Future<void> fetchOrders() async {
    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) return; // User is not signed in

      final sellerId = user.uid;
      final restaurantQuery = FirebaseFirestore.instance
          .collection('restaurants')
          .where('sellerId', isEqualTo: sellerId);

      final restaurantSnapshot = await restaurantQuery.get();
      final restaurantIds = restaurantSnapshot.docs.map((doc) => doc.id).toList();

      List<Order> allOrders = [];
      for (String restaurantId in restaurantIds) {
        final ordersSnapshot = await FirebaseFirestore.instance
            .collection('restaurants')
            .doc(restaurantId)
            .collection('orders')
            .orderBy('timestamp', descending: true) // Fetch latest orders first
            .get();

        allOrders.addAll(
          ordersSnapshot.docs.map((doc) => Order.fromDocument(doc)).toList(),
        );
      }

      // Sorting the orders in reverse chronological order and updating the list
      orders.value = allOrders;
    } catch (e) {
      print("Error fetching orders: $e");
    }
  }

  /// Fetches orders by a specific date range
  Future<void> fetchOrdersByDateRange(DateTime startDate, DateTime endDate) async {
    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) return; // User is not signed in

      final sellerId = user.uid;
      final restaurantQuery = FirebaseFirestore.instance
          .collection('restaurants')
          .where('sellerId', isEqualTo: sellerId);

      final restaurantSnapshot = await restaurantQuery.get();
      final restaurantIds = restaurantSnapshot.docs.map((doc) => doc.id).toList();

      List<Order> filteredOrders = [];
      for (String restaurantId in restaurantIds) {
        final adjustedEndDate = endDate.add(Duration(days: 1)); // Extend end date to include the full day

        final ordersSnapshot = await FirebaseFirestore.instance
            .collection('restaurants')
            .doc(restaurantId)
            .collection('orders')
            .where('timestamp', isGreaterThanOrEqualTo: Timestamp.fromDate(startDate))
            .where('timestamp', isLessThan: Timestamp.fromDate(adjustedEndDate)) // Use < operator to include end date
            .orderBy('timestamp', descending: true)  // Latest orders first
            .get();

        filteredOrders.addAll(
          ordersSnapshot.docs.map((doc) => Order.fromDocument(doc)).toList(),
        );
      }

      // Update the orders with filtered result
      orders.value = filteredOrders;
    } catch (e) {
      print("Error fetching orders by date range: $e");
    }
  }

  /// Updates the status of an order in Firestore.
  Future<void> updateOrderStatus(
      String restaurantId, String orderId, String newStatus) async {
    try {
      await FirebaseFirestore.instance
          .collection('restaurants')
          .doc(restaurantId)
          .collection('orders')
          .doc(orderId)
          .update({'status': newStatus});

      // Refetch orders if the status is not 'Done'
      if (newStatus != 'Done') {
        fetchOrders();
      }
    } catch (e) {
      print("Error updating order status: $e");
    }
  }

  /// Updates the payment status of an order in Firestore.
  Future<void> updatePaymentStatus(String orderId, String newPaymentStatus) async {
    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) return; // User is not signed in

      final sellerId = user.uid;
      final restaurantQuery = FirebaseFirestore.instance
          .collection('restaurants')
          .where('sellerId', isEqualTo: sellerId);

      final restaurantSnapshot = await restaurantQuery.get();
      final restaurantIds = restaurantSnapshot.docs.map((doc) => doc.id).toList();

      // Looping through restaurantIds to find and update the order
      for (String restaurantId in restaurantIds) {
        final ordersQuery = FirebaseFirestore.instance
            .collection('restaurants')
            .doc(restaurantId)
            .collection('orders')
            .where(FieldPath.documentId, isEqualTo: orderId)
            .limit(1)
            .get();

        final ordersSnapshot = await ordersQuery;
        if (ordersSnapshot.docs.isNotEmpty) {
          final orderRef = ordersSnapshot.docs.first.reference;
          await orderRef.update({'paymentStatus': newPaymentStatus});
        }
      }

      // Refetching the orders after updating payment status
      fetchOrders();
    } catch (e) {
      print("Error updating payment status: $e");
    }
  }

  /// Updates the payment method of an order in Firestore.
  Future<void> updatePaymentMethod(String orderId, String newPaymentMethod) async {
    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user == null) return; // User is not signed in

      final sellerId = user.uid;
      final restaurantQuery = FirebaseFirestore.instance
          .collection('restaurants')
          .where('sellerId', isEqualTo: sellerId);

      final restaurantSnapshot = await restaurantQuery.get();
      final restaurantIds = restaurantSnapshot.docs.map((doc) => doc.id).toList();

      // Looping through restaurantIds to find and update the order
      for (String restaurantId in restaurantIds) {
        final ordersQuery = FirebaseFirestore.instance
            .collection('restaurants')
            .doc(restaurantId)
            .collection('orders')
            .where(FieldPath.documentId, isEqualTo: orderId)
            .limit(1)
            .get();

        final ordersSnapshot = await ordersQuery;
        if (ordersSnapshot.docs.isNotEmpty) {
          final orderRef = ordersSnapshot.docs.first.reference;
          await orderRef.update({'paymentMethod': newPaymentMethod});
        }
      }

      // Refetching the orders after updating payment method
      fetchOrders();
    } catch (e) {
      print("Error updating payment method: $e");
    }
  }
}

/// Order model representing each order in Firestore.
class Order {
  final String orderId;
  final String restaurantId;
  final Timestamp timestamp;
  final String orderNumber;
  final String restaurantName;
  final List<String> items;
  final List<int> quantities;
  final double totalAmount;
  final double subtotal;
  String status;
  final String formattedDate;
  String paymentStatus;
  String paymentMethod; // New field for payment method

  Order({
    required this.orderId,
    required this.restaurantId,
    required this.timestamp,
    required this.orderNumber,
    required this.restaurantName,
    required this.items,
    required this.quantities,
    required this.totalAmount,
    required this.subtotal,
    this.status = 'Pending',
    required this.formattedDate,
    this.paymentStatus = 'Unpaid',
    this.paymentMethod = 'Bank Transfer', // Default payment method
  });

  /// Converts Firestore document to Order model.
  factory Order.fromDocument(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return Order(
      orderId: doc.id,
      restaurantId: data['restaurantId'] as String? ?? '',
      timestamp: data['timestamp'] as Timestamp,
      orderNumber: data['orderNumber'] as String? ?? '',
      restaurantName: data['restaurantName'] as String? ?? '',
      items: List<String>.from(data['items'] as List<dynamic>? ?? []),
      quantities: List<int>.from(data['quantities'] as List<dynamic>? ?? []),
      totalAmount: (data['totalAmount'] as num).toDouble(),
      subtotal: (data['subtotal'] as num).toDouble(),
      status: data['status'] as String? ?? 'Pending',
      paymentStatus: data['paymentStatus'] as String? ?? 'Unpaid',
      paymentMethod: data['paymentMethod'] as String? ?? 'Select Payment Method', // Fetch payment method from Firestore
      formattedDate: DateFormat.yMd().format((data['timestamp'] as Timestamp).toDate()),
    );
  }
}
