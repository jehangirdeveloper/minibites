import 'package:minibites/models/seller_dashboard_pages/seller_dashboard_mytransactions_page_model.dart';
import 'package:get/get.dart';

class SellerDashboardMytransactionsPageController extends GetxController {
  var transactions = <Transaction>[].obs;

  @override
  void onInit() {
    super.onInit();
    fetchTransactions();
  }

  void fetchTransactions() {
    // Dummy data for demonstration
    var transactionList = [
      Transaction(
        amount: '163.89',
        date: '2024-07-30 11:02:23',
        orderId: '2262',
        paymentMethod: 'credit',
        message: 'Commission Amount Credited for Order ID: 2262',
      ),
      Transaction(
        amount: '480.69',
        date: '2024-07-28 12:05:13',
        orderId: '2236',
        paymentMethod: 'credit',
        message: 'Commission Amount Credited for Order ID: 2236',
      ),
      Transaction(
        amount: '350.9',
        date: '2024-07-28 12:05:13',
        orderId: '2235',
        paymentMethod: 'credit',
        message: 'Commission Amount Credited for Order ID: 2235',
      ),
    ];

    transactions.assignAll(transactionList);
  }
}
