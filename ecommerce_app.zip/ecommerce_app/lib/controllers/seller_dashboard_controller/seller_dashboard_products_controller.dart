import 'package:get/get.dart';
import 'package:minibites/models/seller_dashboard_pages/seller_dashboard_products_model.dart';

class ProductController extends GetxController {
  var products = <Product>[].obs;

  @override
  void onInit() {
    super.onInit();
    fetchProducts();
  }

  void fetchProducts() {
    var productResult = [
      Product(
        name: 'Black Coffee',
        price: '200.0',
        imageUrl: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSOXnHgS11MjP0xoI7sD-EO55uRCZNlBHyp0g&s',
        isAvailable: true,
      ),
      Product(
        name: 'Zinger Paratha Roll',
        price: '170.0',
        originalPrice: '189',
        imageUrl: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSyVUPeYNnyJs7tWQ1KTxlJ2IE305XNMYPLfg&s',
        isAvailable: false,
      ),
      Product(
        name: 'Crispy Zinger Burger',
        price: '148.99',
        originalPrice: '150',
        imageUrl: 'https://tiermaker.com/images/chart/chart/kfc-menu-polska-483144/zingerpng.png',
        isAvailable: true,
      ),
    ];
    products.assignAll(productResult);
  }

  void toggleAvailability(int index) {
    var product = products[index];
    product.isAvailable = !product.isAvailable;
    products[index] = product;
  }

  void deleteProduct(int index) {
    products.removeAt(index);
  }

  void editProduct(int index, Product newProduct) {
    products[index] = newProduct;
  }
}
