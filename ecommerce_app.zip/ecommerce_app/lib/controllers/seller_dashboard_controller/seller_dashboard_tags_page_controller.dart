import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:minibites/models/seller_dashboard_pages/seller_dashboard_tags_page_model.dart';

class SellerDashboardTagsPageController extends GetxController {
  var tags = <Tag>[].obs;
  var tagController = TextEditingController();

  void addTag() {
    final String tagName = tagController.text;
    if (tagName.isNotEmpty) {
      tags.add(Tag(tagName));
      tagController.clear();
    }
  }

  void deleteTag(int index) {
    tags.removeAt(index);
  }
}
