import 'package:get/get.dart';
import 'package:flutter/material.dart';
import 'package:minibites/models/seller_dashboard_pages/seller_dashboard_change_language_page_model.dart';

class SellerDashboardChangeLanguagePageController extends GetxController {
  var selectedLocale = Locale('en').obs;

  void changeLanguage(String code) {
    selectedLocale.value = Locale(code);
    Get.updateLocale(selectedLocale.value);
  }
}
