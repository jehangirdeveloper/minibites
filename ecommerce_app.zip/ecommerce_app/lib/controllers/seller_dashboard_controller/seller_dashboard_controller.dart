import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:get/get.dart';

class SellerDashboardController extends GetxController {
  String _selectedRestaurantId = '';
  var startDate = DateTime.now().obs;
  var endDate = DateTime.now().obs;

  var orders = 5.obs;
  var products = 20.obs;
  var tags = 0.obs;
  var rating = 0.0.obs;
  var ratingCount = 0.obs;
  var soldOutProducts = 0.obs;
  var lowStockProducts = 0.obs;
  var earnings = 0.obs;

  var salesData = <double>[600.0, 500.0, 400.0, 300.0, 300.0, 400.0, 600.0].obs;

  var categoryData = {
    'Coffee': 5,
    'Burgers and Meals': 4,
    'Wraps': 8,
  }.obs;

  @override
  void onInit() {
    super.onInit();
    fetchRestaurantId();
  }

  // Fetch the restaurantId from Firestore
  Future<void> fetchRestaurantId() async {
    var user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      try {
        var documentSnapshot = await FirebaseFirestore.instance
            .collection('restaurants')
            .doc(user.uid)
            .get();
        if (documentSnapshot.exists) {
          _selectedRestaurantId = documentSnapshot.data()?['restaurantId'] ?? '';
          update(); // Update the UI if restaurantId fetched
        } else {
          print("Restaurant ID not found for this user.");
        }
      } catch (e) {
        print("Error fetching restaurantId: $e");
      }
    } else {
      print("No user is logged in.");
    }
  }

  String get selectedRestaurantId => _selectedRestaurantId;
}
