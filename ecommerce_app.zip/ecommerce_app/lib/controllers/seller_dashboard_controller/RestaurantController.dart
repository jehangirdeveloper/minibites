import 'package:get/get.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'dart:io';
import 'package:path/path.dart' as path;

class RestaurantController extends GetxController {
  // Restaurant related fields
  var restaurantName = ''.obs;
  var category = ''.obs;
  var imageUrl = ''.obs;
  var restaurantId = ''.obs;
  var openingTime = ''.obs;  // New field for opening time
  var closingTime = ''.obs;  // New field for closing time
  var country = ''.obs;  // New field for country
  var city = ''.obs;     // New field for city

  // Menu related fields
  var menuItems = <MenuItem>[].obs;  // Observable list of menu items
  var filteredMenuItems = <MenuItem>[].obs; // Filtered menu items
  var menuName = ''.obs;
  var menuPrice = RxDouble(0.0);
  var menuImageUrl = ''.obs;

  // Search related field
  var searchQuery = ''.obs;

  File? imageFile;
  File? menuImageFile;

  @override
  void onInit() {
    super.onInit();
    // When searchQuery changes, filter menu items
    ever(searchQuery, (query) {
      filterMenuItems(query);
    });
  }

  // Method to fetch restaurant details from Firestore
  void fetchRestaurantDetails(String restaurantId) async {
    try {
      DocumentSnapshot doc = await FirebaseFirestore.instance
          .collection('restaurants')
          .doc(restaurantId)
          .get();

      if (doc.exists) {
        restaurantName.value = doc['name'];  // Assuming your restaurant document has a 'name' field
        imageUrl.value = doc['imageUrl'] ?? '';  // Assuming your restaurant document has an 'imageUrl' field
        openingTime.value = doc['openingTime'] ?? '';  // Fetch opening time
        closingTime.value = doc['closingTime'] ?? '';  // Fetch closing time
        country.value = doc['country'] ?? '';  // Fetch country
        city.value = doc['city'] ?? '';        // Fetch city
      } else {
        restaurantName.value = 'Restaurant not found';
        imageUrl.value = '';  // Clear the image URL if the restaurant is not found
        openingTime.value = '';  // Clear opening time
        closingTime.value = '';  // Clear closing time
        country.value = '';
        city.value = '';
      }
    } catch (e) {
      restaurantName.value = 'Error fetching restaurant details';
      imageUrl.value = '';  // Clear the image URL in case of an error
      openingTime.value = '';  // Clear opening time
      closingTime.value = '';  // Clear closing time
      country.value = '';
      city.value = '';
    }
  }

  // Method to filter menu items based on search query
  void filterMenuItems(String query) {
    if (query.isEmpty) {
      filteredMenuItems.value = menuItems;
    } else {
      filteredMenuItems.value = menuItems.where((item) {
        return item.name.toLowerCase().contains(query.toLowerCase());
      }).toList();
    }
  }

  // Restaurant methods
  void setRestaurantName(String name) {
    restaurantName.value = name;
  }

  void setCategory(String cat) {
    category.value = cat;
  }

  void setImage(File image) {
    imageFile = image;
  }

  void setOpeningTime(String time) {
    openingTime.value = time;  // Setter for opening time
  }

  void setClosingTime(String time) {
    closingTime.value = time;  // Setter for closing time
  }

  void setCountry(String countryName) {
    country.value = countryName;  // Setter for country
  }

  void setCity(String cityName) {
    city.value = cityName;  // Setter for city
  }

  Future<void> uploadImageAndGetUrl() async {
    if (imageFile != null) {
      try {
        String fileName = path.basename(imageFile!.path);
        Reference storageReference = FirebaseStorage.instance.ref().child('restaurant_images/$fileName');
        UploadTask uploadTask = storageReference.putFile(imageFile!);
        TaskSnapshot taskSnapshot = await uploadTask;
        String downloadUrl = await taskSnapshot.ref.getDownloadURL();
        imageUrl.value = downloadUrl;
      } catch (e) {
        print("Error uploading image: $e");
      }
    }
  }

  Future<void> submitForm(String sellerId, RestaurantController restaurant, dynamic doc) async {
    if (restaurant.restaurantName.isNotEmpty && category.value.isNotEmpty) {
      try {
        await FirebaseFirestore.instance.collection('restaurants').add({
          'sellerId': sellerId,
          'name': restaurant.restaurantName.value,
          'category': category.value,
          'imageUrl': imageUrl.value,
          'openingTime': openingTime.value,  // Add opening time to Firestore
          'closingTime': closingTime.value,  // Add closing time to Firestore
          'country': country.value, // Add country to Firestore
          'city': city.value,       // Add city to Firestore
          // Add other restaurant details
        });

        restaurantId.value = doc.id;

        restaurantName.value = '';
        category.value = '';
        imageUrl.value = '';
        openingTime.value = '';  // Clear opening time
        closingTime.value = '';  // Clear closing time
        country.value = ''; // Clear country
        city.value = '';    // Clear city
        imageFile = null;
      } catch (e) {
        print("Error saving data to Firestore: $e");
      }
    } else {
      print("Restaurant name or category is empty");
    }
  }

  // Method to add restaurant
  Future<void> addRestaurant(String sellerId, String name, String category, String imageUrl, String openingTime, String closingTime, String country, String city) async {
    try {
      var docRef = await FirebaseFirestore.instance.collection('restaurants').add({
        'sellerId': sellerId,
        'name': name,
        'category': category,
        'imageUrl': imageUrl,
        'openingTime': openingTime,  // Save opening time
        'closingTime': closingTime,  // Save closing time
        'country': country, // Save country
        'city': city,       // Save city
      });

      restaurantId.value = docRef.id;

      print("Restaurant added to Firestore.");
    } catch (e) {
      print("Error adding restaurant: $e");
    }
  }

  // Menu methods
  void setMenuName(String name) {
    menuName.value = name;
  }

  void setMenuPrice(double price) {
    menuPrice.value = price;
  }

  void setMenuImage(File image) {
    menuImageFile = image;
  }

  Future<void> uploadMenuImageAndGetUrl() async {
    if (menuImageFile != null) {
      try {
        String fileName = path.basename(menuImageFile!.path);
        Reference storageReference = FirebaseStorage.instance.ref().child('menu_images/$fileName');
        UploadTask uploadTask = storageReference.putFile(menuImageFile!);
        TaskSnapshot taskSnapshot = await uploadTask;
        String downloadUrl = await taskSnapshot.ref.getDownloadURL();
        menuImageUrl.value = downloadUrl;
      } catch (e) {
        print("Error uploading menu image: $e");
      }
    }
  }

  Future<void> submitMenuForm(String name, double price, File menuImage) async {
    if (name.isNotEmpty && price > 0 && restaurantId.value.isNotEmpty) {
      try {
        menuName.value = name;
        menuPrice.value = price;
        menuImageFile = menuImage;

        await uploadMenuImageAndGetUrl();

        await FirebaseFirestore.instance
            .collection('restaurants')
            .doc(restaurantId.value)
            .collection('menus')
            .add({
          'menuName': menuName.value,
          'price': menuPrice.value,
          'menuImageUrl': menuImageUrl.value,
        });

        menuName.value = '';
        menuPrice.value = 0.0;
        menuImageUrl.value = '';
        menuImageFile = null;
      } catch (e) {
        print("Error saving menu data to Firestore: $e");
      }
    } else {
      print("Menu name, price, or restaurant ID is empty");
    }
  }

  // Fetch Menu Items
  Future<void> fetchMenuItemsForRestaurant(String restaurantId) async {
    try {
      var snapshot = await FirebaseFirestore.instance
          .collection('restaurants')
          .doc(restaurantId)
          .collection('menus')
          .get();

      menuItems.clear();
      for (var doc in snapshot.docs) {
        menuItems.add(MenuItem.fromFirestore(doc));
      }

      // Update filtered menu items after fetching
      filterMenuItems(searchQuery.value);
    } catch (e) {
      print("Error fetching menu items: $e");
    }
  }
}

class MenuItem {
  String name;
  double price;
  String imageUrl;

  MenuItem({
    required this.name,
    required this.price,
    required this.imageUrl,
  });

  factory MenuItem.fromFirestore(DocumentSnapshot doc) {
    return MenuItem(
      name: doc['menuName'],
      price: doc['price'],
      imageUrl: doc['menuImageUrl'],
    );
  }
}
