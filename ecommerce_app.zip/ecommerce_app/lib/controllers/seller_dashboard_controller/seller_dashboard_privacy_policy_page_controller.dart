import 'package:get/get.dart';
import 'package:minibites/models/seller_dashboard_pages/seller_dashboard_privacy_policy_page_model.dart';

class SellerDashboardPrivacyPolicyPageController extends GetxController {
  var privacyPolicy = PrivacyPolicyModel(
      'Your Privacy Policy content goes here. Please replace this text with your actual privacy policy details. Make sure to explain how you collect, use, and protect user data. You may also include details about data sharing and user rights.'
  ).obs;
}
