import 'package:flutter/material.dart';

const tPrimaryColor = Colors.amber;
const tSecondaryColor = Colors.indigo;
const tAccentColor = Colors.lightBlue;

const tWhiteColor = Colors.white;
const tDarkColor = Colors.black38;
const tCardBgColor = Colors.indigoAccent;

const tOnBoardingPage1Color = Colors.white10;
const tOnBoardingPage2Color = Colors.white12;

