import 'package:flutter/material.dart';

const String tOnBoardingTitle1= "Build Awesome Apps";
const String tOnBoardingTitle2= "Build Awesome Apps";