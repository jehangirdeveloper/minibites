
const String tOnBoardingImage1 = "images/foodlogo.png";
const String tOnBoardingImage2 = "images/foodlogo.png";