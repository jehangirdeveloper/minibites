import 'package:minibites/controllers/seller_multi_step_form_controller.dart';
import 'package:minibites/views/screens/seller_dashboard/seller_dashboard.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:geolocator/geolocator.dart';

class SellerMultiStepFormScreen extends StatelessWidget {
  final SellerMultiStepFormController controller = Get.put(SellerMultiStepFormController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        title: Text('Tell us about your business'),
      ),
      body: Obx(() {
        return SingleChildScrollView(
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: Text(
                  'This information will be shown on the app so that customers can search and contact you in case they have any questions.',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.black,
                    // fontFamily: 'Orbitron-Bold', // Apne font family ka naam yahan daalein
                  ),
                ),
              ),
              SizedBox(
                height: MediaQuery.of(context).size.height - 120, // Adjust height as needed
                child: Stepper(
                  currentStep: controller.currentStep.value,
                  onStepContinue: () {
                    if (controller.currentStep.value == 0 && !controller.validateStep1()) {
                      Get.snackbar('Error', 'Please fill all fields before proceeding');
                      return;
                    }
                    controller.nextStep();
                  },
                  onStepCancel: controller.previousStep,
                  steps: [
                    Step(
                      title: Text('Step 1'),
                      content: Column(
                        children: [
                          TextField(
                            onChanged: (value) => controller.businessName.value = value,
                            decoration: InputDecoration(
                              labelText: 'Your Business Name',
                              hintText: 'Enter your business name',
                            ),
                          ),
                          TextField(
                            onChanged: (value) => controller.businessType.value = value,
                            decoration: InputDecoration(
                              labelText: 'Business Type',
                              hintText: 'Enter your business type',
                            ),
                          ),
                          TextField(
                            onChanged: (value) => controller.businessCategory.value = value,
                            decoration: InputDecoration(
                              labelText: 'Business Category',
                              hintText: 'Enter your business category',
                            ),
                          ),
                          TextField(
                            onChanged: (value) => controller.branches.value = value,
                            decoration: InputDecoration(
                              labelText: 'Branches',
                              hintText: 'Enter number of branches',
                            ),
                          ),
                          TextField(
                            onChanged: (value) => controller.phone.value = value,
                            decoration: InputDecoration(
                              labelText: 'Phone Number',
                              hintText: 'Enter your phone number',
                            ),
                          ),
                        ],
                      ),
                      isActive: controller.currentStep.value == 0,
                      state: controller.currentStep.value > 0 ? StepState.complete : StepState.indexed,
                    ),
                    Step(
                      title: Text('Step 2'),
                      content: Column(
                        children: [
                          Padding(
                            padding: const EdgeInsets.all(16.0),
                            child: Text(
                              'Where is your business located?',
                              style: TextStyle(fontSize: 18),
                            ),
                          ),
                          SizedBox(
                            height: 300,
                            child: GoogleMap(
                              onMapCreated: (GoogleMapController googleMapController) {
                                controller.mapController = googleMapController;
                                controller.updateMapLocation();
                              },
                              initialCameraPosition: CameraPosition(
                                target: controller.selectedLocation.value,
                                zoom: 10,
                              ),
                              markers: {
                                Marker(
                                  markerId: MarkerId('selected-location'),
                                  position: controller.selectedLocation.value,
                                  draggable: true,
                                  onDragEnd: (newPosition) {
                                    controller.updateLocation(newPosition);
                                  },
                                ),
                              },
                              onTap: (position) {
                                controller.updateLocation(position);
                              },
                            ),
                          ),
                          SizedBox(height: 16),
                          TextField(
                            decoration: InputDecoration(
                              labelText: 'Enter Your Manual Address',
                              hintText: 'Enter address here',
                              border: OutlineInputBorder(),
                            ),
                            onChanged: (value) {
                              controller.updateAddress(value);
                            },
                          ),
                          SizedBox(height: 16),

                          SizedBox(height: 16),
                          DropdownButton<String>(
                            value: controller.selectedProvince.value.isEmpty
                                ? null
                                : controller.selectedProvince.value,
                            hint: Text('Select Province'),
                            onChanged: (String? newValue) {
                              if (newValue != null) {
                                controller.updateProvince(newValue);
                              }
                            },
                            items: <String>[
                              'Punjab',
                              'Sindh',
                              'Khyber Pakhtunkhwa',
                              'Balochistan'
                            ].map<DropdownMenuItem<String>>((String value) {
                              return DropdownMenuItem<String>(
                                value: value,
                                child: Text(value),
                              );
                            }).toList(),
                          ),
                          if (controller.selectedProvince.value.isNotEmpty)
                            DropdownButton<String>(
                              value: controller.selectedCity.value.isEmpty
                                  ? null
                                  : controller.selectedCity.value,
                              hint: Text('Select City'),
                              onChanged: (String? newValue) {
                                if (newValue != null) {
                                  controller.updateCity(newValue);
                                }
                              },
                              items: <String>[
                                if (controller.selectedProvince.value == 'Punjab') ...[
                                  'Lahore',
                                  'Attock City',
                                  'Faisalabad',
                                  'Rawalpindi',
                                  'Islamabad',
                                  'Multan',
                                  'Murree',
                                ],
                                if (controller.selectedProvince.value == 'Sindh') ...[
                                  'Karachi',
                                  'Hyderabad',
                                  'Sukkur'
                                ],
                                if (controller.selectedProvince.value == 'Khyber Pakhtunkhwa') ...[
                                  'Peshawar',
                                  'Mardan',
                                  'Abbottabad'
                                ],
                                if (controller.selectedProvince.value == 'Balochistan') ...[
                                  'Quetta',
                                  'Gwadar',
                                  'Khuzdar'
                                ],
                              ].map<DropdownMenuItem<String>>((String value) {
                                return DropdownMenuItem<String>(
                                  value: value,
                                  child: Text(value),
                                );
                              }).toList(),
                            ),
                        ],
                      ),
                      isActive: controller.currentStep.value == 1,
                      state: controller.currentStep.value > 1 ? StepState.complete : StepState.indexed,
                    ),
                    Step(
                      title: Text('Step 3'),
                      content: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Padding(
                            padding: const EdgeInsets.all(15.0),
                            child: Text(
                              'The legal stuff',
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                          SizedBox(height: 1),
                          Padding(
                            padding: const EdgeInsets.all(16.0),
                            child: Text(
                              'We need to verify your business.',
                              style: TextStyle(fontSize: 16),
                            ),
                          ),
                          SizedBox(height: 1),
                          ListTile(
                            title: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                SizedBox(height: 1),
                                Text('Is your business registered with Pakistan\'s Federal Bureau of Revenue?'),
                                SizedBox(height: 8), // Thoda space add karne ke liye
                                Obx(() {
                                  return Row(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: [
                                      Row(
                                        children: [
                                          Radio<bool>(
                                            value: true,
                                            groupValue: controller.isRegisteredWithFbr.value,
                                            onChanged: (value) => controller.isRegisteredWithFbr.value = value!,
                                          ),
                                          Text('Yes'),
                                        ],
                                      ),
                                      SizedBox(width: 20), // Yes aur No ke darmiyan gap dene ke liye
                                      Row(
                                        children: [
                                          Radio<bool>(
                                            value: false,
                                            groupValue: controller.isRegisteredWithFbr.value,
                                            onChanged: (value) => controller.isRegisteredWithFbr.value = value!,
                                          ),
                                          Text('No'),
                                        ],
                                      ),
                                    ],
                                  );
                                }),
                              ],
                            ),
                          ),
                        ],
                      ),
                      isActive: controller.currentStep.value == 2,
                      state: controller.currentStep.value > 2 ? StepState.complete : StepState.indexed,
                    ),
                    Step(
                      title: Text('Step 4'),
                      content: Column(
                        children: [
                          Padding(
                            padding: const EdgeInsets.all(1.0),
                            child: Text(
                              'Add your bank details to receive payments',
                              style: TextStyle(fontSize: 20, color: Colors.black),
                              textAlign: TextAlign.left,
                            ),
                          ),
                          TextField(
                            onChanged: (value) => controller.bankName.value = value,
                            decoration: InputDecoration(
                              labelText: 'Bank Name',
                            ),
                          ),
                          TextField(
                            onChanged: (value) => controller.bankAccountOwner.value = value,
                            decoration: InputDecoration(
                              labelText: 'Bank Account Owner/Title',
                            ),
                          ),
                          TextField(
                            onChanged: (value) => controller.AccountNumber.value = value,
                            decoration: InputDecoration(
                              labelText: 'Account Number',
                            ),
                          ),
                        ],
                      ),
                      isActive: controller.currentStep.value == 3,
                      state: controller.currentStep.value > 3 ? StepState.complete : StepState.indexed,
                    ),
                    Step(
                      title: Text('Step 5'),
                      content: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Plans That Work For You:',
                            style: TextStyle(fontSize: 18),
                          ),
                          SizedBox(height: 10),
                          Text(
                            'How do you want to receive the orders?',
                            style: TextStyle(fontSize: 17),
                          ),
                          Row(
                            children: [
                              Radio(
                                value: 'Your Android Device',
                                groupValue: controller.selectedOption.value,
                                onChanged: (value) {
                                  controller.selectedOption.value = value as String;
                                },
                              ),
                              Text('Your Android Device'),
                            ],
                          ),
                          SizedBox(height: 10), // Buttons ke beech mein space
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween, // Space between buttons
                            children: [
                              TextButton(
                                onPressed: () {
                                  // Back button action
                                  if (controller.currentStep.value > 0) {
                                    controller.currentStep.value--;
                                  }
                                },
                                child: Text('Back'),
                                style: TextButton.styleFrom(
                                  foregroundColor: Colors.white,
                                  backgroundColor: Colors.blue,
                                  minimumSize: Size(130, 36),
                                  padding: EdgeInsets.symmetric(horizontal: 16),
                                  shape: const RoundedRectangleBorder(
                                    borderRadius: BorderRadius.all(Radius.circular(2)),
                                  ),
                                ),
                              ),
                              ElevatedButton(
                                onPressed: () {
                                  Get.to(()=>SellerDashboard());
                                },
                                child: Text('Save & Continue'),
                                style: ElevatedButton.styleFrom(
                                  foregroundColor: Colors.white,
                                  backgroundColor: Colors.blue,
                                  minimumSize: Size(88, 36),
                                  padding: EdgeInsets.symmetric(horizontal: 16),
                                  shape: const RoundedRectangleBorder(
                                    borderRadius: BorderRadius.all(Radius.circular(2)),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                      isActive: controller.currentStep.value == 4,
                      state: controller.currentStep.value > 4 ? StepState.complete : StepState.indexed,
                    ),
                  ],
                  controlsBuilder: (BuildContext context, ControlsDetails details) {
                    return Row(
                      children: <Widget>[
                        if (controller.currentStep.value < 4)
                          ElevatedButton(
                            onPressed: details.onStepContinue,
                            child: Text('Next'),
                            style: ElevatedButton.styleFrom(
                              foregroundColor: Colors.white,
                              backgroundColor: Colors.blue,
                              minimumSize: Size(88, 36),
                              padding: EdgeInsets.symmetric(horizontal: 16),
                              shape: const RoundedRectangleBorder(
                                borderRadius: BorderRadius.all(Radius.circular(2)),
                              ),
                            ),
                          ),
                        SizedBox(width: 8), // Space between Next and Back buttons
                        if (controller.currentStep.value > 0 && controller.currentStep.value < 4) // Step 5 ke liye back button disable
                          TextButton(
                            onPressed: details.onStepCancel,
                            child: Text('Back'),
                            style: TextButton.styleFrom(
                              foregroundColor: Colors.white,
                              backgroundColor: Colors.blue,
                              minimumSize: Size(88, 36),
                              padding: EdgeInsets.symmetric(horizontal: 16),
                              shape: const RoundedRectangleBorder(
                                borderRadius: BorderRadius.all(Radius.circular(2)),
                              ),
                            ),
                          ),
                      ],
                    );
                  },
                ),
              ),
            ],
          ),
        );
      }),
    );
  }
}
