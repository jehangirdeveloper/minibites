import 'dart:convert'; // For jsonEncode
import 'package:flutter/cupertino.dart';
import 'package:http/http.dart' as http;
import 'package:googleapis_auth/auth_io.dart' as auth;

class NotificationService {
  static Future<String> getAccessToken() async {
    final serviceAccountJson = {
      "type": "service_account",
      "project_id": "minibites-91bf9",
      "private_key_id": "3a098fef6636443d1c7a444b0f671918965395d7",
      "private_key": "-----BEGIN PRIVATE KEY-----\nMIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQCyP5+F11GCE9sj\n6nam+c6dVXWA9i810y0AI9hzSGZ9wkD+c9BqNsSKLOfWevrUrROD9SB3KxeOx29Y\nWwz0DsiEeiEEi3Gl6DLHB7TNMfNANRBnfNigaoKHRjvbJgvMWZRw0Tpu9gaM89ob\nN58CdGbiy1F3ies08KX9nZAHn4VJFHT3ZJYW0pyxY3Vhp7VLnQSee1I5m0/M/b4x\n3qOiZVyCkkDiaNRAvV+wb0mIW9QSdaBSx4mEXL7Qu5PpD7e5gzv96LjTdtWTiDF1\nfbig3uU2AjXyxGGQoeb5WkDzY7KzylGSvEXmvC++bKK/7JraCqx3RBfzzAwtderU\nKKDH7c49AgMBAAECggEAElQB8GZxOl2VzyXc8PLnSJzAshO+S3vNGQJWj5YOedhn\nS/K3J7C9eVLAPPjUwVkRlGQ4ZCCBcdw2agCkvpSlkB+ptPispSlQzU/Qyreb4kqC\nhw2ajbYd+VBit7g8BtVgMtCEwGOaTVSGpP1NY5h5+tB6rj63eXBUNRWGOY5wy1B7\n+qKCALyJ4EoL5s8P6hjC0NLjoU2MAWkIs8/Q41WQ+dZwsoo/7UuGy0VoSWaIIs7i\nPJrahNxWR6MkfHkNL2YwOW+gHoYoamvvQ1S/OZq00lyZYvlffsycdgFoJg0DqTfw\nIH4dVZi9clslIHbTHPvB0GOIe9ukdioLzqwbFCoE6QKBgQDb4oAF8NmzvQ5qeQYm\nLpNvw81SDU6BRv2cQUidXEHZk18TUk3I/9YCJ0SAhxucWX3p0CbIAmDtRwPaQWBD\nY7TjGPZKuIXwR6B+SDSj7B5tskT8MFWVQvTYbZ79XTW/qdf4el+Uei/fklug9yA8\nBYFXXFH0AMY+m8hfUT7B2Rrh5QKBgQDPhnFzUJDwSvqmQv/XAIUUDGjJOUuNBalv\n1UVk7Y8dG5zORITAEjUPOopuLg56lvT+t//ZBkIX4EKXFwVaArC9S4/HiSWR74Lt\nKriHmcXHVkADXZl4e61LOq1OfbyZtTLLC+lTiPrvqpOdWJ4xCp57LKeXZKwUSxpl\nDGjP1NhVeQKBgBkE565FXnAOJfLFfIahrBL+g4E/lFwvWLIL15hYJAH+u8W2CrXB\nLnemQiwhs2mR4TrWfWMqqh61guG1qJ9iW/WvJG8SGeNiMwfLbXntZvTyYNkVItfN\n+5AYwQtxLKl3SOSz/+YkFQhqXdSt6dQKiFIJZiXOZMBA94ao9uwVqPJlAoGBAKEm\nubreeW7gCrxJkvqWwMDM0iJQh8a++tCJQRYbE+N6qc3Tj3LHsMRepVjiEwRHbYDP\nybHyFikMUSmbCuDW7gBRSRmd+rrUz0r0vc8vLlKZO6RhbugMwomEy0gEhAyolQTv\n/wSLfrHWOEMbqdxTbrYf+xSpbKdlmt2VQV8C3euhAoGBAIGyD7z6urxImER+7ATz\n51HwLwlDYzSNr98+eEWPmSAZ9Q7PbBWzDtO1JRecQEIZi3TIVv6f93pgrZvrg9Bi\nBQEjN7Ydk33Pdzt3gdbS9CEeMM9nUlQTHlXdAhxEveCQraogkc6cSyO7ejDqgiQR\n0WC2B0Zh9dF977421pJyf/lV\n-----END PRIVATE KEY-----\n",
      "client_email": "pushnotification@minibites-91bf9.iam.gserviceaccount.com",
      "client_id": "100487974801778873353",
      "auth_uri": "https://accounts.google.com/o/oauth2/auth",
      "token_uri": "https://oauth2.googleapis.com/token",
      "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
      "client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/pushnotification%40minibites-91bf9.iam.gserviceaccount.com",
      "universe_domain": "googleapis.com"
    };

    List<String> scopes = [
      "https://www.googleapis.com/auth/userinfo.email",
      "https://www.googleapis.com/auth/firebase.database",
      "https://www.googleapis.com/auth/firebase.messaging",
    ];

    try {
      // Get client and access credentials
      final client = await auth.clientViaServiceAccount(
        auth.ServiceAccountCredentials.fromJson(serviceAccountJson),
        scopes,
      );

      final credentials = await auth.obtainAccessCredentialsViaServiceAccount(
        auth.ServiceAccountCredentials.fromJson(serviceAccountJson),
        scopes,
        client,
      );

      client.close();

      return credentials.accessToken.data ?? ''; // Ensure non-null return
    } catch (e) {
      print("Error getting access token: $e");
      return ''; // Return an empty string on error
    }
  }

  static Future<void> sendNotificationToSeller(String deviceToken, BuildContext context, String tripID) async {
    final String serverKey = await getAccessToken();
    final String endpointFirebaseCloudMessaging = 'https://fcm.googleapis.com/v1/projects/minibites-91bf9/messages:send';

    final notificationPayload = jsonEncode({
      "message": {
        "token": deviceToken,
        "notification": {
          "title": "New Order Notification",
          "body": "A buyer has placed a new order with ID: $tripID",
        },
      },
    });

    try {
      // Send the request
      final response = await http.post(
        Uri.parse(endpointFirebaseCloudMessaging),
        headers: {
          "Authorization": "Bearer $serverKey",
          "Content-Type": "application/json",
        },
        body: notificationPayload,
      );

      if (response.statusCode == 200) {
        print("Notification sent successfully!");
      } else {
        print("Failed to send notification: ${response.body}");
      }
    } catch (e) {
      print("Error sending notification: $e");
    }
  }
}
