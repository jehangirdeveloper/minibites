import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:minibites/controllers/buyer_verify_email_controller.dart';
import 'package:minibites/views/screens/buyer_dashboard/buyer_dashboard.dart';

class BuyerEmailVerificationScreen extends StatefulWidget {
  @override
  _BuyerEmailVerificationScreenState createState() => _BuyerEmailVerificationScreenState();
}

class _BuyerEmailVerificationScreenState extends State<BuyerEmailVerificationScreen> {
  final BuyerVerifyEmailController controller = Get.put(BuyerVerifyEmailController());
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  bool _isCheckingVerification = false;

  @override
  void initState() {
    super.initState();
    _checkEmailVerification();
  }

  Future<void> _checkEmailVerification() async {
    var user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      // Periodically check if email is verified
      while (user != null && !user.emailVerified) {
        await Future.delayed(Duration(seconds: 3)); // Delay for checking periodically
        await user.reload();
        user = FirebaseAuth.instance.currentUser;
        if (user != null && user.emailVerified) {
          // Email is verified, redirect to SellerMultiStepFormScreen
          Get.offAll(() => BuyerDashboard());
          break;
        }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final screenSize = MediaQuery.of(context).size;
    final width = screenSize.width;
    final height = screenSize.height;

    return Scaffold(
      body: Padding(
        padding: EdgeInsets.all(width * 0.04),
        child: Form(
          key: _formKey,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.email, size: width * 0.25, color: Colors.indigo),
              SizedBox(height: height * 0.03),
              Text(
                'To verify your account, click the link we sent to your Email Address',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: width * 0.045),
              ),
              Obx(() => Text(
                controller.email.value,
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: width * 0.05),
                textAlign: TextAlign.center,
              )),
              SizedBox(height: height * 0.03),
              Text(
                'If you can’t see it, check your spam folder.',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: width * 0.045),
              ),
              SizedBox(height: height * 0.03),
              ElevatedButton(
                onPressed: () async {
                  if (_formKey.currentState?.validate() ?? false) {
                    final user = FirebaseAuth.instance.currentUser;
                    if (user != null) {
                      if (!user.emailVerified) {
                        try {
                          await user.sendEmailVerification();
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(content: Text('Verification email sent!')),
                          );
                        } catch (e) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(content: Text('Error sending email: ${e.toString()}')),
                          );
                        }
                      } else {
                        Get.offAll(() => BuyerDashboard());
                      }
                    } else {
                      Get.offAll(() => BuyerDashboard());
                    }
                  }
                },
                child: Text('Skip and Continue', style: TextStyle(fontSize: width * 0.045)),
                style: ElevatedButton.styleFrom(
                  padding: EdgeInsets.symmetric(vertical: height * 0.015, horizontal: width * 0.2),
                  foregroundColor: Colors.black,
                  backgroundColor: Colors.amber,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.all(Radius.circular(10)),
                  ),
                ),
              ),
              TextButton(
                onPressed: controller.resendEmail,
                child: Text('Didn\'t receive it yet? Resend Email', style: TextStyle(fontSize: width * 0.045)),
                style: TextButton.styleFrom(foregroundColor: Colors.black),
              ),
              TextButton(
                onPressed: () {
                  // Handle change email
                },
                child: Text('Change the email', style: TextStyle(fontSize: width * 0.045)),
                style: TextButton.styleFrom(foregroundColor: Colors.black),
              ),
              SizedBox(height: height * 0.03),
            ],
          ),
        ),
      ),
    );
  }
}
