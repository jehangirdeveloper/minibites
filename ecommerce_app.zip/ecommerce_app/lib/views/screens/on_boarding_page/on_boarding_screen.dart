import 'package:minibites/controllers/onboarding_controller.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:liquid_swipe/liquid_swipe.dart';
import 'package:smooth_page_indicator/smooth_page_indicator.dart';

import 'on_boarding_page_widget.dart';

class OnboardingScreen extends StatelessWidget {
  final OnboardingController controller = Get.put(OnboardingController());
  final LiquidController liquidController = LiquidController();

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    final double indicatorPosition = size.height * 0.10; // Position indicator dynamically

    return Scaffold(
      body: Stack(
        children: [
          LiquidSwipe(
            pages: pages,
            enableSideReveal: true,
            liquidController: liquidController,
            onPageChangeCallback: (index) {
              controller.currentPage.value = index;
            },
            slideIconWidget: Icon(Icons.arrow_back_ios),
          ),
          Positioned(
            bottom: indicatorPosition,
            left: size.width * 0.45, // Position indicator dynamically
            child: Center(
              child: Obx(() => AnimatedSmoothIndicator(
                activeIndex: controller.currentPage.value,
                effect: WormEffect(
                  dotHeight: size.height * 0.02, // Adjust indicator size
                  dotWidth: size.height * 0.02,
                ),
                count: pages.length,
              )),
            ),
          ),
        ],
      ),
    );
  }
}
