import 'package:minibites/views/screens/admin_dashboard/admin_login_screen.dart';
import 'package:minibites/views/screens/buyer_welcome_screen.dart';
import 'package:minibites/views/screens/seller_welcome_screen.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../admin_dashboard/restaurantlistpage.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: ResponsivePages(),
    );
  }
}

class ResponsivePages extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: PageView(
        children: pages,
      ),
    );
  }
}

final List<Widget> pages = [
  Builder(
    builder: (context) {
      return LayoutBuilder(
        builder: (context, constraints) {
          final double screenHeight = constraints.maxHeight;
          final double screenWidth = constraints.maxWidth;

          return Container(
            color: Colors.white,
            child: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Image.asset(
                    'images/happy-chef.png',
                    width: screenWidth * 0.9,
                  ),
                  SizedBox(height: screenHeight * 0.05),
                  Text(
                    'Mini Bites Partner',
                    style: TextStyle(
                      fontSize: screenWidth * 0.06,
                      fontWeight: FontWeight.bold,
                      color: Colors.black,
                      fontFamily: 'Horizon',
                    ),
                  ),
                  SizedBox(height: screenHeight * 0.02),
                  Text(
                    'Register Your Restaurant, Shop, Dhaba, Home Kithen',
                    style: TextStyle(
                      fontSize: screenWidth * 0.04,
                      fontWeight: FontWeight.bold,
                      color: Colors.black,
                      fontFamily: 'Orbitron-Bold',
                    ),
                    textAlign: TextAlign.center,
                  ),
                  SizedBox(height: screenHeight * 0.05),
                  SizedBox(
                    width: screenWidth * 0.4,
                    height: screenHeight * 0.07,
                    child: ElevatedButton(
                      onPressed: () {
                        Get.to(() => SellerWelcomeScreen());
                      },
                      child: Text('Get Started'),
                      style: ElevatedButton.styleFrom(
                        foregroundColor: Colors.white,
                        backgroundColor: Colors.blue,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      );
    },
  ),
  Builder(
    builder: (context) {
      return LayoutBuilder(
        builder: (context, constraints) {
          final double screenHeight = constraints.maxHeight;
          final double screenWidth = constraints.maxWidth;

          return Container(
            color: Colors.amber,
            child: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Image.asset(
                    'images/28430525_7.png',
                    width: screenWidth * 0.8,
                  ),
                  SizedBox(height: screenHeight * 0.05),
                  Text(
                    'Mini Bites Mart',
                    style: TextStyle(
                      fontSize: screenWidth * 0.06,
                      fontWeight: FontWeight.bold,
                      color: Colors.black,
                      fontFamily: 'Horizon',
                    ),
                  ),
                  SizedBox(height: screenHeight * 0.02),
                  Text(
                    'Order Now Any Food any time',
                    style: TextStyle(
                      fontSize: screenWidth * 0.04,
                      fontWeight: FontWeight.bold,
                      color: Colors.black,
                      fontFamily: 'Orbitron-Bold',
                    ),
                    textAlign: TextAlign.center,
                  ),
                  SizedBox(height: screenHeight * 0.05),
                  SizedBox(
                    width: screenWidth * 0.4,
                    height: screenHeight * 0.07,
                    child: ElevatedButton(
                      onPressed: () {
                        Get.to(() => BuyerWelcomeScreen());
                      },
                      child: Text('Get Started'),
                      style: ElevatedButton.styleFrom(
                        foregroundColor: Colors.white,
                        backgroundColor: Colors.blue,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      );
    },
  ),
  Builder(
    builder: (context) {
      return LayoutBuilder(
        builder: (context, constraints) {
          final double screenHeight = constraints.maxHeight;
          final double screenWidth = constraints.maxWidth;

          return Container(
            color: Colors.grey[800],
            child: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Image.asset(
                    'images/admin.png',
                    width: screenWidth * 0.8,
                  ),
                  SizedBox(height: screenHeight * 0.05),
                  Text(
                    'Mini Bites Admin',
                    style: TextStyle(
                      fontSize: screenWidth * 0.06,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                      fontFamily: 'Horizon',
                    ),
                  ),
                  SizedBox(height: screenHeight * 0.02),
                  Text(
                    'Only Admin',
                    style: TextStyle(
                      fontSize: screenWidth * 0.04,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                      fontFamily: 'Orbitron-Bold',
                    ),
                    textAlign: TextAlign.center,
                  ),
                  SizedBox(height: screenHeight * 0.05),
                  SizedBox(
                    width: screenWidth * 0.6,
                    height: screenHeight * 0.07,
                    child: ElevatedButton(
                      onPressed: () {
                        Get.to(() => AdminLoginScreen());
                      },
                      child: Text('Admin Login'),
                      style: ElevatedButton.styleFrom(
                        foregroundColor: Colors.white,
                        backgroundColor: Colors.blue,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      );
    },
  ),
];
