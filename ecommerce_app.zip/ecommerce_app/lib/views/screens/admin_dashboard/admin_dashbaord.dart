import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:minibites/controllers/seller_dashboard_controller/seller_dashboard_controller.dart';
import 'package:minibites/views/screens/admin_dashboard/restaurantlistpage.dart';
import 'package:minibites/views/screens/on_boarding_page/on_boarding_screen.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:fl_chart/fl_chart.dart';

class AdminDashboard extends StatefulWidget {
  @override
  _AdminDashboardState createState() => _AdminDashboardState();
}

class _AdminDashboardState extends State<AdminDashboard> {
  final SellerDashboardController controller = Get.put(SellerDashboardController());
  String sellerId = FirebaseAuth.instance.currentUser?.uid ?? '';
  String selectedRestaurantId = '';

  @override
  void initState() {
    super.initState();
    selectedRestaurantId = controller.selectedRestaurantId;
  }

  @override
  Widget build(BuildContext context) {
    double screenHeight = MediaQuery.of(context).size.height;
    double screenWidth = MediaQuery.of(context).size.width;

    return Scaffold(
      backgroundColor: Colors.grey[850],
      appBar: AppBar(
        automaticallyImplyLeading: false,
        backgroundColor: Colors.grey[800],
        title: Row(
          children: [
            Icon(Icons.add_business_rounded, color: Colors.white),
            SizedBox(width: screenWidth * 0.02),
            Text('MiniBites Admin App', style: TextStyle(color: Colors.white, fontSize: screenWidth * 0.045)),
          ],
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: StreamBuilder<QuerySnapshot>(
                stream: FirebaseFirestore.instance.collection('restaurants').snapshots(),
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return Center(child: CircularProgressIndicator());
                  }
                  if (snapshot.hasError) {
                    return Center(child: Text("Error: ${snapshot.error}"));
                  }
                  if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                    return Center(child: Text("No restaurants found"));
                  }

                  double totalAdminAmount = 0.0;
                  double dailyAdminAmount = 0.0;
                  DateTime currentDate = DateTime.now();

                  final List<DocumentSnapshot> restaurantDocs = snapshot.data!.docs;

                  List<Future<void>> orderFetchFutures = restaurantDocs.map((restaurantDoc) async {
                    String restaurantId = restaurantDoc.id;
                    QuerySnapshot ordersSnapshot = await FirebaseFirestore.instance
                        .collection('restaurants')
                        .doc(restaurantId)
                        .collection('orders')
                        .get();

                    double restaurantSubtotal = 0.0;
                    double restaurantDailyAmount = 0.0;

                    for (var doc in ordersSnapshot.docs) {
                      double subtotal = (doc['subtotal'] ?? 0) * 0.15 + 70;
                      totalAdminAmount += subtotal;

                      // Check if order timestamp is from today
                      Timestamp timestamp = doc['timestamp'];
                      DateTime orderDate = timestamp.toDate();

                      if (orderDate.year == currentDate.year &&
                          orderDate.month == currentDate.month &&
                          orderDate.day == currentDate.day) {
                        restaurantDailyAmount += subtotal;
                      }
                    }

                    dailyAdminAmount += restaurantDailyAmount;
                  }).toList();

                  return FutureBuilder(
                    future: Future.wait(orderFetchFutures),
                    builder: (context, orderSnapshot) {
                      if (orderSnapshot.connectionState == ConnectionState.waiting) {
                        return Center(child: CircularProgressIndicator());
                      }

                      return Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Container(
                            width: screenWidth * 0.3,
                            height: screenHeight * 0.2,
                            child: Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Image.asset(
                                'images/Screenshot_2024.png',
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                          Expanded(
                            child: Card(
                              color: Colors.grey.shade800,
                              elevation: 3,
                              child: Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                  Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      'Daily Amount',
                                      style: TextStyle(
                                        fontSize: screenWidth * 0.030,
                                        color: Colors.white,
                                        fontFamily: 'Horizon',
                                      ),
                                    ),
                                    SizedBox(height: 5),
                                    Text(
                                      'PKR ${dailyAdminAmount.toStringAsFixed(2)}',
                                      style: TextStyle(
                                        fontSize: screenWidth * 0.03,
                                        color: Colors.white60,
                                        fontFamily: 'Orbitron-Bold',
                                      ),
                                    ),
                                  ],
                                ),
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      'Total Amount',
                                      style: TextStyle(
                                        fontSize: screenWidth * 0.030,
                                        color: Colors.white,
                                        fontFamily: 'Horizon',
                                      ),
                                    ),
                                    SizedBox(height: 5),
                                    Text(
                                      'PKR ${totalAdminAmount.toStringAsFixed(2)}',
                                      style: TextStyle(
                                        fontSize: screenWidth * 0.03,
                                        color: Colors.white60,
                                        fontFamily: 'Orbitron-Bold',
                                      ),
                                    ),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ],
                      );
                    },
                  );
                },
              ),
            ),

            Padding(
              padding: const EdgeInsets.only(left: 8.0),
              child: Container(
                width: double.infinity,
                height: screenHeight * 0.4,
                child: LineChart(
                  LineChartData(
                    gridData: FlGridData(show: false),
                    titlesData: FlTitlesData(
                      bottomTitles: AxisTitles(
                        sideTitles: SideTitles(showTitles: true, reservedSize: 20, getTitlesWidget: (value, meta) {
                          switch (value.toInt()) {
                            case 0: return Text('1W', style: TextStyle(color: Colors.white, fontSize: screenWidth * 0.03));
                            case 1: return Text('2W', style: TextStyle(color: Colors.white, fontSize: screenWidth * 0.03));
                            case 2: return Text('3W', style: TextStyle(color: Colors.white, fontSize: screenWidth * 0.03));
                            case 3: return Text('4W', style: TextStyle(color: Colors.white, fontSize: screenWidth * 0.03));
                            case 4: return Text('5W', style: TextStyle(color: Colors.white, fontSize: screenWidth * 0.03));
                            case 5: return Text('6W', style: TextStyle(color: Colors.white, fontSize: screenWidth * 0.03));
                            case 6: return Text('7W', style: TextStyle(color: Colors.white, fontSize: screenWidth * 0.03));
                          }
                          return Text('');
                        }),
                      ),
                      leftTitles: AxisTitles(
                        sideTitles: SideTitles(showTitles: true, reservedSize: 40, getTitlesWidget: (value, meta) {
                          return Text('${value.toInt()} PKR', style: TextStyle(color: Colors.white, fontSize: screenWidth * 0.03));
                        }),
                      ),
                    ),
                    borderData: FlBorderData(
                      show: true,
                      border: Border.all(color: Colors.white, width: 1),
                    ),
                    minX: 0,
                    maxX: 6,
                    minY: 0,
                    maxY: 100000,
                    lineBarsData: [
                      LineChartBarData(
                        spots: [
                          FlSpot(0, 200),
                          FlSpot(1, 300),
                          FlSpot(2, 400),
                          FlSpot(3, 250),
                          FlSpot(4, 500),
                          FlSpot(5, 590),
                          FlSpot(6, 400),
                        ],
                        isCurved: true,
                        color: Colors.blue,
                        dotData: FlDotData(show: false),
                        belowBarData: BarAreaData(show: false),
                        showingIndicators: [0, 1, 2, 3, 4, 5, 6],
                      ),
                    ],
                  ),
                ),
              ),
            ),

            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      buildCard(
                        'Restaurant Lists',
                        '',
                        Icons.restaurant_menu_rounded,
                            () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => RestaurantListPage(),
                            ),
                          );
                        },
                        backgroundColor: Colors.grey.shade800,
                        textColor: Colors.white,
                        fontFamily: 'Horizon',  // Apply font family here
                      ),
                      SizedBox(width: 10),  // Spacing between cards
                      Container(
                        width: 150,  // Set the width for logout card
                        child: buildCard(
                          'Logout',
                          '',
                          Icons.exit_to_app,
                              () async {
                            try {
                              await FirebaseAuth.instance.signOut();
                              Get.to(OnboardingScreen());
                            } catch (e) {
                              print('Sign out error: $e');
                            }
                          },
                          backgroundColor: Colors.grey.shade800,
                          textColor: Colors.white,
                          fontFamily: 'Horizon',  // Apply font family here
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget buildCard(String title, String subtitle, IconData icon, Function onTap,
      {Color backgroundColor = Colors.white, Color textColor = Colors.black, String fontFamily = 'Horizon',}) {
    return GestureDetector(
      onTap: () => onTap(),
      child: Card(
        color: backgroundColor,
        elevation: 5,
        child: Padding(
          padding: const EdgeInsets.all(12.0),
          child: Column(
            children: [
              Icon(icon, size: 40, color: textColor),
              SizedBox(height: 8),
              Text(title, style: TextStyle(fontSize: 11, color: textColor, fontFamily: fontFamily, )),
              SizedBox(height: 4),
              Text(subtitle, style: TextStyle(fontSize: 10, color: textColor, fontFamily: fontFamily,)),
            ],
          ),
        ),
      ),
    );
  }
}
