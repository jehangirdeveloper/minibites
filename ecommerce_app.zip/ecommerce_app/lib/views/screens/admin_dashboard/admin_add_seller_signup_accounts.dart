import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:minibites/views/screens/seller_email_verification_screen.dart';
import 'package:minibites/views/screens/seller_login_screen.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:minibites/controllers/seller_signup_usercontroller.dart';
import 'package:firebase_auth/firebase_auth.dart';

class AdminAddSellerSignupAccounts extends StatelessWidget {
  final UserController userController = Get.put(UserController());
  final FirebaseFirestore firestore = FirebaseFirestore.instance;
  final FirebaseAuth auth = FirebaseAuth.instance;

  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('SignUp'),
        backgroundColor: Colors.amber,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                SizedBox(height: 15),
                Text(
                  'Ready to grow your business?',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: Colors.black,
                    fontFamily: 'Horizon',
                  ),
                  textAlign: TextAlign.center,
                ),
                SizedBox(height: 20),
                TextFormField(
                  onChanged: (value) => userController.fullName.value = value,
                  decoration: InputDecoration(
                    labelText: 'Business Owner Full Name',
                    prefixIcon: Icon(Icons.person),
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please enter your full name';
                    }
                    return null;
                  },
                ),
                TextFormField(
                  onChanged: (value) => userController.businessName.value = value,
                  decoration: InputDecoration(
                    labelText: 'Business Name',
                    prefixIcon: Icon(Icons.business),
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please enter your business name';
                    }
                    return null;
                  },
                ),
                TextFormField(
                  onChanged: (value) => userController.email.value = value,
                  decoration: InputDecoration(
                    labelText: 'Enter Your Email',
                    prefixIcon: Icon(Icons.email),
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please enter your email';
                    }
                    // Additional email validation can be added here
                    return null;
                  },
                ),
                TextFormField(
                  onChanged: (value) => userController.password.value = value,
                  obscureText: true,
                  decoration: InputDecoration(
                    labelText: 'Enter Your Password',
                    prefixIcon: Icon(Icons.lock),
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please enter your password';
                    }
                    return null;
                  },
                ),
                DropdownButtonFormField<String>(
                  value: userController.selectedRole.value,
                  onChanged: (String? newValue) {
                    userController.selectedRole.value = newValue!;
                  },
                  items: <String>['Restaurant', 'Shop', 'Dhaba', 'Home Kitchen']
                      .map<DropdownMenuItem<String>>((String value) {
                    return DropdownMenuItem<String>(
                      value: value,
                      child: Text(value),
                    );
                  }).toList(),
                  decoration: InputDecoration(
                    labelText: 'Business Type',
                    prefixIcon: Icon(Icons.business),
                  ),
                  validator: (value) {
                    if (value == null) {
                      return 'Please select your business type';
                    }
                    return null;
                  },
                ),
                DropdownButtonFormField<String>(
                  value: userController.selectedCountry.value,
                  onChanged: (String? newValue) {
                    userController.selectedCountry.value = newValue!;
                  },
                  items: <String>['Pakistan']
                      .map<DropdownMenuItem<String>>((String value) {
                    return DropdownMenuItem<String>(
                      value: value,
                      child: Text(value),
                    );
                  }).toList(),
                  decoration: InputDecoration(
                    labelText: 'Select Your Country',
                    prefixIcon: Icon(Icons.flag),
                  ),
                  validator: (value) {
                    if (value == null) {
                      return 'Please select your country';
                    }
                    return null;
                  },
                ),
                DropdownButtonFormField<String>(
                  value: 'Attock City', // Default value
                  onChanged: (String? newValue) {
                    userController.cityName.value = newValue!;
                  },
                  decoration: InputDecoration(
                    labelText: 'Select Your City',
                    prefixIcon: Icon(Icons.location_city),
                  ),
                  items: <String>['Attock City']
                      .map<DropdownMenuItem<String>>((String value) {
                    return DropdownMenuItem<String>(
                      value: value,
                      child: Text(value),
                    );
                  }).toList(),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please select your city';
                    }
                    return null;
                  },
                ),

                TextFormField(
                  onChanged: (value) => userController.phoneNumber.value = value,
                  decoration: InputDecoration(
                    labelText: 'Enter Your Phone Number',
                    prefixIcon: Icon(Icons.phone),
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please enter your phone number';
                    }
                    return null;
                  },
                ),
                SizedBox(height: 20),
                ElevatedButton(
                  onPressed: () async {
                    if (_formKey.currentState!.validate()) {
                      // Firebase Authentication aur Firestore mein data save karna
                      try {
                        // Firebase Authentication se user create karein
                        UserCredential userCredential = await auth.createUserWithEmailAndPassword(
                          email: userController.email.value,
                          password: userController.password.value,
                        );

                        // Unique sellerId ko Firestore me seller document ke sath save karein
                        await firestore.collection('sellers').doc(userCredential.user!.uid).set({
                          'sellerId': userCredential.user!.uid,
                          'fullName': userController.fullName.value,
                          'businessName': userController.businessName.value,
                          'email': userController.email.value,
                          'role': userController.selectedRole.value,
                          'country': userController.selectedCountry.value,
                          'city': userController.cityName.value,
                          'phoneNumber': userController.phoneNumber.value,
                        });

                        Get.to(() => SellerEmailVerificationScreen());
                      } catch (e) {
                        Get.snackbar('Error', e.toString(), backgroundColor: Colors.red, colorText: Colors.white);
                      }
                    }
                  },
                  child: Text('Signup'),
                  style: ElevatedButton.styleFrom(
                    padding: EdgeInsets.symmetric(vertical: 10, horizontal: 100),
                    foregroundColor: Colors.black,
                    backgroundColor: Colors.amber,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.all(Radius.circular(10)),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
