import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../controllers/admin_dashboard/restaurantcontroller.dart';
import 'package:intl/intl.dart';

class OrderListPage extends StatelessWidget {
  final String restaurantId;
  final RestaurantController restaurantController = Get.find();

  DateTime? startDate;
  DateTime? endDate;

  OrderListPage({required this.restaurantId});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Orders"),
        centerTitle: true,
        backgroundColor: Colors.amber,
      ),
      body: StreamBuilder<List<Order>>(
        stream: restaurantController.getOrderStream(restaurantId),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return Center(child: CircularProgressIndicator());
          }

          var orders = snapshot.data!;

          // Filter orders based on selected dates
          if (startDate != null && endDate != null) {
            print("Filtering orders on: $startDate");
            orders = orders.where((order) {
              return order.timestamp.isAfter(startDate!.subtract(Duration(hours: 1))) &&
                  order.timestamp.isBefore(endDate!.add(Duration(hours: 1))) ||
                  order.timestamp.isAtSameMomentAs(startDate!);
            }).toList();
          }

          orders.sort((a, b) => b.timestamp.compareTo(a.timestamp));

          if (orders.isEmpty) {
            return Center(child: Text("No orders found"));
          }

          return RefreshIndicator(
            onRefresh: () async {
              await restaurantController.refreshOrdersByDate(restaurantId, startDate!, endDate!);
            },
            child: ListView.builder(
              padding: EdgeInsets.all(10),
              itemCount: orders.length,
              itemBuilder: (context, index) {
                var order = orders[index];
                double subtotal85Percent = order.subtotal * 0.85;
                double totalFifteenPercent = (order.subtotal * 0.15) + 70; // Add 70 here
                double totalAmount = subtotal85Percent + totalFifteenPercent; // Calculate Total Amount

                return Card(
                  elevation: 3,
                  margin: EdgeInsets.symmetric(vertical: 8),
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _buildOrderInfoRow("Order Number:", order.orderNumber),
                        Divider(color: Colors.black), // Add a line between the details
                        _buildOrderInfoRow("Restaurant Name:", order.restaurantName),
                        Divider(color: Colors.black),
                        _buildOrderInfoRow("Order Status:", order.status),
                        Divider(color: Colors.black),
                        _buildOrderInfoRow("Payment Status:", order.paymentStatus),
                        Divider(color: Colors.black),
                        _buildOrderInfoRow("Payment Method:", order.paymentMethod),
                        Divider(color: Colors.black),
                        _buildOrderInfoRow("Delivery Address:", order.deliveryAddress),
                        Divider(color: Colors.black),
                        _buildOrderInfoRow("Date & Time:", DateFormat('yyyy-MM-dd – kk:mm').format(order.timestamp)),
                        Divider(color: Colors.black),
                        Padding(
                          padding: const EdgeInsets.only(top: 8.0),
                          child: Text('Items and Quantities:', style: TextStyle(fontWeight: FontWeight.bold)),
                        ),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: List.generate(order.items.length, (i) {
                            return Padding(
                              padding: const EdgeInsets.symmetric(vertical: 2),
                              child: Row(
                                children: [
                                  Expanded(
                                    flex: 3,
                                    child: Text('• ${order.items[i]}'),
                                  ),
                                  Expanded(
                                    flex: 1,
                                    child: Text('x${order.quantities[i]}'),
                                  ),
                                ],
                              ),
                            );
                          }),
                        ),
                        Divider(color: Colors.black),
                        _buildOrderInfoRow("Restaurant Amount:", "PKR ${subtotal85Percent.toStringAsFixed(2)}"),
                        Divider(color: Colors.black),
                        _buildOrderInfoRow("Admin Amount:", "PKR ${totalFifteenPercent.toStringAsFixed(2)}"),
                        Divider(color: Colors.black),
                        _buildOrderInfoRow("Customer Amount:", "PKR ${totalAmount.toStringAsFixed(2)}"), // Add Total Amount field
                      ],
                    ),
                  ),
                );
              },
            ),
          );
        },
      ),
    );
  }

  // Updated _buildOrderInfoRow with vertical line
  Widget _buildOrderInfoRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2),
      child: Row(
        children: [
          Expanded(
            flex: 2,
            child: Text(
              label,
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
          ),
          Container(
            height: 20, // Adjust the height of the line to fit the text
            width: 1,   // This is the thickness of the line
            color: Colors.black, // Color of the line
            margin: EdgeInsets.symmetric(horizontal: 10), // Adds space around the line
          ),
          Expanded(
            flex: 3,
            child: Text(value),
          ),
        ],
      ),
    );
  }
}
