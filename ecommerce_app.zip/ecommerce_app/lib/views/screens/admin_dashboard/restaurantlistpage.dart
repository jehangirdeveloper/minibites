import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:minibites/views/screens/admin_dashboard/orderlistpage.dart';
import '../../../controllers/admin_dashboard/restaurantcontroller.dart';

class RestaurantListPage extends StatelessWidget {
  final RestaurantController restaurantController = Get.put(RestaurantController());

  // Add lists of countries and cities for filtering
  final List<String> countries = ['Pakistan'];
  final List<String> cities = ['Attock City'];

  // Selected country and city variables
  final RxString selectedCountry = 'Pakistan'.obs;
  final RxString selectedCity = 'Attock City'.obs;

  // TextEditingController for search
  final TextEditingController searchController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.amber,
      appBar: AppBar(
        automaticallyImplyLeading: false,
        backgroundColor: Colors.yellow[700],
        elevation: 2,
        centerTitle: true, // Center the title and dropdowns
        toolbarHeight: 150, // Adjust height
        title: Column(
          children: [
            // Search bar
            Container(
              padding: EdgeInsets.symmetric(horizontal: 10),
              decoration: BoxDecoration(
                color: Colors.white, // Background color of search bar
                borderRadius: BorderRadius.circular(20),
              ),
              child: TextField(
                controller: searchController,
                decoration: InputDecoration(
                  hintText: 'Search restaurants...',
                  border: InputBorder.none,
                  icon: Icon(Icons.search, color: Colors.grey),
                ),
                onChanged: (value) {
                  restaurantController.searchRestaurants(value);
                },
              ),
            ),
            SizedBox(height: 10),
            Row(
              mainAxisAlignment: MainAxisAlignment.center, // Centering the dropdowns
              children: [
                // Country filter with border
                Obx(() {
                  return Container(
                    padding: EdgeInsets.symmetric(horizontal: 10),
                    decoration: BoxDecoration(
                      border: Border.all(color: Colors.grey, width: 1), // Adding border
                      borderRadius: BorderRadius.circular(8), // Rounded corners
                    ),
                    child: DropdownButton<String>(
                      value: selectedCountry.value,
                      items: countries.map((String country) {
                        return DropdownMenuItem<String>(
                          value: country,
                          child: Text(
                            country,
                            style: TextStyle(color: Colors.grey[800]),
                          ),
                        );
                      }).toList(),
                      onChanged: (newValue) {
                        selectedCountry.value = newValue!;
                        restaurantController.filterRestaurants(
                          country: selectedCountry.value,
                          city: selectedCity.value,
                        );
                      },
                      dropdownColor: Colors.yellow[700],
                      underline: SizedBox(),
                      icon: Icon(Icons.arrow_drop_down, color: Colors.grey[800]),
                    ),
                  );
                }),
                SizedBox(width: 10),
                // City filter with border
                Obx(() {
                  return Container(
                    padding: EdgeInsets.symmetric(horizontal: 10),
                    decoration: BoxDecoration(
                      border: Border.all(color: Colors.grey, width: 1), // Adding border
                      borderRadius: BorderRadius.circular(8), // Rounded corners
                    ),
                    child: DropdownButton<String>(
                      value: selectedCity.value,
                      items: cities.map((String city) {
                        return DropdownMenuItem<String>(
                          value: city,
                          child: Text(
                            city,
                            style: TextStyle(color: Colors.grey[800]),
                          ),
                        );
                      }).toList(),
                      onChanged: (newValue) {
                        selectedCity.value = newValue!;
                        restaurantController.filterRestaurants(
                          country: selectedCountry.value,
                          city: selectedCity.value,
                        );
                      },
                      dropdownColor: Colors.yellow[700],
                      underline: SizedBox(),
                      icon: Icon(Icons.arrow_drop_down, color: Colors.white),
                    ),
                  );
                }),
              ],
            ),
          ],
        ),
      ),
      body: Obx(() {
        if (restaurantController.restaurantsList.isEmpty) {
          return Center(child: CircularProgressIndicator(color: Colors.yellow));
        }
        return ListView.builder(
          itemCount: restaurantController.restaurantsList.length,
          itemBuilder: (context, index) {
            var restaurant = restaurantController.restaurantsList[index];
            return Padding(
              padding: const EdgeInsets.symmetric(vertical: 8.0, horizontal: 15.0),
              child: Card(
                color: Colors.grey[900],
                elevation: 5,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20),
                ),
                child: InkWell(
                  onTap: () {
                    restaurantController.fetchOrders(restaurant.id);
                    Get.to(() => OrderListPage(restaurantId: restaurant.id));
                  },
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      ClipRRect(
                        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
                        child: restaurant.imageUrl.isNotEmpty
                            ? Image.network(
                          restaurant.imageUrl,
                          height: 180,
                          width: double.infinity,
                          fit: BoxFit.cover,
                        )
                            : Image.asset(
                          'assets/placeholder_image.png',
                          height: 180,
                          width: double.infinity,
                          fit: BoxFit.cover,
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(15.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      restaurant.name,
                                      style: TextStyle(
                                        fontSize: 20,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.white,
                                      ),
                                    ),
                                    SizedBox(height: 5),
                                  ],
                                ),
                              ],
                            ),
                            SizedBox(height: 10),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  "Close: ${restaurant.closingTime}",
                                  style: TextStyle(
                                    color: Colors.grey[400],
                                  ),
                                ),
                                IconButton(
                                  icon: Icon(Icons.delete, color: Colors.red),
                                  onPressed: () async {
                                    bool confirmDelete = await showDialog(
                                      context: context,
                                      builder: (context) => AlertDialog(
                                        title: Text('Delete Restaurant'),
                                        content: Text('Are you sure you want to delete this restaurant?'),
                                        actions: [
                                          TextButton(
                                            onPressed: () => Get.back(result: false),
                                            child: Text('Cancel'),
                                          ),
                                          TextButton(
                                            onPressed: () => Get.back(result: true),
                                            child: Text('Delete'),
                                          ),
                                        ],
                                      ),
                                    );
                                    if (confirmDelete) {
                                      restaurantController.restaurantsList.removeAt(index);
                                    }
                                  },
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            );
          },
        );
      }),
    );
  }
}
