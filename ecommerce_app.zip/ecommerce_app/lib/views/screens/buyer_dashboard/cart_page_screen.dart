import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:minibites/controllers/buyer_dashboard_pages_controller/Cart_Controller.dart';
import 'package:minibites/views/screens/buyer_dashboard/checkout_page_screen.dart'; // CheckoutPageScreen ko import karein

class CartPageScreen extends StatelessWidget {
  final String restaurantName;
  final String restaurantId;

  // Constructor with unique parameter names
  CartPageScreen({required this.restaurantName, required this.restaurantId});

  @override
  Widget build(BuildContext context) {
    final CartController cartController = Get.find<CartController>();

    return Scaffold(
      appBar: AppBar(
        title: Text('My Cart'),
        backgroundColor: Colors.yellow,
      ),
      body: Obx(() {
        if (cartController.cartItems.isEmpty) {
          return Center(child: Text('Cart is empty'));
        }
        return Column(
          children: [
            Expanded(
              child: ListView.builder(
                itemCount: cartController.cartItems.length,
                itemBuilder: (context, index) {
                  final item = cartController.cartItems[index];
                  return Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
                    child: Row(
                      children: [
                        item.imageUrl.isNotEmpty
                            ? Image.network(item.imageUrl, width: 80, height: 80, fit: BoxFit.cover)
                            : SizedBox(width: 80, height: 80),
                        SizedBox(width: 16),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(item.name, style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                              SizedBox(height: 4),
                              Text('Rs ${item.price}', style: TextStyle(fontSize: 16, color: Colors.grey)),
                            ],
                          ),
                        ),
                        Row(
                          children: [
                            IconButton(
                              icon: Icon(Icons.remove_circle_outline),
                              onPressed: () {
                                cartController.decrementQuantity(item.id);
                              },
                            ),
                            Text('${item.quantity}', style: TextStyle(fontSize: 16)),
                            IconButton(
                              icon: Icon(Icons.add_circle_outline),
                              onPressed: () {
                                cartController.incrementQuantity(item.id);
                              },
                            ),
                          ],
                        ),
                        IconButton(
                          icon: Icon(Icons.close),
                          onPressed: () {
                            cartController.removeItem(item.id);
                          },
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
            Divider(thickness: 1, color: Colors.grey),
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text('Sub total', style: TextStyle(fontSize: 16)),
                      Text('Rs ${cartController.getSubTotalPrice()}', style: TextStyle(fontSize: 16)),
                    ],
                  ),
                  SizedBox(height: 8),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text('Platform Fee', style: TextStyle(fontSize: 16)),
                      Text('Rs 20.00', style: TextStyle(fontSize: 16)),
                    ],
                  ),
                  SizedBox(height: 8),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text('Delivery Fee', style: TextStyle(fontSize: 16)),
                      Text('Rs 50.00', style: TextStyle(fontSize: 16)),
                    ],
                  ),
                  SizedBox(height: 8),
                  Divider(thickness: 1, color: Colors.grey),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text('Total', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                      Text('Rs ${cartController.getTotalPrice()}', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                    ],
                  ),
                  SizedBox(height: 16),
                  ElevatedButton(
                    onPressed: () {
                      final CartController cartController = Get.find<CartController>();
                      final totalAmount = cartController.getTotalPrice(); // Total amount calculate karein
                      final subtotal = cartController.getSubTotalPrice(); // Subtotal calculate karein
                      final cartItems = cartController.cartItems.map((item) => item.toCheckoutPageScreenModel()).toList();

                      // Navigate to CheckoutPageScreen and pass cart items, restaurantName, subtotal, and totalAmount
                      Get.to(() => CheckoutPageScreen(
                        checkoutItems: cartItems,
                        subtotal: subtotal, // Pass subtotal here
                        totalAmount: totalAmount,
                        restaurantId: restaurantId,
                        restaurantName: restaurantName,
                      ));
                    },
                    style: ElevatedButton.styleFrom(
                      minimumSize: Size(double.infinity, 50),
                      backgroundColor: Colors.amber,
                    ),
                    child: Text('Checkout', style: TextStyle(fontSize: 18)),
                  ),
                ],
              ),
            ),
          ],
        );
      }),
    );
  }
}
