import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart'; // Import for RatingBar
import 'package:cloud_firestore/cloud_firestore.dart'; // Import for Firestore
import 'package:get/get.dart';
import 'dart:io';
import 'package:minibites/controllers/buyer_dashboard_pages_controller/OrderTrackingController.dart';
import 'package:minibites/controllers/seller_dashboard_controller/seller_dashboard_ratings_page_controller.dart';
import 'package:minibites/views/screens/buyer_dashboard/dbchatscreen.dart';
import 'package:firebase_storage/firebase_storage.dart'; // Import for Firebase Storage
import 'package:minibites/views/screens/notification_services.dart';


// Firebase Storage se image URL fetch karne ka function
Future<String> getDeliveryBoyImageUrl() async {
  try {
    String imagePath = 'deliveryboyimage/db.png';
    String downloadURL =
    await FirebaseStorage.instance.ref(imagePath).getDownloadURL();
    return downloadURL;
  } catch (e) {
    print("Error getting image URL: $e");
    return '';
  }
}

// Firestore se timestamp ko readable format me convert karne ka function
String formatTimestamp(Timestamp timestamp) {
  DateTime dateTime = timestamp.toDate();
  return "${dateTime.day}-${dateTime.month}-${dateTime.year} ${dateTime.hour}:${dateTime.minute}";
}

// Example: Firestore se order data fetch karna and timestamp ko display karna
Future<void> _fetchOrderDetails(String restaurantId) async {
  try {
    var orderSnapshot = await FirebaseFirestore.instance
        .collection('restaurants')
        .doc(restaurantId)
        .collection('orders')
        .get();

    if (orderSnapshot.docs.isNotEmpty) {
      var orderData = orderSnapshot.docs.first.data();
      Timestamp orderTimestamp = orderData['timestamp'];
      String status = orderData['status']; // Status field ko fetch karna

      // Timestamp ko formatted date me convert kar ke use display karna
      String formattedDate = formatTimestamp(orderTimestamp);
      print('Order Date: $formattedDate');
      print('Order Status: $status');
    } else {
      print('No orders found for the restaurant');
    }
  } catch (e) {
    print('Error fetching order details: $e');
  }
}

class OrderTrackingScreen extends StatefulWidget {
  final List<String> itemNames;
  final List<double> itemPrices;
  final List<int> itemQuantities;
  final double subtotal;
  final double deliveryFee;
  final double platformFee;
  final double totalAmount;
  final String paymentMethod;
  final String orderNumber;
  final String restaurantName;
  final String deliveryAddress;

  OrderTrackingScreen({
    required this.itemNames,
    required this.itemPrices,
    required this.itemQuantities,
    required this.subtotal,
    required this.deliveryFee,
    required this.platformFee,
    required this.totalAmount,
    required this.paymentMethod,
    required this.orderNumber,
    required this.restaurantName,
    required this.deliveryAddress,
  });

  @override
  _OrderTrackingScreenState createState() => _OrderTrackingScreenState();
}

class _OrderTrackingScreenState extends State<OrderTrackingScreen>
    with SingleTickerProviderStateMixin {
  final OrderTrackingController trackingController =
  Get.put(OrderTrackingController());
  late AnimationController _controller;
  final TextEditingController _reviewController =
  TextEditingController(); // Controller for review text
  double _rating = 0.0; // Rating value
  String? _selectedRestaurantId; // Store selected restaurant ID for review

  Future<void> _saveOrderDetails() async {
    try {
      // Firestore collection 'restaurants' ke under order details save kar rahe hain
      await FirebaseFirestore.instance
          .collection('restaurants')
          .doc(_selectedRestaurantId) // Restaurant ID document
          .collection('orders') // Orders collection inside restaurant
          .add({
        'orderNumber': widget.orderNumber,
        'restaurantName': widget.restaurantName,
        'paymentMethod': widget.paymentMethod,
        'totalAmount': widget.totalAmount,
        'items': widget.itemNames,
        'quantities': widget.itemQuantities,
        'prices': widget.itemPrices,
        'subtotal': widget.subtotal,
        'deliveryFee': widget.deliveryFee,
        'platformFee': widget.platformFee,
        'deliveryAddress': widget.deliveryAddress,
        'timestamp': Timestamp.now(),
        'status': 'Pending',
      });
      print('Order details saved successfully');
    } catch (e) {
      print('Error saving order details: $e');
      throw e; // Error ko throw karein taake catch block handle kar sake
    }

    // Seller ko notification send karne ke liye
    try {
      // Seller ID use karte hue Firestore se seller ka document fetch kar rahe hain
      DocumentSnapshot sellerSnapshot = await FirebaseFirestore.instance
          .collection('sellers')
          .doc('ZPr1Ptipi3c6InmKY7Lc5eHM62U2') // Yahan sellerId use karna hai jo 'sellers' collection se match kare
          .get();

      // Check if seller document exists
      if (!sellerSnapshot.exists) {
        print("Seller document does not exist.");
        return; // Handle the error accordingly
      }

      // Safely seller data ko fetch kar rahe hain
      Map<String, dynamic>? sellerData =
      sellerSnapshot.data() as Map<String, dynamic>?;

      if (sellerData == null || !sellerData.containsKey('deviceToken')) {
        print("Device token does not exist.");
        return; // Handle the error accordingly
      }

      String sellerDeviceToken = sellerData['deviceToken']; // Device token from Firestore

      // Notification send karne ke liye function call
      await NotificationService.sendNotificationToSeller(
        sellerDeviceToken,
        context,
        widget.orderNumber,
      );

      print('Notification sent to the seller successfully.');
    } catch (e) {
      print('Error fetching seller device token or sending notification: $e');
    }
  }

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: Duration(seconds: 5),
    );
    _controller.repeat(); // Yeh line timer ko repeat karegi


    // Fetch restaurant ID and then save order details
    _fetchRestaurantId().then((_) {
      if (_selectedRestaurantId != null) {
        _saveOrderDetails();
      } else {
        print('Restaurant ID not found');
      }
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Future<void> _fetchRestaurantId() async {
    try {
      var querySnapshot = await FirebaseFirestore.instance
          .collection('restaurants')
          .where('name', isEqualTo: widget.restaurantName)
          .get();

      if (querySnapshot.docs.isNotEmpty) {
        setState(() {
          _selectedRestaurantId = querySnapshot.docs.first.id;
        });
        print('Restaurant ID fetched: $_selectedRestaurantId');
      } else {
        print('No restaurant found with the name ${widget.restaurantName}');
      }
    } catch (e) {
      print('Error fetching restaurant ID: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    final double fontSize = MediaQuery.of(context).textScaleFactor * 16;
    final double padding = MediaQuery.of(context).size.width * 0.03;

    List<String> displayedItemNames = [];
    for (int i = 0; i < widget.itemNames.length; i++) {
      displayedItemNames
          .add('${widget.itemQuantities[i]}x ${widget.itemNames[i]}');
    }

    return Scaffold(
      appBar: AppBar(
        title: Text('Order Tracking'),
        backgroundColor: Colors.amber,
        centerTitle: true,
        automaticallyImplyLeading: false,
      ),
      backgroundColor: Colors.amber,
      body: Padding(
        padding: EdgeInsets.all(padding),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Obx(() => Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    trackingController.minTime.value > 0
                        ? 'Arriving within ${trackingController.minTime.value} minutes'
                        : 'Order Status: ${trackingController.orderStatus.value}',
                    style: TextStyle(
                      fontSize: fontSize * 1.20,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Orbitron-Bold',
                    ),
                  ),
                  SizedBox(height: 8),
                  trackingController.minTime.value > 0
                      ? AnimatedBuilder(
                    animation: _controller,
                    builder: (context, child) {
                      return LinearProgressIndicator(
                        value: _controller.value,
                        backgroundColor: Colors.amber,
                        valueColor: AlwaysStoppedAnimation<Color>(
                            Colors.black),
                      );
                    },
                  )
                      : SizedBox(), // Hide progress bar when the time is up
                ],
              )),
              SizedBox(height: padding / 2),
              Obx(() => Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    trackingController.minTime.value > 0
                        ? 'Order is being Prepared'
                        : 'Order is being Prepared',
                    style: TextStyle(
                      fontSize: fontSize,
                      fontWeight: FontWeight.w500,
                      color: Colors.black,
                    ),
                  ),
                  SizedBox(height: 8),
                  Text(
                    "When it's ready, the rider will pick up your order and deliver it to your door",
                    style: TextStyle(
                      fontSize: fontSize * 1.04,
                      fontWeight: FontWeight.w400,
                      color: Colors.black,
                    ),
                  ),
                ],
              )),
              SizedBox(height: padding),
              Padding(
                padding: EdgeInsets.all(MediaQuery.of(context).size.width * 0.05), // Responsive padding
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildInfoRow(
                      'Order Number',
                      widget.orderNumber,
                      MediaQuery.of(context).size.width * 0.05, // Responsive font size
                    ),
                    Divider(color: Colors.black, // Yahan par color set karein
                      thickness: 0.3, // Aap thickness bhi set kar sakte hain//
                    ),
                    SizedBox(height: MediaQuery.of(context).size.height * 0.02), // Responsive height
                    _buildInfoRow(
                      'Delivery Address',
                      widget.deliveryAddress,
                      MediaQuery.of(context).size.width * 0.05, // Responsive font size
                    ),
                    Divider(color: Colors.black, // Yahan par color set karein
                      thickness: 0.3, // Aap thickness bhi set kar sakte hain//
                    ),
                    SizedBox(height: MediaQuery.of(context).size.height * 0.01), // Responsive height
                    _buildInfoRow(
                      'Payment Method',
                      widget.paymentMethod,
                      MediaQuery.of(context).size.width * 0.05, // Responsive font size
                    ),
                    Divider(color: Colors.black, // Yahan par color set karein
                      thickness: 0.3, // Aap thickness bhi set kar sakte hain//
                    ),
                    SizedBox(height: MediaQuery.of(context).size.height * 0.01), // Responsive height
                  ],
                ),
              ),

              Padding(
                padding: EdgeInsets.symmetric(vertical: 16.0),
                child: FutureBuilder<String>(
                  future: getDeliveryBoyImageUrl(),
                  builder: (context, snapshot) {
                    if (snapshot.connectionState == ConnectionState.waiting) {
                      return Center(child: CircularProgressIndicator());
                    } else if (snapshot.hasError || !snapshot.hasData) {
                      return Center(child: Icon(Icons.error, color: Colors.red));
                    } else {
                      return LayoutBuilder(
                        builder: (context, constraints) {
                          double imageWidth = constraints.maxWidth * 0.25; // 25% of available width
                          double imageHeight = imageWidth * 0.8; // Maintain aspect ratio

                          return Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: [
                              Image.network(
                                snapshot.data!,
                                width: imageWidth,
                                height: imageHeight,
                                fit: BoxFit.cover,
                                errorBuilder: (context, error, stackTrace) {
                                  return Icon(Icons.error, color: Colors.red);
                                },
                              ),
                              SizedBox(width: 15),
                              ElevatedButton(
                                onPressed: () {
                                  Get.to(Dbchatscreen());
                                },
                                child: Text('Chat with Delivery Boy'),
                                style: ElevatedButton.styleFrom(
                                  foregroundColor: Colors.white,
                                  backgroundColor: Colors.black,
                                  minimumSize: Size(
                                    constraints.maxWidth * 0.7, // 30% of available width
                                    50,
                                  ),
                                ),
                              ),
                            ],
                          );
                        },
                      );
                    }
                  },
                ),
              ),
              Divider(
                thickness: 0.3,
                color: Colors.black,
              ), // Divider after Chat with Delivery Boy section
              Padding(
                padding: EdgeInsets.all(MediaQuery.of(context).size.width * 0.05), // Responsive padding
                child: LayoutBuilder(
                  builder: (context, constraints) {
                    double fontSize = constraints.maxWidth * 0.05; // Responsive font size based on screen width

                    return Row(
                      children: [
                        Text(
                          'Restaurant:',
                          style: TextStyle(
                            fontSize: fontSize * 1.3, // Increase font size for label
                          ),
                        ),
                        Expanded(
                          child: Text(
                            widget.restaurantName,
                            textAlign: TextAlign.end,
                            style: TextStyle(
                              fontSize: fontSize * 1.3, // Increase font size for restaurant name
                            ),
                          ),
                        ),
                      ],
                    );
                  },
                ),
              ),
              Divider(
                thickness: 0.3,
                color: Colors.black,
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  LayoutBuilder(
                    builder: (context, constraints) {
                      // Screen width ke hisaab se padding aur font size
                      double padding = constraints.maxWidth * 0.04; // Responsive padding
                      double fontSize = constraints.maxWidth * 0.05; // Responsive font size

                      return Column(
                        children: List.generate(
                          displayedItemNames.length,
                              (index) => Column(
                            children: [
                              Padding(
                                padding: EdgeInsets.all(padding),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    Expanded( // Wrap text in Expanded to allow it to take available space
                                      child: Text(
                                        displayedItemNames[index],
                                        style: TextStyle(
                                          fontSize: fontSize * 1.1, // Increase font size for item names
                                        ),
                                        overflow: TextOverflow.visible, // Allow text to wrap
                                      ),
                                    ),
                                    Text(
                                      'Rs. ${widget.itemPrices[index] * widget.itemQuantities[index]}',
                                      style: TextStyle(
                                        fontSize: fontSize * 1.1, // Increase font size for prices
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              if (index < displayedItemNames.length - 1) // Divider except for the last item
                                Divider(
                                  thickness: 0.3,
                                  color: Colors.black,
                                ),
                            ],
                          ),
                        ),
                      );

                    },
                  ),
                ],
              ),
              Divider(
                thickness: 0.3,
                color: Colors.black,
              ),
              // Payment Details Section
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Payment details',
                        style: TextStyle(
                            fontWeight: FontWeight.bold, fontSize: 18)),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('Platform Fee', style: TextStyle(fontSize: 16)),
                        Text('Rs ${widget.platformFee.toStringAsFixed(2)}',
                            style: TextStyle(fontSize: 16)),
                      ],
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('Delivery Fee', style: TextStyle(fontSize: 16)),
                        Text('Rs ${widget.deliveryFee.toStringAsFixed(2)}',
                            style: TextStyle(fontSize: 16)),
                      ],
                    ),
                    _buildPaymentDetailRow('Total Payment', widget.totalAmount),
                  ],
                ),
              ),
              Divider(thickness: 0.3, color: Colors.black),
              // Review Form Section
              Padding(
                padding: EdgeInsets.all(padding),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    TextField(
                      controller: _reviewController,
                      decoration: InputDecoration(
                          labelText:
                          'First, finish your food, then submit your food review.',
                          labelStyle: TextStyle(fontSize: 12)),
                    ),
                    SizedBox(height: 10),
                    RatingBar.builder(
                      initialRating: _rating,
                      minRating: 1,
                      direction: Axis.horizontal,
                      allowHalfRating: true,
                      itemCount: 5,
                      itemPadding: EdgeInsets.symmetric(horizontal: 4.0),
                      itemBuilder: (context, _) => Icon(
                        Icons.star,
                        color: Colors.black,
                      ),
                      onRatingUpdate: (rating) {
                        setState(() {
                          _rating = rating;
                        });
                      },
                    ),
                    SizedBox(height: 10),
                    ElevatedButton(
                      onPressed: () {
                        if (_reviewController.text.isNotEmpty && _rating > 0) {
                          _submitReview();
                        } else {
                          Get.snackbar('Error',
                              'Please write a review and provide a rating before submitting');
                        }
                      },
                      child: Text('Submit Review'),
                      style: ElevatedButton.styleFrom(
                        foregroundColor: Colors.white,
                        backgroundColor: Colors.black, // Button text ka color
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildInfoRow(String title, String value, double fontSize) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      crossAxisAlignment: CrossAxisAlignment.start, // To align the text properly
      children: [
        Expanded(
          child: Text(
            title,
            style: TextStyle(fontSize: fontSize, fontWeight: FontWeight.bold), // Title font size
          ),
        ),
        Expanded(
          child: Text(
            value,
            style: TextStyle(fontSize: fontSize), // Value font size
            maxLines: 12, // Maximum 6 lines tak show karega
            overflow: TextOverflow.visible, // Text ko wrap karne ke liye overflow visible rakhen
          ),
        ),
      ],
    );
  }

  Widget _buildPaymentDetailRow(String label, double amount) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: TextStyle(fontSize: 16),
          ),
          Text(
            'Rs ${amount.toStringAsFixed(2)}',
            style: TextStyle(fontSize: 16),
          ),
        ],
      ),
    );
  }

  void _submitReview() async {
    if (_selectedRestaurantId != null) {
      try {
        await FirebaseFirestore.instance
            .collection('restaurants')
            .doc(_selectedRestaurantId)
            .collection('reviews')
            .add({
          'review': _reviewController.text,
          'rating': _rating,
          'createdAt': FieldValue.serverTimestamp(),
        });
        Get.snackbar('Success', 'Review submitted successfully');
        _reviewController.clear();
        setState(() {
          _rating = 0.0;
        });
      } catch (e) {
        Get.snackbar('Error', 'Failed to submit review: $e');
      }
    } else {
      Get.snackbar('Error', 'Restaurant ID not found');
    }
  }
}
