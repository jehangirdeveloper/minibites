import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:minibites/controllers/buyer_dashboard_pages_controller/buyer_dashboard_controller.dart';
import 'package:minibites/models/buyer_dashboard_pages_models/buyer_dashboard_model.dart';
import 'package:minibites/views/screens/buyer_dashboard/Crafted%20Cuisine_all_type_foods_pages/restaurantlistpage.dart';
import 'package:minibites/views/screens/buyer_dashboard/help_center_screen.dart';
import 'package:minibites/views/screens/buyer_dashboard/settings_screen.dart';
import 'package:minibites/views/screens/on_boarding_page/on_boarding_screen.dart';
import 'package:minibites/views/screens/splash_screen.dart';
import 'package:minibites/views/screens/buyer_dashboard/menupage.dart';

class BuyerDashboard extends StatelessWidget {

  late final String restaurantId;
  @override
  Widget build(BuildContext context) {
    final BuyerDashboardController controller = Get.put(BuyerDashboardController());

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.amber,
        automaticallyImplyLeading: false,
        title: Row(
          children: const [
            Icon(Icons.fastfood),
            SizedBox(width: 8),
            Text('Mini Bites Mart', style: TextStyle(fontSize: 18)),
          ],
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: TextField(
                decoration: InputDecoration(
                  hintText: 'Search Food',
                  prefixIcon: Icon(Icons.search),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
                onChanged: (value) {
                  controller.searchCuisine(value);
                },
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: GestureDetector(
                onTap:
                     () {
                  Get.to(() => RestaurantListPage(category: 'Burgers'));
                }
                    ,
                child: Container(
                  width: double.infinity,
                  height: 150,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.2),
                        blurRadius: 4.0,
                        spreadRadius: 1.0,
                      ),
                    ],
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(8),
                    child: Image.asset(
                      'images/buyer-dashboard-banner-image-1.jpg',
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
              ),
            ),
            
            Padding(
              padding: const EdgeInsets.all(4.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SizedBox(
                    width: 240, // Desired width
                    child: Text(
                      'Cuisine Crafted with Care',
                      style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
                      textAlign: TextAlign.center, // Center the text
                    ),
                  ),
                  Obx(
                        () => GridView.builder(
                      shrinkWrap: true,
                      physics: NeverScrollableScrollPhysics(),
                      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 4,
                        childAspectRatio: 1,
                      ),
                      itemCount: controller.searchResults.length,
                      itemBuilder: (context, index) {
                        final cuisine = controller.searchResults[index];
                        return GestureDetector(
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => _getCuisinePage(cuisine),
                              ),
                            );
                          },
                          child: _buildCuisineItem(cuisine),
                        );
                      },
                    ),
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Hot Deals',
                    style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 8),
                  SizedBox(
                    height: 300, // Adjust height as needed
                    child: SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      child: Row(
                        children: [
                          GestureDetector(
                            onTap: () {
                              Get.to(RestaurantListPage(category: 'Pizza')); // Navigate to a specific screen
                            },
                            child: Container(
                              height: 300, // Specify a height
                              width: 300,  // Add width for consistency
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(8),
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.black.withOpacity(0.2),
                                    blurRadius: 4.0,
                                    spreadRadius: 1.0,
                                  ),
                                ],
                              ),
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(8),
                                child: Image.asset(
                                  'images/hot-deal-1.jpg',
                                  fit: BoxFit.cover, // Makes sure the image fits properly within the container
                                ),
                              ),
                            ),
                          ),
                          SizedBox(width: 8), // Add spacing between images
                          GestureDetector(
                            onTap: () {
                              Get.to(RestaurantListPage(category: 'Shawarma')); // Navigate to a specific screen
                            },
                            child: Container(
                              height: 300,
                              width: 300,  // Add width for consistency
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(8),
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.black.withOpacity(0.2),
                                    blurRadius: 4.0,
                                    spreadRadius: 1.0,
                                  ),
                                ],
                              ),
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(8),
                                child: Image.asset('images/hot-deal-2.jpg', fit: BoxFit.cover),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            )

          ],
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.help),
            label: 'Help Center',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.assignment_return_outlined),
            label: 'Sign Out',
          ),
        ],
        onTap: (index) async {
          switch (index) {
            case 0:
              Get.to(HelpCenterScreen()); // Navigate to HelpCenterPage
              break;
            case 1:
              try {
                await FirebaseAuth.instance.signOut(); // Perform sign out
                Get.to(OnboardingScreen()); // Navigate to OnboardingScreen after sign out
              } catch (e) {
                // Handle any errors here
                print('Sign out error: $e');
              }
              break;
          }
        },
      ),
    );
  }

  Widget _buildCuisineItem(Cuisine cuisine) {
    return LayoutBuilder(
      builder: (context, constraints) {
        // Zyada bara responsive sizing
        double containerWidth = constraints.maxWidth * 1; // Thoda zyada width
        double circleSize = containerWidth * 0.6; // Bara circle size
        double imageSize = containerWidth * 0.6; // Image size same as circle size
        double textSize = containerWidth * 0.1; // Bara text size

        // Ensuring everything fits within constraints
        return Container(
          width: containerWidth,
          padding: EdgeInsets.all(5.0), // Zyada padding for better spacing
          decoration: BoxDecoration(
            // color: Colors.amber[200], // Background color diya
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Container(
                width: circleSize,
                height: circleSize,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.white70,
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.2),
                      blurRadius: 6.0, // Bara blur radius
                      spreadRadius: 2.0, // Zyada spread radius
                    ),
                  ],
                ),
                child: ClipOval(
                  child: Image.asset(
                    cuisine.imageUrl,
                    fit: BoxFit.cover, // Ensure image fits inside circle
                    width: imageSize,
                    height: imageSize,
                  ),
                ),
              ),
              SizedBox(height: 8.0), // Space between image and text reduced slightly
              ConstrainedBox(
                constraints: BoxConstraints(
                  maxWidth: containerWidth * 0.85, // Ensure text does not exceed container width
                ),
                child: Text(
                  cuisine.name,
                  style: TextStyle(
                    fontSize: textSize, // Responsive text size
                    fontWeight: FontWeight.bold,
                  ),
                  textAlign: TextAlign.center,
                  overflow: TextOverflow.ellipsis, // Handle overflow by ellipsis
                  softWrap: false, // Prevent long text from wrapping
                ),
              ),
            ],
          ),
        );
      },
    );
  }


  Widget _getCuisinePage(Cuisine cuisine) {
    switch (cuisine.name) {
      case 'Pizza':
        return RestaurantListPage(category: 'Pizza');
      case 'Burgers':
        return RestaurantListPage(category: 'Burgers');
      case 'Haleem':
        return RestaurantListPage(category: 'Haleem');
      case 'Pulao':
        return RestaurantListPage(category: 'Pulao');
      case 'Biryani':
        return RestaurantListPage(category: 'Biryani');
      case 'Pasta':
        return RestaurantListPage(category: 'Pasta');
      case 'Paratha Roll':
        return RestaurantListPage(category: 'Paratha Roll');
      case 'BBQ':
        return RestaurantListPage(category: 'BBQ');
      case 'Shawarma':
        return RestaurantListPage(category: 'Shawarma');
      case 'Pak Food':
        return RestaurantListPage(category: 'Pak Food');
      case 'Ice Cream':
        return RestaurantListPage(category: 'Ice Cream');
      case 'Chinese':
        return RestaurantListPage(category: 'Chinese');
      case 'Samosa':
        return RestaurantListPage(category: 'Samosa');
      case 'Desserts':
        return RestaurantListPage(category: 'Desserts');
      case 'Fish':
        return RestaurantListPage(category: 'Fish');
      case 'Sweet Dish':
        return RestaurantListPage(category: 'Sweet Dish');
      default:
        return SplashScreen(); // Default page if no match
    }
  }
}
