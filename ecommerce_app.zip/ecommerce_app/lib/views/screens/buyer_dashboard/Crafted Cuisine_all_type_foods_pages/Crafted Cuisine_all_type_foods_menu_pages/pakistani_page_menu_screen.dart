// import 'package:minibites/controllers/buyer_dashboard_pages_controller/Crafted%20Cuisine_all_type_foods_controller/Crafted%20Cuisine_all_type_foods_menu_controller/pakistani_page_menu_controller.dart';
// import 'package:minibites/views/screens/buyer_dashboard/cart_page_screen.dart';
// import 'package:minibites/views/screens/buyer_dashboard/review_page.dart';
// import 'package:flutter/material.dart';
// import 'package:get/get.dart';
//
// class PakistaniPageMenuScreen extends StatefulWidget {
//   @override
//   _PakistaniPageMenuScreenState createState() => _PakistaniPageMenuScreenState();
// }
//
// class _PakistaniPageMenuScreenState extends State<PakistaniPageMenuScreen> with SingleTickerProviderStateMixin {
//   final PakistaniPageMenuController pakistaniPageMenuController = Get.put(PakistaniPageMenuController());
//   late TabController _tabController;
//   final ScrollController _scrollController = ScrollController();
//   bool _isTabTapped = false;
//
//   // Keys for categories
//   final Map<String, GlobalKey> _categoryKeys = {
//     'PakFood Deals': GlobalKey(),
//     'Pakistani': GlobalKey(),
//     'Grilled PakFood': GlobalKey(),
//   };
//
//   @override
//   void initState() {
//     super.initState();
//     _tabController = TabController(length: _categoryKeys.length, vsync: this);
//     _scrollController.addListener(_onScroll);
//   }
//
//   @override
//   void dispose() {
//     _scrollController.dispose();
//     _tabController.dispose();
//     super.dispose();
//   }
//
//   void _onScroll() {
//     if (_isTabTapped) return; // Ignore if tab was tapped
//
//     final pakistaniPageMenuController = Get.find<PakistaniPageMenuController>(); // Get controller
//
//     for (int i = 0; i < pakistaniPageMenuController.categories.length; i++) {
//       final category = pakistaniPageMenuController.categories[i].name;
//       final key = _categoryKeys[category];
//
//       if (key != null) {
//         final context = key.currentContext;
//         if (context != null) {
//           final box = context.findRenderObject() as RenderBox?;
//           if (box != null) {
//             final position = box.localToGlobal(Offset.zero).dy;
//
//             if (position <= kToolbarHeight + _tabController.index * 50 &&
//                 position + box.size.height > kToolbarHeight) {
//               _tabController.animateTo(i);
//               break;
//             }
//           }
//         }
//       }
//     }
//   }
//
//   void _scrollToCategory(int index) {
//     _isTabTapped = true; // Tab tap tracking
//     final pakistaniPageMenuController = Get.find<PakistaniPageMenuController>();
//     final category = pakistaniPageMenuController.categories[index].name;
//     final key = _categoryKeys[category];
//     if (key != null) {
//       Scrollable.ensureVisible(
//         key.currentContext!,
//         duration: Duration(seconds: 1),
//       ).then((_) => _isTabTapped = false); // Re-enable scroll tracking
//     }
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     final pakistaniPageMenuController = Get.put(PakistaniPageMenuController()); // Initialize controller
//     final width = MediaQuery.of(context).size.width;
//     final itemWidth = width / 5;
//
//     return DefaultTabController(
//       length: _categoryKeys.length,
//       child: Scaffold(
//         backgroundColor: Colors.white,
//         appBar: AppBar(
//           title: Text('Pakistani Food'),
//           backgroundColor: Colors.white,
//           leading: IconButton(
//             icon: Icon(Icons.arrow_back),
//             color: Colors.black,
//             onPressed: () {
//               Navigator.push(
//                 context,
//                 MaterialPageRoute(
//                   builder: (context) => CartPageScreen(restaurantName: 'Pakistani Food'),
//                 ),
//               );
//
//             },
//           ),
//           actions: [
//             Obx(() {
//               return IconButton(
//                 icon: Stack(
//                   children: [
//                     Icon(Icons.shopping_cart),
//                     if (pakistaniPageMenuController.cartItemCount.value > 0)
//                       Positioned(
//                         right: 0,
//                         child: Container(
//                           padding: EdgeInsets.all(2),
//                           decoration: BoxDecoration(
//                             color: Colors.red,
//                             borderRadius: BorderRadius.circular(6),
//                           ),
//                           constraints: BoxConstraints(
//                             minWidth: 16,
//                             minHeight: 16,
//                           ),
//                           child: Center(
//                             child: Text(
//                               '${pakistaniPageMenuController.cartItemCount.value}',
//                               style: TextStyle(
//                                 color: Colors.white,
//                                 fontSize: 12,
//                                 fontWeight: FontWeight.bold,
//                               ),
//                             ),
//                           ),
//                         ),
//                       ),
//                   ],
//                 ),
//                 onPressed: () {
//                   Navigator.push(
//                     context,
//                     MaterialPageRoute(
//                       builder: (context) => CartPageScreen(restaurantName: 'Pakistani Food'),
//                     ),
//                   );
//
//                 },
//               );
//             }),
//             IconButton(icon: Icon(Icons.search), onPressed: () {}),
//           ],
//         ),
//         body: Obx(() {
//           return CustomScrollView(
//             controller: _scrollController,
//             slivers: [
//               SliverList(
//                 delegate: SliverChildListDelegate([
//                   Padding(
//                     padding: const EdgeInsets.all(8.0),
//                     child: Card(
//                       child: Padding(
//                         padding: const EdgeInsets.all(8.0),
//                         child: Column(
//                           crossAxisAlignment: CrossAxisAlignment.start,
//                           children: [
//                             Row(
//                               children: [
//                                 Image.asset(
//                                   'images/Pakistani-food-menu-images/pakistani-food-menu-image-1.png',
//                                   width: 60,
//                                   height: 60,
//                                 ),
//                                 SizedBox(width: 10),
//                                 Column(
//                                   crossAxisAlignment: CrossAxisAlignment.start,
//                                   children: [
//                                     Text(
//                                       'Pakistani Food',
//                                       style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
//                                     ),
//                                   ],
//                                 ),
//                               ],
//                             ),
//                             SizedBox(height: 10),
//                             Row(
//                               mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                               children: [
//                                 Row(
//                                   children: [
//                                     Icon(Icons.star, color: Colors.amber),
//                                     Text('4.0 | 100+ ratings'),
//                                   ],
//                                 ),
//                                 GestureDetector(
//                                   onTap: () {
//                                     Get.to(ReviewPage());
//                                   },
//                                   child: Text(
//                                     'View Reviews',
//                                     style: TextStyle(
//                                       color: Colors.black, // Optional: Change text color to indicate it's clickable
//                                     ),
//                                   ),
//                                 ),
//                               ],
//                             ),
//                             SizedBox(height: 10),
//                           ],
//                         ),
//                       ),
//                     ),
//                   ),
//                 ]),
//               ),
//               SliverPersistentHeader(
//                 pinned: true,
//                 delegate: _SliverAppBarDelegate(
//                   TabBar(
//                     controller: _tabController,
//                     onTap: _scrollToCategory,
//                     tabs: _categoryKeys.keys
//                         .map((categoryName) => Tab(text: categoryName))
//                         .toList(),
//                   ),
//                 ),
//               ),
//               SliverList(
//                 delegate: SliverChildListDelegate(
//                   pakistaniPageMenuController.categories.map((category) {
//                     return Column(
//                       key: _categoryKeys[category.name],
//                       crossAxisAlignment: CrossAxisAlignment.start,
//                       children: [
//                         Padding(
//                           padding: const EdgeInsets.all(8.0),
//                           child: Text(category.name, style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
//                         ),
//                         ListView.builder(
//                           shrinkWrap: true,
//                           physics: NeverScrollableScrollPhysics(),
//                           itemCount: category.items.length,
//                           itemBuilder: (context, itemIndex) {
//                             final item = category.items[itemIndex];
//                             return Padding(
//                               padding: const EdgeInsets.symmetric(horizontal: 8.0),
//                               child: ListTile(
//                                 leading: Image.asset(
//                                   item.image.assetName,
//                                   width: itemWidth,
//                                   height: itemWidth,
//                                   fit: BoxFit.cover,
//                                 ),
//                                 title: Text(item.name),
//                                 subtitle: Column(
//                                   crossAxisAlignment: CrossAxisAlignment.start,
//                                   children: [
//                                     Text('from Rs. ${item.price}'),
//                                     if (item.isPopular)
//                                       Chip(
//                                         label: Text('Popular Deal', style: TextStyle(color: Colors.black)),
//                                       ),
//                                   ],
//                                 ),
//                                 trailing: IconButton(
//                                   icon: Icon(Icons.add),
//                                   onPressed: () {
//                                     pakistaniPageMenuController.addToCart(item, 'Pakistani Food');
//                                     ScaffoldMessenger.of(context).showSnackBar(
//                                       SnackBar(
//                                         content: Text('${item.name} added to cart'),
//                                       ),
//                                     );
//                                   },
//                                 ),
//                               ),
//                             );
//                           },
//                         ),
//                         Divider(),
//                       ],
//                     );
//                   }).toList(),
//                 ),
//               ),
//             ],
//           );
//         }),
//         bottomNavigationBar: Obx(() {
//           return BottomAppBar(
//             child: InkWell(
//               onTap: () {
//                 Navigator.push(
//                   context,
//                   MaterialPageRoute(
//                     builder: (context) => CartPageScreen(restaurantName: 'Pakistani Food'),
//                   ),
//                 );
//
//               },
//               child: Container(
//                 color: Colors.blueGrey,
//                 child: Row(
//                   mainAxisAlignment: MainAxisAlignment.center,
//                   children: [
//                     Flexible(
//                       child: Container(
//                         alignment: Alignment.center,
//                         child: Text(
//                           'View your cart',
//                           style: TextStyle(
//                             fontSize: 18,
//                             fontWeight: FontWeight.bold,
//                             color: Colors.white,
//                           ),
//                         ),
//                       ),
//                     ),
//                     SizedBox(width: 10),
//                     Flexible(
//                       child: Container(
//                         alignment: Alignment.center,
//                         child: Text(
//                           'Rs. ${pakistaniPageMenuController.totalAmount.value}',
//                           style: TextStyle(
//                             fontSize: 18,
//                             fontWeight: FontWeight.bold,
//                             color: Colors.white,
//                           ),
//                           overflow: TextOverflow.ellipsis,
//                         ),
//                       ),
//                     ),
//                   ],
//                 ),
//               ),
//             ),
//           );
//         }),
//       ),
//     );
//   }
// }
//
// class _SliverAppBarDelegate extends SliverPersistentHeaderDelegate {
//   final TabBar _tabBar;
//
//   _SliverAppBarDelegate(this._tabBar);
//
//   @override
//   double get minExtent => _tabBar.preferredSize.height;
//   @override
//   double get maxExtent => _tabBar.preferredSize.height;
//
//   @override
//   Widget build(BuildContext context, double shrinkOffset, bool overlapsContent) {
//     return Container(
//       color: Colors.white,
//       child: _tabBar,
//     );
//   }
//
//   @override
//   bool shouldRebuild(_SliverAppBarDelegate oldDelegate) {
//     return false;
//   }
// }
