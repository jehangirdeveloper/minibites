// import 'package:minibites/controllers/buyer_dashboard_pages_controller/Crafted%20Cuisine_all_type_foods_controller/Crafted%20Cuisine_all_type_foods_menu_controller/chinese_page_menu_controller.dart';
// import 'package:minibites/views/screens/buyer_dashboard/cart_page_screen.dart';
// import 'package:minibites/views/screens/buyer_dashboard/review_page.dart';
// import 'package:flutter/material.dart';
// import 'package:get/get.dart';
//
// class ChinesePageMenuScreen extends StatefulWidget {
//   @override
//   _ChinesePageMenuScreenState createState() => _ChinesePageMenuScreenState();
// }
//
// class _ChinesePageMenuScreenState extends State<ChinesePageMenuScreen> with SingleTickerProviderStateMixin {
//   final ChinesePageMenuController chinesePageMenuController = Get.put(ChinesePageMenuController());
//   late TabController _tabController;
//   final ScrollController _scrollController = ScrollController();
//   bool _isTabTapped = false;
//
//   // Keys for categories
//   final Map<String, GlobalKey> _categoryKeys = {
//     'Chinese Deals': GlobalKey(),
//     'Chinese': GlobalKey(),
//     'Grilled Chinese': GlobalKey(),
//   };
//
//   @override
//   void initState() {
//     super.initState();
//     _tabController = TabController(length: _categoryKeys.length, vsync: this);
//     _scrollController.addListener(_onScroll);
//   }
//
//   @override
//   void dispose() {
//     _scrollController.dispose();
//     _tabController.dispose();
//     super.dispose();
//   }
//
//   void _onScroll() {
//     if (_isTabTapped) return; // Ignore if tab was tapped
//
//     final chinesePageMenuController = Get.find<ChinesePageMenuController>(); // Get controller
//
//     for (int i = 0; i < chinesePageMenuController.categories.length; i++) {
//       final category = chinesePageMenuController.categories[i].name;
//       final key = _categoryKeys[category];
//
//       if (key != null) {
//         final context = key.currentContext;
//         if (context != null) {
//           final box = context.findRenderObject() as RenderBox?;
//           if (box != null) {
//             final position = box.localToGlobal(Offset.zero).dy;
//
//             if (position <= kToolbarHeight + _tabController.index * 50 &&
//                 position + box.size.height > kToolbarHeight) {
//               _tabController.animateTo(i);
//               break;
//             }
//           }
//         }
//       }
//     }
//   }
//
//   void _scrollToCategory(int index) {
//     _isTabTapped = true; // Tab tap tracking
//     final chinesePageMenuController = Get.find<ChinesePageMenuController>();
//     final category = chinesePageMenuController.categories[index].name;
//     final key = _categoryKeys[category];
//     if (key != null) {
//       Scrollable.ensureVisible(
//         key.currentContext!,
//         duration: Duration(seconds: 1),
//       ).then((_) => _isTabTapped = false); // Re-enable scroll tracking
//     }
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     final chinesePageMenuController = Get.put(ChinesePageMenuController()); // Initialize controller
//     final width = MediaQuery.of(context).size.width;
//     final itemWidth = width / 5;
//
//     return DefaultTabController(
//       length: _categoryKeys.length,
//       child: Scaffold(
//         backgroundColor: Colors.white,
//         appBar: AppBar(
//           title: Text('Famous Chinese'),
//           backgroundColor: Colors.white,
//           leading: IconButton(
//             icon: Icon(Icons.arrow_back),
//             color: Colors.black,
//             onPressed: () {
//               Navigator.push(
//                 context,
//                 MaterialPageRoute(
//                   builder: (context) => CartPageScreen(restaurantName: 'Famous Chinese'),
//                 ),
//               );
//
//             },
//           ),
//           actions: [
//             Obx(() {
//               return IconButton(
//                 icon: Stack(
//                   children: [
//                     Icon(Icons.shopping_cart),
//                     if (chinesePageMenuController.cartItemCount.value > 0)
//                       Positioned(
//                         right: 0,
//                         child: Container(
//                           padding: EdgeInsets.all(2),
//                           decoration: BoxDecoration(
//                             color: Colors.red,
//                             borderRadius: BorderRadius.circular(6),
//                           ),
//                           constraints: BoxConstraints(
//                             minWidth: 16,
//                             minHeight: 16,
//                           ),
//                           child: Center(
//                             child: Text(
//                               '${chinesePageMenuController.cartItemCount.value}',
//                               style: TextStyle(
//                                 color: Colors.white,
//                                 fontSize: 12,
//                                 fontWeight: FontWeight.bold,
//                               ),
//                             ),
//                           ),
//                         ),
//                       ),
//                   ],
//                 ),
//                 onPressed: () {
//                   Navigator.push(
//                     context,
//                     MaterialPageRoute(
//                       builder: (context) => CartPageScreen(restaurantName: 'Famous Chinese'),
//                     ),
//                   );
//
//                 },
//               );
//             }),
//             IconButton(icon: Icon(Icons.search), onPressed: () {}),
//           ],
//         ),
//         body: Obx(() {
//           return CustomScrollView(
//             controller: _scrollController,
//             slivers: [
//               SliverList(
//                 delegate: SliverChildListDelegate([
//                   Padding(
//                     padding: const EdgeInsets.all(8.0),
//                     child: Card(
//                       child: Padding(
//                         padding: const EdgeInsets.all(8.0),
//                         child: Column(
//                           crossAxisAlignment: CrossAxisAlignment.start,
//                           children: [
//                             Row(
//                               children: [
//                                 Image.asset(
//                                   'images/chinese-menu-images/chinese-page-menu-image-1.png',
//                                   width: 60,
//                                   height: 60,
//                                 ),
//                                 SizedBox(width: 10),
//                                 Column(
//                                   crossAxisAlignment: CrossAxisAlignment.start,
//                                   children: [
//                                     Text(
//                                       'Famous Chinese',
//                                       style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
//                                     ),
//                                   ],
//                                 ),
//                               ],
//                             ),
//                             SizedBox(height: 10),
//                             Row(
//                               mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                               children: [
//                                 Row(
//                                   children: [
//                                     Icon(Icons.star, color: Colors.amber),
//                                     Text('4.0 | 100+ ratings'),
//                                   ],
//                                 ),
//                                 GestureDetector(
//                                   onTap: () {
//                                     Get.to(ReviewPage());
//                                   },
//                                   child: Text(
//                                     'View Reviews',
//                                     style: TextStyle(
//                                       color: Colors.black, // Optional: Change text color to indicate it's clickable
//                                     ),
//                                   ),
//                                 ),
//                               ],
//                             ),
//                             SizedBox(height: 10),
//                           ],
//                         ),
//                       ),
//                     ),
//                   ),
//                 ]),
//               ),
//               SliverPersistentHeader(
//                 pinned: true,
//                 delegate: _SliverAppBarDelegate(
//                   TabBar(
//                     controller: _tabController,
//                     onTap: _scrollToCategory,
//                     tabs: _categoryKeys.keys
//                         .map((categoryName) => Tab(text: categoryName))
//                         .toList(),
//                   ),
//                 ),
//               ),
//               SliverList(
//                 delegate: SliverChildListDelegate(
//                   chinesePageMenuController.categories.map((category) {
//                     return Column(
//                       key: _categoryKeys[category.name],
//                       crossAxisAlignment: CrossAxisAlignment.start,
//                       children: [
//                         Padding(
//                           padding: const EdgeInsets.all(8.0),
//                           child: Text(category.name, style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
//                         ),
//                         ListView.builder(
//                           shrinkWrap: true,
//                           physics: NeverScrollableScrollPhysics(),
//                           itemCount: category.items.length,
//                           itemBuilder: (context, itemIndex) {
//                             final item = category.items[itemIndex];
//                             return Padding(
//                               padding: const EdgeInsets.symmetric(horizontal: 8.0),
//                               child: ListTile(
//                                 leading: Image.asset(
//                                   item.image.assetName,
//                                   width: itemWidth,
//                                   height: itemWidth,
//                                   fit: BoxFit.cover,
//                                 ),
//                                 title: Text(item.name),
//                                 subtitle: Column(
//                                   crossAxisAlignment: CrossAxisAlignment.start,
//                                   children: [
//                                     Text('from Rs. ${item.price}'),
//                                     if (item.isPopular)
//                                       Chip(
//                                         label: Text('Popular Deal', style: TextStyle(color: Colors.black)),
//                                       ),
//                                   ],
//                                 ),
//                                 trailing: IconButton(
//                                   icon: Icon(Icons.add),
//                                   onPressed: () {
//                                     chinesePageMenuController.addToCart(item, 'Famous Chinese');
//                                     ScaffoldMessenger.of(context).showSnackBar(
//                                       SnackBar(
//                                         content: Text('${item.name} added to cart'),
//                                       ),
//                                     );
//                                   },
//                                 ),
//                               ),
//                             );
//                           },
//                         ),
//                         Divider(),
//                       ],
//                     );
//                   }).toList(),
//                 ),
//               ),
//             ],
//           );
//         }),
//         bottomNavigationBar: Obx(() {
//           return BottomAppBar(
//             child: InkWell(
//               onTap: () {
//                 Navigator.push(
//                   context,
//                   MaterialPageRoute(
//                     builder: (context) => CartPageScreen(restaurantName: 'Famous Chinese'),
//                   ),
//                 );
//
//               },
//               child: Container(
//                 color: Colors.blueGrey,
//                 child: Row(
//                   mainAxisAlignment: MainAxisAlignment.center,
//                   children: [
//                     Flexible(
//                       child: Container(
//                         alignment: Alignment.center,
//                         child: Text(
//                           'View your cart',
//                           style: TextStyle(
//                             fontSize: 18,
//                             fontWeight: FontWeight.bold,
//                             color: Colors.white,
//                           ),
//                         ),
//                       ),
//                     ),
//                     SizedBox(width: 10),
//                     Flexible(
//                       child: Container(
//                         alignment: Alignment.center,
//                         child: Text(
//                           'Rs. ${chinesePageMenuController.totalAmount.value}',
//                           style: TextStyle(
//                             fontSize: 18,
//                             fontWeight: FontWeight.bold,
//                             color: Colors.white,
//                           ),
//                           overflow: TextOverflow.ellipsis,
//                         ),
//                       ),
//                     ),
//                   ],
//                 ),
//               ),
//             ),
//           );
//         }),
//       ),
//     );
//   }
// }
//
// class _SliverAppBarDelegate extends SliverPersistentHeaderDelegate {
//   final TabBar _tabBar;
//
//   _SliverAppBarDelegate(this._tabBar);
//
//   @override
//   double get minExtent => _tabBar.preferredSize.height;
//   @override
//   double get maxExtent => _tabBar.preferredSize.height;
//
//   @override
//   Widget build(BuildContext context, double shrinkOffset, bool overlapsContent) {
//     return Container(
//       color: Colors.white,
//       child: _tabBar,
//     );
//   }
//
//   @override
//   bool shouldRebuild(_SliverAppBarDelegate oldDelegate) {
//     return false;
//   }
// }
