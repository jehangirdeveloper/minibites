import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:minibites/views/screens/buyer_dashboard/menupage.dart';

class RestaurantListPage extends StatefulWidget {
  final String category;

  RestaurantListPage({required this.category});

  @override
  _RestaurantListPageState createState() => _RestaurantListPageState();
}

class _RestaurantListPageState extends State<RestaurantListPage> {
  TextEditingController _searchController = TextEditingController();
  String searchQuery = '';
  String selectedCountry = '';
  String selectedCity = '';

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  bool isRestaurantOpen(String openingTime, String closingTime) {
    // Pakistan ka waqt lagane ke liye UTC time mein 5 ghantay add karna
    final now = DateTime.now().toUtc().add(Duration(hours: 24)); // Pakistan GMT+5

    final opening = DateFormat('h:mm a').parse(openingTime);
    final closing = DateFormat('h:mm a').parse(closingTime);

    final openingTimeToday = DateTime(now.year, now.month, now.day, opening.hour, opening.minute);
    DateTime closingTimeToday;

    // Agar closing time 12:00 AM ke baad ho, to agle din ka time consider karo
    if (closing.hour < opening.hour || (closing.hour == opening.hour && closing.minute < opening.minute)) {
      closingTimeToday = DateTime(now.year, now.month, now.day + 1, closing.hour, closing.minute);
    } else {
      closingTimeToday = DateTime(now.year, now.month, now.day, closing.hour, closing.minute);
    }

    // Check karna hai ke restaurant open hai ya nahi
    return now.isAfter(openingTimeToday) && now.isBefore(closingTimeToday);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.amber,
        title: Text('${widget.category}'),
        bottom: PreferredSize(
          preferredSize: Size.fromHeight(120.0),
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: TextField(
                  controller: _searchController,
                  onChanged: (value) {
                    setState(() {
                      searchQuery = value.toLowerCase();
                    });
                  },
                  decoration: InputDecoration(
                    hintText: 'Search restaurants...',
                    prefixIcon: Icon(Icons.search),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(15),
                      borderSide: BorderSide.none,
                    ),
                    filled: true,
                    fillColor: Colors.white,
                  ),
                ),
              ),
              // Country and City Filters Side by Side
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Row(
                  children: [
                    // Dropdown for Country
                    Expanded(
                      child: DropdownButtonFormField<String>(
                        decoration: InputDecoration(
                          labelText: "Select Country",
                          border: OutlineInputBorder(),
                        ),
                        value: selectedCountry.isEmpty ? null : selectedCountry,
                        onChanged: (value) {
                          setState(() {
                            selectedCountry = value ?? '';
                          });
                        },
                        items: ['Pakistan',]
                            .map((country) => DropdownMenuItem<String>(
                          value: country,
                          child: Text(country),
                        ))
                            .toList(),
                      ),
                    ),
                    SizedBox(width: 10), // Space between the filters
                    // Dropdown for City
                    Expanded(
                      child: DropdownButtonFormField<String>(
                        decoration: InputDecoration(
                          labelText: "Select City",
                          border: OutlineInputBorder(),
                        ),
                        value: selectedCity.isEmpty ? null : selectedCity,
                        onChanged: (value) {
                          setState(() {
                            selectedCity = value ?? '';
                          });
                        },
                        items: ['Attock City',]
                            .map((city) => DropdownMenuItem<String>(
                          value: city,
                          child: Text(city),
                        ))
                            .toList(),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection('restaurants')
            .where('category', isEqualTo: widget.category)
            .where('country', isEqualTo: selectedCountry.isNotEmpty ? selectedCountry : null)
            .where('city', isEqualTo: selectedCity.isNotEmpty ? selectedCity : null)
            .snapshots(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          }
          if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return Center(child: Text('No restaurants found'));
          }

          final docs = snapshot.data!.docs;

          final filteredDocs = docs.where((doc) {
            final data = doc.data() as Map<String, dynamic>;
            final name = data['name'] ?? '';
            return name.toLowerCase().contains(searchQuery);
          }).toList();

          filteredDocs.sort((a, b) {
            final dataA = a.data() as Map<String, dynamic>;
            final dataB = b.data() as Map<String, dynamic>;

            final isOpenA = isRestaurantOpen(dataA['openingTime'] ?? '12:00 AM', dataA['closingTime'] ?? '11:59 PM');
            final isOpenB = isRestaurantOpen(dataB['openingTime'] ?? '12:00 AM', dataB['closingTime'] ?? '11:59 PM');

            return isOpenA ? -1 : (isOpenB ? 1 : 0);
          });

          return ListView.builder(
            itemCount: filteredDocs.length,
            itemBuilder: (context, index) {
              final data = filteredDocs[index].data() as Map<String, dynamic>;
              final name = data['name'] ?? 'No Name';
              final imageUrl = data['imageUrl'] ?? 'https://via.placeholder.com/150';
              final restaurantCategory = data['category'] ?? 'No Category';
              final openingTime = data['openingTime'] ?? '12:00 AM';
              final closingTime = data['closingTime'] ?? '11:59 PM';
              final restaurantId = filteredDocs[index].id;
              final country = data['country'] ?? 'Unknown Country';  // Add this line
              final city = data['city'] ?? 'Unknown City';  // Add this line

              final isOpen = isRestaurantOpen(openingTime, closingTime);

              return Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8.0, vertical: 4.0),
                child: GestureDetector(
                  onTap: isOpen
                      ? () {
                    Get.to(() => MenuPage(restaurantId: restaurantId));
                  }
                      : null,
                  child: Card(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(15.0),
                    ),
                    clipBehavior: Clip.antiAlias,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Stack(
                          children: [
                            Image.network(
                              imageUrl,
                              width: double.infinity,
                              height: 180,
                              fit: BoxFit.fill,
                            ),
                            Container(
                              height: 180,
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  colors: [Colors.black.withOpacity(0.6), Colors.transparent],
                                  begin: Alignment.bottomCenter,
                                  end: Alignment.topCenter,
                                ),
                              ),
                            ),
                          ],
                        ),
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Expanded(
                                    child: Text(
                                      name,
                                      style: TextStyle(
                                        fontSize: 20,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                  SizedBox(width: 5),
                                  Container(
                                    padding: EdgeInsets.symmetric(horizontal: 6, vertical: 6),  // Padding for text inside
                                    decoration: BoxDecoration(
                                      color: Colors.amber,  // Background color
                                      borderRadius: BorderRadius.circular(10),  // Circular edges
                                    ),
                                    child: Text(
                                      restaurantCategory,
                                      style: TextStyle(
                                        fontSize: 15,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.black,
                                      ),
                                    ),
                                  )
                                ],
                              ),
                              SizedBox(height: 4),
                              Row(
                                children: [
                                  Text(
                                    isOpen ? 'Open' : 'Closed',
                                    style: TextStyle(
                                      color: isOpen ? Colors.green : Colors.red,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  Spacer(),
                                  Text(
                                    'Open: $openingTime | Close: $closingTime',
                                    style: TextStyle(
                                      fontSize: 12,
                                      color: Colors.black,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ],
                              ),
                              SizedBox(height: 4), // Add space before country and city
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Row(
                                    children: [
                                      Icon(Icons.location_on, size: 16, color: Colors.black),
                                      SizedBox(width: 4),
                                      Text(
                                        city,
                                        style: TextStyle(
                                          fontSize: 14,
                                          color: Colors.black,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                    ],
                                  ),
                                  Text(
                                    country,
                                    style: TextStyle(
                                      fontSize: 14,
                                      color: Colors.black,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              );
            },
          );

        },
      ),
    );
  }
}
