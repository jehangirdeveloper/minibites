// import 'package:minibites/controllers/buyer_dashboard_pages_controller/Crafted%20Cuisine_all_type_foods_controller/Crafted%20Cuisine_all_type_foods_menu_controller/samosa_page_menu_controller.dart';
// import 'package:minibites/controllers/buyer_dashboard_pages_controller/Crafted%20Cuisine_all_type_foods_controller/bbq_page_controller.dart';
// import 'package:minibites/controllers/buyer_dashboard_pages_controller/Crafted%20Cuisine_all_type_foods_controller/biryani_page_controller.dart';
// import 'package:minibites/controllers/buyer_dashboard_pages_controller/Crafted%20Cuisine_all_type_foods_controller/burgers_page_controller.dart';
// import 'package:minibites/controllers/buyer_dashboard_pages_controller/Crafted%20Cuisine_all_type_foods_controller/fast_food_page_controller.dart';
// import 'package:minibites/controllers/buyer_dashboard_pages_controller/Crafted%20Cuisine_all_type_foods_controller/paratha_page_controller.dart';
// import 'package:minibites/controllers/buyer_dashboard_pages_controller/Crafted%20Cuisine_all_type_foods_controller/pasta_page_controller.dart';
// import 'package:minibites/controllers/buyer_dashboard_pages_controller/Crafted%20Cuisine_all_type_foods_controller/pizza_page_controller.dart';
// import 'package:minibites/controllers/buyer_dashboard_pages_controller/Crafted%20Cuisine_all_type_foods_controller/pulao_page_controller.dart';
// import 'package:minibites/controllers/buyer_dashboard_pages_controller/Crafted%20Cuisine_all_type_foods_controller/samosa_page_controller.dart';
// import 'package:minibites/views/screens/buyer_dashboard/Crafted%20Cuisine_all_type_foods_pages/Crafted%20Cuisine_all_type_foods_menu_pages/samosa_page_menu_screen.dart';
// import 'package:flutter/material.dart';
// import 'package:get/get.dart';
// import 'package:minibites/controllers/buyer_dashboard_pages_controller/buyer_dashboard_controller.dart';
//
// class SamosaPage extends StatefulWidget {
//   const SamosaPage({super.key});
//
//   @override
//   State<SamosaPage> createState() => _SamosaPageState();
// }
//
// class _SamosaPageState extends State<SamosaPage> {
//   final SamosaPageController controller = Get.put(SamosaPageController());
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(title: Text('Samosa')),
//       body: SingleChildScrollView(
//         child: Column(
//           children: [
//             SizedBox(height: 10), // AppBar ke neeche thoda space dene ke liye
//             Padding(
//               padding: const EdgeInsets.symmetric(horizontal: 16.0),
//               child: Column(
//                 children: [
//                   SingleChildScrollView(
//                     scrollDirection: Axis.horizontal, // Horizontal scrolling enable karta hai
//                     child: Row(
//                       children: [
//                         ElevatedButton.icon(
//                           onPressed: () {
//                             // Filter button ka action
//                           },
//                           icon: Icon(Icons.filter_list),
//                           label: Text('Filter'),
//                           style: ElevatedButton.styleFrom(
//                             shape: StadiumBorder(),
//                           ),
//                         ),
//                         SizedBox(width: 8), // Buttons ke darmiyan space dene ke liye
//                         ElevatedButton.icon(
//                           onPressed: () {
//                             // Sort button ka action
//                           },
//                           icon: Icon(Icons.sort),
//                           label: Text('Sort'),
//                           style: ElevatedButton.styleFrom(
//                             shape: StadiumBorder(),
//                           ),
//                         ),
//                         SizedBox(width: 8),
//                         ElevatedButton.icon(
//                           onPressed: () {
//                             // Ratings filter ka action
//                           },
//                           icon: Icon(Icons.star),
//                           label: Text('Ratings 4.0+'),
//                           style: ElevatedButton.styleFrom(
//                             shape: StadiumBorder(),
//                           ),
//                         ),
//                         SizedBox(width: 8),
//                         ElevatedButton.icon(
//                           onPressed: () {
//                             // Offers button ka action
//                           },
//                           icon: Icon(Icons.local_offer),
//                           label: Text('Offers'),
//                           style: ElevatedButton.styleFrom(
//                             shape: StadiumBorder(),
//                           ),
//                         ),
//                         SizedBox(width: 8),
//                         ElevatedButton.icon(
//                           onPressed: () {
//                             // Price button ka action
//                           },
//                           icon: Icon(Icons.attach_money),
//                           label: Text('Price'),
//                           style: ElevatedButton.styleFrom(
//                             shape: StadiumBorder(),
//                           ),
//                         ),
//                         SizedBox(width: 8),
//                         ElevatedButton.icon(
//                           onPressed: () {
//                             // Top restaurant button ka action
//                           },
//                           icon: Icon(Icons.star_rate),
//                           label: Text('Top restaurant'),
//                           style: ElevatedButton.styleFrom(
//                             shape: StadiumBorder(),
//                           ),
//                         ),
//                       ],
//                     ),
//                   ),
//
//                 ],
//               ),
//             ),
//             SizedBox(height: 10), // Buttons ke neeche thoda space dene ke liye
//             Obx(() {
//               return Column(
//                 children: [
//                   GestureDetector(
//                     onTap: () {
//                       Get.to(SamosaPageMenuScreen());
//                     },
//                     child: Column(
//                       crossAxisAlignment: CrossAxisAlignment.start,
//                       children: [
//                         SizedBox(height: 8, width: 20,),
//                         Image(
//                           image: controller.restaurant4.value.image.value!,
//                         ),
//                         Padding(
//                           padding: const EdgeInsets.all(8.0),
//                           child: Row(
//                             children: [
//                               Expanded(
//                                 child: Text(
//                                   controller.restaurant4.value.name,
//                                   style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
//                                 ),
//                               ),
//                               Row(
//                                 children: [
//                                   Icon(Icons.star, color: Colors.orange, size: 16),
//                                   Text(
//                                     '${controller.restaurant4.value.rating} (${controller.restaurant4.value.reviews}+ reviews)',
//                                   ),
//                                 ],
//                               ),
//                             ],
//                           ),
//                         ),
//                         Padding(
//                           padding: const EdgeInsets.all(8.0),
//                           child: Row(
//                             children: [
//                               Text(
//                                 'Min order: PKR ${controller.restaurant4.value.minOrder}',
//                               ),
//                               SizedBox(width: 90),
//                               Text(controller.restaurant4.value.category),
//                               Spacer(),
//                               Text(
//                                 '${controller.restaurant4.value.deliveryTime}-${controller.restaurant4.value.deliveryTime + 15} min',
//                               ),
//                             ],
//                           ),
//                         ),
//                         Padding(
//                           padding: const EdgeInsets.symmetric(horizontal: 8.0),
//                           child: Row(
//                             children: [
//                               Icon(Icons.delivery_dining, size: 16),
//                               Text(' ${controller.restaurant4.value.deliveryFee} PKR'),
//                             ],
//                           ),
//                         ),
//                       ],
//                     ),
//                   ),
//                   Card(
//                     child: Column(
//                       crossAxisAlignment: CrossAxisAlignment.start,
//                       children: [
//                         SizedBox(height: 8, width: 10,),
//                         Image(
//                           image: controller.restaurant5.value.image.value!,
//                         ),
//                         Padding(
//                           padding: const EdgeInsets.all(8.0),
//                           child: Row(
//                             children: [
//                               Expanded(
//                                 child: Text(
//                                   controller.restaurant5.value.name,
//                                   style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
//                                 ),
//                               ),
//                               Row(
//                                 children: [
//                                   Icon(Icons.star, color: Colors.orange, size: 16),
//                                   Text(
//                                     '${controller.restaurant5.value.rating} (${controller.restaurant5.value.reviews}+ reviews)',
//                                   ),
//                                 ],
//                               ),
//                             ],
//                           ),
//                         ),
//                         Padding(
//                           padding: const EdgeInsets.all(8.0),
//                           child: Row(
//                             children: [
//                               Text(
//                                 'Min order: PKR ${controller.restaurant5.value.minOrder}',
//                               ),
//                               SizedBox(width: 90),
//                               Text(controller.restaurant5.value.category),
//                               Spacer(),
//                               Text(
//                                 '${controller.restaurant5.value.deliveryTime}-${controller.restaurant5.value.deliveryTime + 15} min',
//                               ),
//                             ],
//                           ),
//                         ),
//                         Padding(
//                           padding: const EdgeInsets.symmetric(horizontal: 8.0),
//                           child: Row(
//                             children: [
//                               Icon(Icons.delivery_dining, size: 16),
//                               Text(' ${controller.restaurant5.value.deliveryFee} PKR'),
//                             ],
//                           ),
//                         ),
//                       ],
//                     ),
//                   ),
//                   Card(
//                     child: Column(
//                       crossAxisAlignment: CrossAxisAlignment.start,
//                       children: [
//                         SizedBox(height: 8, width: 10,),
//                         Image(
//                           image: controller.restaurant6.value.image.value!,
//                         ),
//                         Padding(
//                           padding: const EdgeInsets.all(8.0),
//                           child: Row(
//                             children: [
//                               Expanded(
//                                 child: Text(
//                                   controller.restaurant6.value.name,
//                                   style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
//                                 ),
//                               ),
//                               Row(
//                                 children: [
//                                   Icon(Icons.star, color: Colors.orange, size: 16),
//                                   Text(
//                                     '${controller.restaurant6.value.rating} (${controller.restaurant6.value.reviews}+ reviews)',
//                                   ),
//                                 ],
//                               ),
//                             ],
//                           ),
//                         ),
//                         Padding(
//                           padding: const EdgeInsets.all(8.0),
//                           child: Row(
//                             children: [
//                               Text(
//                                 'Min order: PKR ${controller.restaurant6.value.minOrder}',
//                               ),
//                               SizedBox(width: 90),
//                               Text(controller.restaurant6.value.category),
//                               Spacer(),
//                               Text(
//                                 '${controller.restaurant6.value.deliveryTime}-${controller.restaurant6.value.deliveryTime + 15} min',
//                               ),
//                             ],
//                           ),
//                         ),
//                         Padding(
//                           padding: const EdgeInsets.symmetric(horizontal: 8.0),
//                           child: Row(
//                             children: [
//                               Icon(Icons.delivery_dining, size: 16),
//                               Text(' ${controller.restaurant6.value.deliveryFee} PKR'),
//                             ],
//                           ),
//                         ),
//                       ],
//                     ),
//                   ),
//                 ],
//               );
//             }),
//           ],
//         ),
//       ),
//     );
//   }
// }
