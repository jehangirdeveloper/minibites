// import 'package:minibites/controllers/buyer_dashboard_pages_controller/Crafted%20Cuisine_all_type_foods_controller/pizza_page_controller.dart';
// import 'package:minibites/views/screens/buyer_dashboard/Crafted%20Cuisine_all_type_foods_pages/Crafted%20Cuisine_all_type_foods_menu_pages/pizza_page_menu_screen.dart';
// import 'package:flutter/material.dart';
// import 'package:get/get.dart';
// import 'package:minibites/controllers/buyer_dashboard_pages_controller/buyer_dashboard_controller.dart';
//
// class PizzaPage extends StatefulWidget {
//   const PizzaPage({super.key});
//
//   @override
//   State<PizzaPage> createState() => _PizzaPageState();
// }
//
// class _PizzaPageState extends State<PizzaPage> {
//   final PizzaPageController controller = Get.put(PizzaPageController());
//
//   void _navigateToMenuScreen() {
//     Navigator.push(
//       context,
//       MaterialPageRoute(builder: (context) => PizzaPageMenuScreen()),
//     );
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(title: Text('Pizza')),
//       body: SingleChildScrollView(
//         child: Column(
//           children: [
//             SizedBox(height: 10),
//             Padding(
//               padding: const EdgeInsets.symmetric(horizontal: 16.0),
//               child: Column(
//                 children: [
//                   SingleChildScrollView(
//                     scrollDirection: Axis.horizontal,
//                     child: Row(
//                       children: [
//                         ElevatedButton.icon(
//                           onPressed: () {},
//                           icon: Icon(Icons.filter_list),
//                           label: Text('Filter'),
//                           style: ElevatedButton.styleFrom(
//                             shape: StadiumBorder(),
//                           ),
//                         ),
//                         SizedBox(width: 8),
//                         ElevatedButton.icon(
//                           onPressed: () {},
//                           icon: Icon(Icons.sort),
//                           label: Text('Sort'),
//                           style: ElevatedButton.styleFrom(
//                             shape: StadiumBorder(),
//                           ),
//                         ),
//                         SizedBox(width: 8),
//                         ElevatedButton.icon(
//                           onPressed: () {},
//                           icon: Icon(Icons.star),
//                           label: Text('Ratings 4.0+'),
//                           style: ElevatedButton.styleFrom(
//                             shape: StadiumBorder(),
//                           ),
//                         ),
//                         SizedBox(width: 8),
//                         ElevatedButton.icon(
//                           onPressed: () {},
//                           icon: Icon(Icons.local_offer),
//                           label: Text('Offers'),
//                           style: ElevatedButton.styleFrom(
//                             shape: StadiumBorder(),
//                           ),
//                         ),
//                         SizedBox(width: 8),
//                         ElevatedButton.icon(
//                           onPressed: () {},
//                           icon: Icon(Icons.attach_money),
//                           label: Text('Price'),
//                           style: ElevatedButton.styleFrom(
//                             shape: StadiumBorder(),
//                           ),
//                         ),
//                         SizedBox(width: 8),
//                         ElevatedButton.icon(
//                           onPressed: () {},
//                           icon: Icon(Icons.star_rate),
//                           label: Text('Top restaurant'),
//                           style: ElevatedButton.styleFrom(
//                             shape: StadiumBorder(),
//                           ),
//                         ),
//                       ],
//                     ),
//                   ),
//                 ],
//               ),
//             ),
//             SizedBox(height: 10),
//             Obx(() {
//               var value;
//               return Column(
//                 children: [
//                   GestureDetector(
//                     onTap: _navigateToMenuScreen,
//                     child: Card(
//                       child: Column(
//                         crossAxisAlignment: CrossAxisAlignment.start,
//                         children: [
//                           SizedBox(height: 8, width: 20),
//                           Image.network(controller.restaurant4.value.image), // Image added here
//                         ],
//                       ),
//                     ),
//                   ),
//                 ],
//               );
//             }),
//           ],
//         ),
//       ),
//     );
//   }
// }
