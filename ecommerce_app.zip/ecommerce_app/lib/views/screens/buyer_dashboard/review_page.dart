import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart'; // Import for RatingBarIndicator

class ReviewPage extends StatelessWidget {
  final String restaurantId;
  final String restaurantName;

  ReviewPage({required this.restaurantId, required this.restaurantName,});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('$restaurantName Reviews'),
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection('restaurants')
            .doc(restaurantId)
            .collection('reviews')
            .orderBy('createdAt', descending: true) // Ensure timestamp field name is 'createdAt'
            .snapshots(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          }

          if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          }

          if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return Center(child: Text('No reviews available for this restaurant.'));
          }

          var reviews = snapshot.data!.docs;

          return ListView.builder(
            itemCount: reviews.length,
            itemBuilder: (context, index) {
              var review = reviews[index];
              // Use default values if fields are null
              String reviewText = review['review'] ?? 'No review text available';
              double rating = review['rating']?.toDouble() ?? 0.0;

              return ListTile(
                title: Text(reviewText),
                trailing: RatingBarIndicator(
                  rating: rating,
                  itemCount: 5,
                  itemSize: 20.0,
                  direction: Axis.horizontal,
                  itemBuilder: (context, _) => Icon(
                    Icons.star,
                    color: Colors.amber,
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
