// lib/screens/checkout_page_screen.dart
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:geocoding/geocoding.dart';
import 'dart:math';
import 'package:minibites/controllers/buyer_dashboard_pages_controller/checkout_page_screen_controller.dart';
import 'package:minibites/models/buyer_dashboard_pages_models/checkout_page_screen_model.dart';
import 'package:minibites/views/screens/buyer_dashboard/order_tracking_screen.dart';

class CheckoutPageScreen extends StatefulWidget {
  final List<CheckoutPageScreenModel> checkoutItems;
  final double subtotal;
  final String restaurantId;
  final double totalAmount;

  CheckoutPageScreen({
    required this.checkoutItems,
    required this.subtotal,
    required this.restaurantId,
    required this.totalAmount, required String restaurantName,
  });

  @override
  _CheckoutPageScreenState createState() => _CheckoutPageScreenState();
}

class _CheckoutPageScreenState extends State<CheckoutPageScreen> {
  late CheckoutPageScreenController controller;
  final TextEditingController addressController = TextEditingController();
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>(); // Form key defined here
  LatLng _currentLocation = LatLng(33.6844, 73.0479); // Default location
  Set<Marker> _markers = {};
  GoogleMapController? _mapController;

  @override
  void initState() {
    super.initState();
    controller = Get.put(CheckoutPageScreenController());
    _addMarker(_currentLocation); // Default marker
  }

  void _placeOrder() async {
    // Generate a random order number
    String orderNumber = _generateOrderNumber();

    // Fetch restaurant name from Firestore
    String restaurantName = await controller.fetchRestaurantName(widget.restaurantId);

    // Navigate to OrderTrackingScreen with details
    Get.to(OrderTrackingScreen(
      itemNames: widget.checkoutItems.map((item) => item.name).toList(),
      itemPrices: widget.checkoutItems.map((item) => item.price).toList(),
      itemQuantities: widget.checkoutItems.map((item) => item.quantity).toList(),
      subtotal: widget.subtotal,
      deliveryFee: 50,
      platformFee: 20,
      totalAmount: widget.totalAmount,
      paymentMethod: 'Cash On Delivery',
      orderNumber: orderNumber,
      restaurantName: restaurantName,
      deliveryAddress: addressController.text,
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Checkout'),
      ),
      body: LayoutBuilder(
        builder: (context, constraints) {
          return SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Google Map Section
                Container(
                  height: 300, // Map height
                  child: GoogleMap(
                    initialCameraPosition: CameraPosition(
                      target: _currentLocation,
                      zoom: 14.0,
                    ),
                    markers: _markers,
                    onMapCreated: (GoogleMapController controller) {
                      _mapController = controller;
                    },
                  ),
                ),
                SizedBox(height: 16),

                // Address Input Field
                Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Form(
                    key: _formKey, // Form key for validation
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        TextFormField(
                          controller: addressController,
                          decoration: InputDecoration(
                            labelText: 'Enter Your Delivery Address',
                            border: OutlineInputBorder(),
                            suffixIcon: IconButton(
                              icon: Icon(Icons.search),
                              onPressed: _searchAddress, // Search functionality
                            ),
                          ),
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Please Enter Your Delivery Address'; // Error message
                            }
                            return null;
                          },
                          onFieldSubmitted: (value) {
                            if (_formKey.currentState!.validate()) {
                              _searchAddress(); // Search only if valid
                            }
                          },
                        ),
                      ],
                    ),
                  ),
                ),

                // Cart Items List
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Menus',
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                    SizedBox(height: 8),
                    ...widget.checkoutItems.map((item) {
                      return Column(
                        children: [
                          Padding(
                            padding: const EdgeInsets.symmetric(vertical: 4.0),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Expanded(
                                  child: Text(
                                    '${item.name} x${item.quantity}',
                                    style: TextStyle(fontSize: 16),
                                    maxLines: 12, // Maximum 6 lines tak show karega
                                    overflow: TextOverflow.visible, // Text wrap karne ke liye
                                  ),
                                ),
                                SizedBox(width: 10), // Thoda gap add karen
                                Text(
                                  'Rs ${item.price * item.quantity}',
                                  style: TextStyle(fontSize: 16),
                                ),
                              ],
                            ),
                          ),
                          Divider( // Yeh Divider items ko alag karega
                            thickness: 1, // Divider ka thickness set karein
                            color: Colors.grey, // Divider ka color
                          ),
                        ],
                      );
                    }).toList(),
                  ],
                ),
              ),
                // Payment Details Section
                Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Payment details', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
                      SizedBox(height: 16),
                      _buildPaymentDetailRow('Platform Fee', 20),
                      _buildPaymentDetailRow('Delivery Fee', 50),
                      _buildPaymentDetailRow('Total Payment', widget.totalAmount),
                    ],
                  ),
                ),
                Divider(),

                // Payment Method Section
                Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Payment method', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
                      SizedBox(height: 16),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          _buildPaymentMethodOption('Cash On Delivery', Icons.money, true),
                        ],
                      ),
                    ],
                  ),
                ),

                // Place Order Button
                Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: ElevatedButton(
                    onPressed: () {
                      // Form validate karne ka check lagaya gaya hai
                      if (_formKey.currentState!.validate()) {
                        _placeOrder();
                      } else {
                        // Agar form valid nahi hai to user ko error show kiya jayega
                        Get.snackbar(
                          'Error',
                          'Please enter your delivery address',
                          backgroundColor: Colors.red,
                          colorText: Colors.white,
                        );
                      }
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.amber,
                      padding: EdgeInsets.symmetric(vertical: 16),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                    ),
                    child: Center(
                      child: Text('Place Order', style: TextStyle(color: Colors.white, fontSize: 18)),
                    ),
                  ),
                ),

              ],
            ),
          );
        },
      ),
    );
  }

  Widget _buildPaymentDetailRow(String label, double amount, {bool isBold = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: TextStyle(fontSize: 16, fontWeight: isBold ? FontWeight.bold : FontWeight.normal)),
          Text('Rs ${amount.toStringAsFixed(0)}', style: TextStyle(fontSize: 16, fontWeight: isBold ? FontWeight.bold : FontWeight.normal)),
        ],
      ),
    );
  }

  Widget _buildPaymentMethodOption(String method, IconData icon, bool isSelected) {
    return Column(
      children: [
        CircleAvatar(
          radius: 25,
          backgroundColor: isSelected ? Colors.green : Colors.grey.shade300,
          child: Icon(icon, color: Colors.white),
        ),
        SizedBox(height: 8),
        Text(method),
      ],
    );
  }

  void _addMarker(LatLng position) {
    setState(() {
      _markers.add(
        Marker(
          markerId: MarkerId(position.toString()),
          position: position,
          infoWindow: InfoWindow(title: 'Selected Location'),
        ),
      );
    });
  }

  void _searchAddress() async {
    try {
      List<Location> locations = await locationFromAddress(addressController.text);
      if (locations.isNotEmpty) {
        Location location = locations.first;
        LatLng newLocation = LatLng(location.latitude, location.longitude);

        _mapController?.animateCamera(CameraUpdate.newLatLng(newLocation));
        _addMarker(newLocation);

        setState(() {
          _currentLocation = newLocation;
        });
      }
    } catch (e) {
      print('Error: $e');
    }
  }

  String _generateOrderNumber() {
    var random = Random();
    return 'ORD${random.nextInt(9999999).toString().padLeft(7, '0')}';
  }
}
