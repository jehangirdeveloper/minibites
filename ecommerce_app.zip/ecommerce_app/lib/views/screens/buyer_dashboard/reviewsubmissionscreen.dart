// import 'package:flutter/material.dart';
// import 'package:cloud_firestore/cloud_firestore.dart';
//
// class ReviewSubmissionScreen extends StatefulWidget {
//   final String restaurantId;
//
//   ReviewSubmissionScreen({required this.restaurantId});
//
//   @override
//   _ReviewSubmissionScreenState createState() => _ReviewSubmissionScreenState();
// }
//
// class _ReviewSubmissionScreenState extends State<ReviewSubmissionScreen> {
//   final _formKey = GlobalKey<FormState>();
//   final _reviewController = TextEditingController();
//   final _ratingController = TextEditingController();
//
//   void _submitReview() async {
//     if (_formKey.currentState!.validate()) {
//       final reviewText = _reviewController.text;
//       final rating = int.parse(_ratingController.text);
//
//       // Save review to Firestore
//       await FirebaseFirestore.instance.collection('restaurants').doc(widget.restaurantId).collection('reviews').add({
//         'reviewText': reviewText,
//         'rating': rating,
//         'userId': 'user123', // Replace with actual user ID
//         'timestamp': FieldValue.serverTimestamp(),
//       });
//
//       // Go back to previous screen
//       Navigator.pop(context);
//     }
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(title: Text('Submit Review')),
//       body: Padding(
//         padding: const EdgeInsets.all(16.0),
//         child: Form(
//           key: _formKey,
//           child: Column(
//             children: [
//               TextFormField(
//                 controller: _reviewController,
//                 decoration: InputDecoration(labelText: 'Review'),
//                 validator: (value) {
//                   if (value == null || value.isEmpty) {
//                     return 'Please enter a review';
//                   }
//                   return null;
//                 },
//               ),
//               TextFormField(
//                 controller: _ratingController,
//                 keyboardType: TextInputType.number,
//                 decoration: InputDecoration(labelText: 'Rating (1-5)'),
//                 validator: (value) {
//                   if (value == null || value.isEmpty) {
//                     return 'Please enter a rating';
//                   }
//                   final rating = int.tryParse(value);
//                   if (rating == null || rating < 1 || rating > 5) {
//                     return 'Please enter a rating between 1 and 5';
//                   }
//                   return null;
//                 },
//               ),
//               SizedBox(height: 20),
//               ElevatedButton(
//                 onPressed: _submitReview,
//                 child: Text('Submit Review'),
//               ),
//             ],
//           ),
//         ),
//       ),
//     );
//   }
// }
