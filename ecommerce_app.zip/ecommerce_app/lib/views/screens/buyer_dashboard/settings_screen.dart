// settings_page.dart
import 'package:minibites/controllers/buyer_dashboard_pages_controller/settings_screen_controller.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class SettingsScreen extends StatefulWidget {
  @override
  _SettingsScreenState createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final SettingsScreenController settingsScreenController = Get.put(SettingsScreenController());

  final TextEditingController nameController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController addressController = TextEditingController();
  final TextEditingController mobileNumberController = TextEditingController();

  @override
  void initState() {
    super.initState();
    nameController.text = settingsScreenController.settings.name.value;
    emailController.text = settingsScreenController.settings.email.value;
    addressController.text = settingsScreenController.settings.address.value;
    mobileNumberController.text = settingsScreenController.settings.mobileNumber.value;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Settings'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: LayoutBuilder(
          builder: (context, constraints) {
            // Adjust the layout based on the available width
            double formWidth = constraints.maxWidth > 600 ? 500 : constraints.maxWidth;

            return Center(
              child: SizedBox(
                width: formWidth,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Add this text at the top
                    SizedBox(height: 80),
                    Center(
                      child: Text(
                        'Update Your Settings',
                        style: TextStyle(
                          fontSize: 20, // Increase font size
                          fontWeight: FontWeight.bold, // Make text bold
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                    SizedBox(height: 10), // Space between the heading and form
                    Text('Name', style: Theme.of(context).textTheme.bodyMedium),
                    TextField(
                      controller: nameController,
                      decoration: InputDecoration(border: OutlineInputBorder()),
                      onChanged: (value) => settingsScreenController.updateName(value),
                    ),
                    SizedBox(height: 16),
                    Text('Email', style: Theme.of(context).textTheme.bodyMedium),
                    TextField(
                      controller: emailController,
                      decoration: InputDecoration(border: OutlineInputBorder()),
                      onChanged: (value) => settingsScreenController.updateEmail(value),
                    ),
                    SizedBox(height: 16),
                    Text('Address', style: Theme.of(context).textTheme.bodyMedium),
                    TextField(
                      controller: addressController,
                      decoration: InputDecoration(border: OutlineInputBorder()),
                      onChanged: (value) => settingsScreenController.updateAddress(value),
                    ),
                    SizedBox(height: 16),
                    Text('Mobile Number', style: Theme.of(context).textTheme.bodyMedium),
                    TextField(
                      controller: mobileNumberController,
                      decoration: InputDecoration(border: OutlineInputBorder()),
                      keyboardType: TextInputType.phone,
                      onChanged: (value) => settingsScreenController.updateMobileNumber(value),
                    ),
                    SizedBox(height: 20),
                    Center(
                      child: ElevatedButton(
                        onPressed: () {
                          // Save settings
                          Get.snackbar('Settings', 'Settings have been updated');
                        },
                        style: ElevatedButton.styleFrom(
                          foregroundColor: Colors.white, backgroundColor: Colors.blue, minimumSize: Size(200, 50), // Text color
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(8), // Rounded corners
                          ),
                        ),
                        child: Text('Save Settings'),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}
