import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:minibites/controllers/seller_dashboard_controller/MenuController.dart'
    as sellerMenuController;
import 'package:minibites/controllers/buyer_dashboard_pages_controller/Cart_Controller.dart';
import 'package:minibites/controllers/buyer_dashboard_pages_controller/RestaurantController.dart';
import 'package:minibites/controllers/seller_dashboard_controller/RestaurantController.dart';
import 'package:minibites/models/MenuItem.dart' as modelMenuItem;
import 'package:minibites/views/screens/buyer_dashboard/cart_page_screen.dart';
import 'package:minibites/views/screens/buyer_dashboard/review_page.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class MenuPage extends StatelessWidget {
  final String restaurantId;

  MenuPage({required this.restaurantId}) {
    final sellerMenuController.MenuController menuController =
        Get.put(sellerMenuController.MenuController());
    final RestaurantController restaurantController =
        Get.put(RestaurantController());
    menuController.fetchMenuItemsForRestaurant(restaurantId);
    restaurantController.fetchRestaurantDetails(restaurantId);
  }

  @override
  Widget build(BuildContext context) {
    final sellerMenuController.MenuController menuController =
        Get.find<sellerMenuController.MenuController>();
    final CartController cartController = Get.find<CartController>();
    final RestaurantController restaurantController =
        Get.find<RestaurantController>();

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.amber,
        title: Obx(() => Text(
          '${restaurantController.restaurantName.value} Menu',
          style: TextStyle(fontSize: 20.0),
        )),
        actions: [
          Obx(() => IconButton(
            icon: Stack(
              children: [
                Icon(Icons.shopping_cart),
                if (cartController.totalItems > 0)
                  Positioned(
                    right: 0,
                    child: Container(
                      padding: EdgeInsets.all(2),
                      decoration: BoxDecoration(
                        color: Colors.red,
                        borderRadius: BorderRadius.circular(6),
                      ),
                      constraints: BoxConstraints(
                        maxWidth: 20,
                        maxHeight: 20,
                      ),
                      child: Center(
                        child: Text(
                          '${cartController.totalItems}',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 12,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                  ),
              ],
            ),
            onPressed: () {
              Get.to(CartPageScreen(
                restaurantName: restaurantId,
                restaurantId: '',
              ));
            },
          )),
        ],
        bottom: PreferredSize(
          preferredSize: Size.fromHeight(70.0), // Total height for AppBar including search bar
          child: Padding(
            padding: const EdgeInsets.all(12.0), // Padding around the search bar
            child: Container(
              height: 50.0, // Height of the search bar
              decoration: BoxDecoration(
                color: Colors.white, // Background color of search bar
                borderRadius: BorderRadius.circular(30.0), // Circular sides
              ),
              child: TextField(
                onChanged: (value) {
                  menuController.searchMenuItems(value);
                },
                decoration: InputDecoration(
                  hintText: 'Search menu...',
                  hintStyle: TextStyle(color: Colors.grey),
                  prefixIcon: Icon(Icons.search, color: Colors.grey),
                  border: InputBorder.none, // Removes default underline
                  contentPadding: EdgeInsets.symmetric(vertical: 10.0, horizontal: 16.0),
                ),
                style: TextStyle(color: Colors.black),
              ),
            ),
          ),
        ),
      ),
      body: Obx(() {
        if (restaurantController.restaurantName.value.isEmpty) {
          return Center(child: CircularProgressIndicator());
        } else {
          return LayoutBuilder(
            builder: (context, constraints) {
              return Column(
                children: [
                  Container(
                    margin: EdgeInsets.all(16.0),
                    padding: EdgeInsets.all(16.0),
                    decoration: BoxDecoration(
                      color: Colors.amber,
                      borderRadius: BorderRadius.circular(18.0),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.grey.withOpacity(0.2),
                          spreadRadius: 2,
                          blurRadius: 8,
                          offset: Offset(0, 2), // changes position of shadow
                        ),
                      ],
                    ),
                    child: Row(
                      children: [
                        StreamBuilder<DocumentSnapshot>(
                          stream: FirebaseFirestore.instance
                              .collection('restaurants')
                              .doc(
                                  restaurantId) // restaurantId should be passed from previous page
                              .snapshots(),
                          builder: (context, snapshot) {
                            if (snapshot.connectionState ==
                                ConnectionState.waiting) {
                              return CircularProgressIndicator(); // Show loading indicator while fetching data
                            }

                            if (snapshot.hasError) {
                              return Icon(Icons
                                  .error); // Show error icon if there's an error
                            }

                            if (!snapshot.hasData || !snapshot.data!.exists) {
                              return Icon(Icons
                                  .image_not_supported); // Show fallback icon if no data is found
                            }

                            // Fetch restaurant image URL from Firestore
                            var restaurantData =
                                snapshot.data!.data() as Map<String, dynamic>;
                            String imageUrl = restaurantData['imageUrl'] ??
                                'https://via.placeholder.com/150'; // Fallback image

                            return CircleAvatar(
                              backgroundImage: NetworkImage(imageUrl),
                              radius: 30, // Set size of the CircleAvatar
                            );
                          },
                        ),
                        SizedBox(width: 16.0),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                restaurantController.restaurantName.value,
                                style: TextStyle(
                                  fontSize: 18.0,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),

                            ],
                          ),
                        ),
                        TextButton(
                          onPressed: () {
                            Get.to(() => ReviewPage(
                                  restaurantId: restaurantId,
                                  restaurantName:
                                      restaurantController.restaurantName.value,
                                ));
                          },
                          child: Text(
                            'View Reviews',
                            style: TextStyle(
                              fontSize: 12.0,
                              // fontWeight: FontWeight.bold,
                              color: Colors.black,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),

                  SizedBox(height: 16.0),
                  Expanded(
                    child: Obx(() {
                      if (menuController.filteredItems.isEmpty) {
                        return Center(child: Text('No menu found'));
                      }
                      return SingleChildScrollView(
                        child: Column(
                          children: [
                            ListView.builder(
                              padding: EdgeInsets.all(16.0),
                              shrinkWrap: true,
                              physics: NeverScrollableScrollPhysics(),
                              itemCount: menuController.filteredItems.length,
                              itemBuilder: (context, index) {
                                final item =
                                    menuController.filteredItems[index];
                                return Card(
                                  elevation: 4.0,
                                  margin: EdgeInsets.only(bottom: 16.0),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(16.0),
                                  ),
                                  child: Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child: Row(
                                      children: [
                                        ClipRRect(
                                          borderRadius:
                                              BorderRadius.circular(16.0),
                                          child: item.imageUrl.isNotEmpty
                                              ? Image.network(item.imageUrl,
                                                  width: 80,
                                                  height: 80,
                                                  fit: BoxFit.cover)
                                              : SizedBox(width: 80, height: 80),
                                        ),
                                        SizedBox(width: 12.0),
                                        Expanded(
                                          child: Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              Text(
                                                item.name,
                                                style: TextStyle(
                                                    fontSize: 16,
                                                    fontWeight:
                                                        FontWeight.bold),
                                              ),
                                              SizedBox(height: 4.0),
                                              Text(
                                                'Rs. ${item.price}',
                                                style: TextStyle(
                                                    fontSize: 14,
                                                    color: Colors.black),
                                              ),
                                              SizedBox(height: 4.0),
                                              if (item.dealPrice != null &&
                                                  item.dealPrice! >
                                                      0) // Check if it's a deal
                                                Container(
                                                  padding: EdgeInsets.symmetric(
                                                      horizontal: 8.0,
                                                      vertical: 4.0),
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            16.0),
                                                    border: Border.all(
                                                        color: Colors.orange),
                                                  ),
                                                  child: Text(
                                                    'Popular Deal',
                                                    style: TextStyle(
                                                        color: Colors.orange,
                                                        fontWeight:
                                                            FontWeight.bold),
                                                  ),
                                                ),
                                            ],
                                          ),
                                        ),
                                        IconButton(
                                          icon: Icon(Icons.add_circle_outline,
                                              color: Colors.orange),
                                          onPressed: () {
                                            cartController.addToCart(
                                                modelMenuItem.MenuItem(
                                              id: item.id,
                                              name: item.name,
                                              imageUrl: item.imageUrl,
                                              price: item.price,
                                              dealPrice: item.dealPrice,
                                              quantity: 1,
                                              category: item.category,
                                            ));
                                          },
                                        ),
                                      ],
                                    ),
                                  ),
                                );
                              },
                            ),
                          ],
                        ),
                      );
                    }),
                  ),
                ],
              );
            },
          );
        }
      }),
      bottomNavigationBar: Obx(() {
        double totalPrice = cartController.getTotalPrice();
        return Container(
          padding: EdgeInsets.all(16.0),
          color: Colors.grey.shade200,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              ElevatedButton(
                onPressed: () {
                  Get.to(() => CartPageScreen(
                        restaurantId: restaurantId,
                        restaurantName: '',
                      ));
                },
                child: Text('View your cart'),
                style: ElevatedButton.styleFrom(
                  padding:
                      EdgeInsets.symmetric(horizontal: 32.0, vertical: 16.0),
                  backgroundColor: Colors.amber,
                ),
              ),
              Text(
                'Rs. ${totalPrice.toStringAsFixed(2)}',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
            ],
          ),
        );
      }),
    );
  }
}
