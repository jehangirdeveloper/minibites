import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:minibites/views/screens/buyer_dashboard/buyer_dashboard.dart';
import 'package:minibites/views/screens/seller_dashboard/seller_dashboard.dart';
import 'package:minibites/views/screens/on_boarding_page/on_boarding_screen.dart';

class SplashScreen extends StatefulWidget {
  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    _checkUser();
  }

  Future<void> _checkUser() async {
    await Future.delayed(Duration(seconds: 3)); // Splash screen delay

    User? user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      bool isBuyerUser = await isBuyer(user.uid);
      bool isSellerUser = await isSeller(user.uid);
      print('User ID: ${user.uid}');
      print('Is Buyer: $isBuyerUser');
      print('Is Seller: $isSellerUser');

      if (isBuyerUser) {
        print("Navigating to BuyerDashboard");
        Get.offAll(() => BuyerDashboard());
      } else if (isSellerUser) {
        print("Navigating to SellerDashboard");
        Get.offAll(() => SellerDashboard());
      } else {
        print("User is neither Buyer nor Seller, navigating to OnboardingScreen");
        Get.offAll(() => OnboardingScreen());
      }
    } else {
      print("No user logged in, navigating to OnboardingScreen");
      Get.offAll(() => OnboardingScreen());
    }
  }

  Future<bool> isBuyer(String uid) async {
    try {
      DocumentSnapshot doc = await FirebaseFirestore.instance
          .collection('buyers') // Ensure this matches your Firestore collection name
          .doc(uid)
          .get();
      print('Buyer Document Exists: ${doc.exists}');
      return doc.exists;
    } catch (e) {
      print('Error checking if user is buyer: $e');
      return false;
    }
  }

  Future<bool> isSeller(String uid) async {
    try {
      DocumentSnapshot doc = await FirebaseFirestore.instance
          .collection('sellers') // Ensure this matches your Firestore collection name
          .doc(uid)
          .get();
      print('Seller Document Exists: ${doc.exists}');
      return doc.exists;
    } catch (e) {
      print('Error checking if user is seller: $e');
      return false;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.yellow,
      appBar: AppBar(
        backgroundColor: Colors.yellow,
        elevation: 0,
      ),
      body: Center(
        child: Padding(
          padding: EdgeInsets.symmetric(
            horizontal: MediaQuery.of(context).size.width * 0.05,
            vertical: MediaQuery.of(context).size.height * 0.02,
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Spacer(),
              Text(
                'Mini Bites',
                style: TextStyle(
                  fontSize: MediaQuery.of(context).size.width * 0.05,
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                  fontFamily: 'Horizon',
                ),
                textAlign: TextAlign.center,
              ),
              SizedBox(height: MediaQuery.of(context).size.height * 0.01),
              Text(
                "deliciousness of their food",
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: MediaQuery.of(context).size.width * 0.03,
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                  fontFamily: 'Orbitron-Bold',
                ),
              ),
              SizedBox(height: MediaQuery.of(context).size.height * 0.02),
              Image(
                image: AssetImage('images/foodlogo.png'),
                width: MediaQuery.of(context).size.width * 0.8,
                height: MediaQuery.of(context).size.width * 0.8,
              ),
              Spacer(),
              Container(
                alignment: Alignment.center,
                padding: EdgeInsets.only(bottom: MediaQuery.of(context).size.height * 0.02),
                child: Text(
                  'Developed by MiniBites',
                  style: TextStyle(
                    fontSize: MediaQuery.of(context).size.width * 0.04,
                    fontFamily: 'Horizon',
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
