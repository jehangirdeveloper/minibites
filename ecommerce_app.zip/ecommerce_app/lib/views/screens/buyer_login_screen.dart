import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:minibites/controllers/buyer_signup_usercontroller.dart';
import 'package:minibites/views/screens/buyer_password_reset_screen.dart';
import 'package:minibites/views/screens/buyer_sign_up_screen.dart';
import 'package:minibites/views/screens/buyer_dashboard/buyer_dashboard.dart';

class BuyerLoginScreen extends StatefulWidget {
  @override
  _BuyerLoginScreenState createState() => _BuyerLoginScreenState();
}

class _BuyerLoginScreenState extends State<BuyerLoginScreen> {
  final UserController userController = Get.put(UserController());
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  bool _obscurePassword = true;

  // Updated login method with better error handling
  Future<void> login(String email, String password) async {
    try {
      UserCredential userCredential = await FirebaseAuth.instance.signInWithEmailAndPassword(
        email: email,
        password: password,
      );

      User? user = userCredential.user;
      if (user == null) {
        Get.snackbar('Error', 'User not found');
        return;
      }

      try {
        // Secure Firestore access based on authenticated user's UID
        DocumentSnapshot userDoc = await _firestore.collection('buyers').doc(user.uid).get();
        if (userDoc.exists) {
          var buyerData = userDoc.data() as Map<String, dynamic>?;
          if (buyerData == null) {
            Get.snackbar('Error', 'Buyer data is incomplete');
            return;
          }

          String buyerId = user.uid;

          // Navigate to Buyer Dashboard
          Get.offAll(() => BuyerDashboard(), arguments: {'buyerId': buyerId, ...buyerData});
        } else {
          Get.snackbar('Error', 'Buyer not found in Firestore');
        }
      } catch (e) {
        Get.snackbar('Firestore Error', 'Failed to fetch buyer data: ${e.toString()}');
      }
    } on FirebaseAuthException catch (e) {
      if (e.code == 'user-not-found') {
        Get.snackbar('Login Error', 'No user found for that email.');
      } else if (e.code == 'wrong-password') {
        Get.snackbar('Login Error', 'Wrong password provided.');
      } else {
        Get.snackbar('Login Error', e.message ?? 'An unknown error occurred.');
      }
    } catch (e) {
      Get.snackbar('Error', 'Failed to login: ${e.toString()}');
    }
  }

  void _togglePasswordVisibility() {
    setState(() {
      _obscurePassword = !_obscurePassword;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Login'),
        backgroundColor: Colors.amber,
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: SingleChildScrollView(
            child: Form(
              key: _formKey,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  SizedBox(height: 15),
                  Text(
                    'Login',
                    style: TextStyle(
                      fontSize: 25.0,
                      fontFamily: 'Horizon',
                    ),
                    textAlign: TextAlign.center,
                  ),
                  SizedBox(height: 20),
                  TextFormField(
                    onChanged: (value) => userController.email.value = value,
                    decoration: InputDecoration(
                      labelText: 'Enter Your Email',
                      prefixIcon: Icon(Icons.email),
                    ),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please enter your email';
                      }
                      return null;
                    },
                  ),
                  TextFormField(
                    onChanged: (value) => userController.password.value = value,
                    obscureText: _obscurePassword,
                    decoration: InputDecoration(
                      labelText: 'Enter Your Password',
                      prefixIcon: Icon(Icons.lock),
                      suffixIcon: IconButton(
                        icon: Icon(
                          _obscurePassword ? Icons.visibility_off : Icons.visibility,
                        ),
                        onPressed: _togglePasswordVisibility,
                      ),
                    ),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please enter your password';
                      }
                      return null;
                    },
                  ),
                  TextButton(
                    onPressed: () {
                      Get.to(() => BuyerPasswordResetScreen());
                    },
                    child: Container(
                      alignment: Alignment.centerRight,
                      child: Text(
                        'Forgot Password?',
                        style: TextStyle(color: Colors.black, fontSize: 17),
                      ),
                    ),
                  ),
                  SizedBox(height: 20),
                  ElevatedButton(
                    onPressed: () {
                      if (_formKey.currentState?.validate() ?? false) {
                        login(userController.email.value, userController.password.value);
                      }
                    },
                    child: Text('Login'),
                    style: ElevatedButton.styleFrom(
                      padding: EdgeInsets.symmetric(vertical: 10, horizontal: 100),
                      foregroundColor: Colors.black,
                      backgroundColor: Colors.amber,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.all(Radius.circular(10)),
                      ),
                    ),
                  ),
                  TextButton(
                    onPressed: () {
                      Get.to(() => BuyerSignUpScreen());
                    },
                    child: Text(
                      'Don\'t have an account? Sign Up',
                      style: TextStyle(color: Colors.black, fontSize: 17),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
