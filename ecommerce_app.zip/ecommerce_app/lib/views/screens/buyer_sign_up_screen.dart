import 'package:minibites/controllers/buyer_signup_usercontroller.dart';
import 'package:minibites/views/screens/buyer_email_verification_screen.dart';
import 'package:minibites/views/screens/buyer_login_screen.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart'; // Import Firestore

class BuyerSignUpScreen extends StatelessWidget {
  final UserController userController = Get.put(UserController());
  // Firestore reference
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  // Form key for validation
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  BuyerSignUpScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('SignUp'),
        backgroundColor: Colors.amber,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                SizedBox(height: 60),
                Text(
                  'Ready to order the Food?',
                  style: TextStyle(
                    fontSize: 18.0,
                    fontFamily: 'Horizon',
                  ),
                  textAlign: TextAlign.center,
                ),
                SizedBox(height: 20),
                TextFormField(
                  onChanged: (value) => userController.fullName.value = value,
                  decoration: InputDecoration(
                    labelText: 'Enter Your Full Name',
                    prefixIcon: Icon(Icons.person),
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please enter your full name';
                    }
                    return null;
                  },
                ),
                TextFormField(
                  onChanged: (value) => userController.username.value = value,
                  decoration: InputDecoration(
                    labelText: 'Enter Your Username',
                    prefixIcon: Icon(Icons.person),
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please enter your username';
                    }
                    return null;
                  },
                ),
                TextFormField(
                  onChanged: (value) => userController.email.value = value,
                  decoration: InputDecoration(
                    labelText: 'Enter Your Email',
                    prefixIcon: Icon(Icons.email),
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please enter your email';
                    }
                    if (!RegExp(r'\S+@\S+\.\S+').hasMatch(value)) {
                      return 'Please enter a valid email';
                    }
                    return null;
                  },
                ),
                TextFormField(
                  onChanged: (value) => userController.password.value = value,
                  obscureText: true,
                  decoration: InputDecoration(
                    labelText: 'Enter Your Password',
                    prefixIcon: Icon(Icons.lock),
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please enter your password';
                    }
                    if (value.length < 6) {
                      return 'Password must be at least 6 characters long';
                    }
                    return null;
                  },
                ),
                DropdownButtonFormField<String>(
                  value: userController.selectedCountry.value,
                  onChanged: (String? newValue) {
                    userController.selectedCountry.value = newValue!;
                  },
                  items: <String>['Pakistan']
                      .map<DropdownMenuItem<String>>((String value) {
                    return DropdownMenuItem<String>(
                      value: value,
                      child: Text(value),
                    );
                  }).toList(),
                  decoration: InputDecoration(
                    labelText: 'Select Your Country',
                    prefixIcon: Icon(Icons.flag),
                  ),
                  validator: (value) {
                    if (value == null) {
                      return 'Please select your country';
                    }
                    return null;
                  },
                ),
                DropdownButtonFormField<String>(
                  value: 'Attock City', // Default selected value
                  onChanged: (String? newValue) {
                    userController.city.value = newValue!;
                  },
                  decoration: InputDecoration(
                    labelText: 'Select Your City',
                    prefixIcon: Icon(Icons.location_city),
                  ),
                  items: <String>['Attock City']
                      .map<DropdownMenuItem<String>>((String value) {
                    return DropdownMenuItem<String>(
                      value: value,
                      child: Text(value),
                    );
                  }).toList(),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please select your city';
                    }
                    return null;
                  },
                ),

                TextFormField(
                  onChanged: (value) => userController.phoneNumber.value = value,
                  decoration: InputDecoration(
                    labelText: 'Enter Your Phone Number',
                    prefixIcon: Icon(Icons.phone),
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please enter your phone number';
                    }
                    return null;
                  },
                ),
                SizedBox(height: 20),
                ElevatedButton(
                  onPressed: () async {
                    if (_formKey.currentState?.validate() ?? false) {
                      try {
                        // Sign up user with Firebase Authentication
                        UserCredential userCredential = await FirebaseAuth.instance.createUserWithEmailAndPassword(
                          email: userController.email.value,
                          password: userController.password.value,
                        );

                        // Save additional user info in Firestore
                        await _firestore.collection('buyers').doc(userCredential.user?.uid).set({
                          'buyerId': userCredential.user!.uid, // Storing buyerId instead of sellerId
                          'fullName': userController.fullName.value, // Full Name
                          'username': userController.username.value,
                          'email': userController.email.value,
                          'country': userController.selectedCountry.value,
                          'city': userController.city.value,
                          'phoneNumber': userController.phoneNumber.value,
                        });

                        Get.to(() => BuyerEmailVerificationScreen());
                      } catch (e) {
                        Get.snackbar('Error', e.toString(), backgroundColor: Colors.red, colorText: Colors.white);
                      }
                    }
                  },
                  child: Text('Signup'),
                  style: ElevatedButton.styleFrom(
                    padding: EdgeInsets.symmetric(vertical: 10, horizontal: 100),
                    foregroundColor: Colors.black,
                    backgroundColor: Colors.amber,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.all(Radius.circular(10)),
                    ),
                  ),
                ),
                TextButton(
                  onPressed: () {
                    Get.to(() => BuyerLoginScreen());
                  },
                  child: Text(
                    'Already have an account? Login',
                    style: TextStyle(color: Colors.black, fontSize: 17),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
