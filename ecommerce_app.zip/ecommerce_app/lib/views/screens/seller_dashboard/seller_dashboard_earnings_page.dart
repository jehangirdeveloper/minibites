import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:minibites/controllers/seller_dashboard_controller/seller_dashboard_earnings_page_controller.dart';

class SellerDashboardEarningsPage extends StatefulWidget {
  final String restaurantId;
  final String sellerId;

  SellerDashboardEarningsPage({
    required this.restaurantId,
    required this.sellerId,
  });

  @override
  _SellerDashboardEarningsPageState createState() => _SellerDashboardEarningsPageState();
}

class _SellerDashboardEarningsPageState extends State<SellerDashboardEarningsPage> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  late SellerDashboardEarningsPageController controller;
  DateTimeRange? selectedDateRange;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    controller = Get.put(SellerDashboardEarningsPageController());
    controller.fetchOrders();
  }

  @override
  void dispose() {
    _tabController.dispose();
    Get.delete<SellerDashboardEarningsPageController>();
    super.dispose();
  }

  Future<void> _selectDateRange(BuildContext context) async {
    final DateTimeRange? pickedDateRange = await showDateRangePicker(
      context: context,
      initialDateRange: selectedDateRange,
      firstDate: DateTime(2021),
      lastDate: DateTime.now(),
    );

    if (pickedDateRange != null && pickedDateRange != selectedDateRange) {
      setState(() {
        selectedDateRange = pickedDateRange;
        if (selectedDateRange != null) {
          controller.fetchOrdersByDateRange(selectedDateRange!.start, selectedDateRange!.end);
        }
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.amber,
        title: Text('Payments', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        actions: [
          IconButton(
            icon: Icon(Icons.calendar_today),
            onPressed: () => _selectDateRange(context),
          ),
        ],
        bottom: TabBar(
          controller: _tabController,
          tabs: [
            Tab(text: 'This Month'),
            Tab(text: 'Last Month'),
            Tab(text: 'All Time'),
          ],
        ),
      ),
      body: Column(
        children: [
          if (selectedDateRange != null)
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    'Start Date: ${DateFormat.yMd().format(selectedDateRange!.start)}',
                    style: TextStyle(fontSize: 16),
                  ),
                  SizedBox(width: 20),
                  Text(
                    'End Date: ${DateFormat.yMd().format(selectedDateRange!.end)}',
                    style: TextStyle(fontSize: 16),
                  ),
                ],
              ),
            ),
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: [
                buildEarningsList('This Month'),
                buildEarningsList('Last Month'),
                buildEarningsList('All Time'),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget buildEarningsList(String period) {
    return Obx(() {
      final orders = controller.orders
          .where((order) => _isOrderInPeriod(order, period) && order.status == 'Done')
          .toList();

      if (orders.isEmpty) {
        return Center(
          child: Text('No Payments for $period.', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w500)),
        );
      } else {
        return ListView.builder(
          itemCount: orders.length,
          itemBuilder: (context, index) {
            final order = orders[index];
            final subtotal = order.subtotal * 0.85;

            return Card(
              elevation: 5,
              margin: EdgeInsets.symmetric(vertical: 10, horizontal: 15),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
              ),
              color: Colors.green[100],
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('Order Number:', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                        Container(
                          height: 20,
                          width: 1,
                          color: Colors.black,
                          margin: EdgeInsets.symmetric(horizontal: 45),
                        ),
                        Text('${order.orderNumber}', style: TextStyle(fontSize: 16)),
                      ],
                    ),
                    SizedBox(height: 8),
                    Divider(color: Colors.black, // Yahan par color set karein
                        thickness: 1, // Aap thickness bhi set kar sakte hain//
                         ), // Horizontal Divider
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('Restaurant:', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
                        Container(
                          height: 20,
                          width: 1,
                          color: Colors.black,
                          margin: EdgeInsets.symmetric(horizontal: 45),
                        ),
                        Text('${order.restaurantName}', style: TextStyle(fontSize: 16)),
                      ],
                    ),
                    SizedBox(height: 8),
                    Divider(color: Colors.black, // Yahan par color set karein
                      thickness: 1, // Aap thickness bhi set kar sakte hain//
                    ), // Horizontal Divider
                    // Menu Items
                    ...List.generate(order.items.length, (itemIndex) {
                      return Padding(
                        padding: const EdgeInsets.symmetric(vertical: 4),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text('Menu:', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                            Container(
                              height: 20,
                              width: 1,
                              color: Colors.black,
                              margin: EdgeInsets.symmetric(horizontal: 45),
                            ),
                            Expanded( // Use Expanded to ensure the Text widget takes available space
                              child: Text(
                                '${order.items[itemIndex]} Quantity: ${order.quantities[itemIndex]}',
                                style: TextStyle(fontSize: 13,),
                                maxLines: 6, // Maximum 6 lines dikhayega
                                overflow: TextOverflow.ellipsis, // Overflow ko handle karega
                              ),
                            ),
                          ],
                        ),
                      );
                    }),

                    SizedBox(height: 8),
                    Divider(color: Colors.black, // Yahan par color set karein
                      thickness: 1, // Aap thickness bhi set kar sakte hain//
                    ),  // Horizontal Divider
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('Date:', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                        Container(
                          height: 20,
                          width: 1,
                          color: Colors.black,
                          margin: EdgeInsets.symmetric(horizontal: 45),
                        ),
                        Text('${order.formattedDate}', style: TextStyle(fontSize: 16)),
                      ],
                    ),
                    SizedBox(height: 8),
                    Divider(color: Colors.black, // Yahan par color set karein
                      thickness: 1, // Aap thickness bhi set kar sakte hain//
                    ), // Horizontal Divider
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('Total Payment:', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                        Container(
                          height: 20,
                          width: 1,
                          color: Colors.black,
                          margin: EdgeInsets.symmetric(horizontal: 45),
                        ),
                        Text('Rs ${subtotal.toStringAsFixed(2)}', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                      ],
                    ),
                    SizedBox(height: 8),
                    Divider(color: Colors.black, // Yahan par color set karein
                      thickness: 1, // Aap thickness bhi set kar sakte hain//
                    ), // Horizontal Divider
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('Payment Status:', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                        DropdownButton<String>(
                          value: order.paymentStatus,
                          onChanged: (String? newValue) {
                            if (newValue != null) {
                              controller.updatePaymentStatus(order.orderId, newValue);
                            }
                          },
                          items: ['Unpaid', 'Paid'].map((status) {
                            return DropdownMenuItem<String>(
                              value: status,
                              child: Text(status),
                            );
                          }).toList(),
                        ),
                      ],
                    ),
                    SizedBox(height: 8),
                    Divider(color: Colors.black, // Yahan par color set karein
                      thickness: 1, // Aap thickness bhi set kar sakte hain//
                    ),  // Horizontal Divider
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('Payment Method:', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                        DropdownButton<String>(
                          value: order.paymentMethod, // Ensure this is part of your Order model
                          onChanged: (String? newMethod) {
                            if (newMethod != null) {
                              controller.updatePaymentMethod(order.orderId, newMethod);
                            }
                          },
                          items: ['Bank Transfer', 'EasyPaisa', 'JazzCash', 'Cash On Delivery'].map((method) {
                            return DropdownMenuItem<String>(
                              value: method,
                              child: Text(method),
                            );
                          }).toList(),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            );
          },
        );
      }
    });
  }

  bool _isOrderInPeriod(Order order, String period) {
    final now = DateTime.now();
    final orderDate = order.timestamp.toDate();
    switch (period) {
      case 'This Month':
        return orderDate.year == now.year && orderDate.month == now.month;
      case 'Last Month':
        final lastMonth = now.subtract(Duration(days: now.day));
        return orderDate.year == lastMonth.year && orderDate.month == lastMonth.month;
      case 'All Time':
        return true;
      default:
        return false;
    }
  }
}
