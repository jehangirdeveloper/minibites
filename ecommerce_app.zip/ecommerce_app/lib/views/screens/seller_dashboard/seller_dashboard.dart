import 'package:firebase_auth/firebase_auth.dart';
import 'package:minibites/controllers/seller_dashboard_controller/seller_dashboard_controller.dart';
import 'package:minibites/controllers/seller_dashboard_controller/seller_dashboard_products_controller.dart';
import 'package:minibites/models/seller_dashboard_pages/seller_dashboard_products_model.dart';
import 'package:minibites/views/screens/buyer_dashboard/Crafted%20Cuisine_all_type_foods_pages/pizza_page.dart';
import 'package:minibites/views/screens/buyer_dashboard/review_page.dart';
import 'package:minibites/views/screens/on_boarding_page/on_boarding_screen.dart';
import 'package:minibites/views/screens/seller_dashboard/live_support.dart';
import 'package:minibites/views/screens/seller_dashboard/seller_dashboard_add_your_menu_page.dart';
import 'package:minibites/views/screens/seller_dashboard/seller_dashboard_change_language_page.dart';
import 'package:minibites/views/screens/seller_dashboard/seller_dashboard_help_center.dart';
import 'package:minibites/views/screens/seller_dashboard/seller_dashboard_earnings_page.dart';
import 'package:minibites/views/screens/seller_dashboard/seller_dashboard_mytransactions_page.dart';
import 'package:minibites/views/screens/seller_dashboard/seller_dashboard_order_page.dart';
import 'package:minibites/views/screens/seller_dashboard/seller_dashboard_privacy_policy_page.dart';
import 'package:minibites/views/screens/seller_dashboard/seller_dashboard_products_page.dart';
import 'package:minibites/views/screens/seller_dashboard/seller_dashboard_ratings_page.dart';
import 'package:minibites/views/screens/seller_dashboard/seller_dashboard_tags_page.dart';
import 'package:minibites/views/screens/seller_dashboard/seller_dashboard_termsconditions_page.dart';
import 'package:minibites/views/screens/seller_login_screen.dart';
import 'package:minibites/views/screens/seller_multi_step_form_screen.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:firebase_messaging/firebase_messaging.dart';

class SellerDashboard extends StatefulWidget {
  @override
  _SellerDashboardState createState() => _SellerDashboardState();
}

class _SellerDashboardState extends State<SellerDashboard> {

  @override
  Widget build(BuildContext context) {
    final SellerDashboardController controller = Get.put(SellerDashboardController());
    final String sellerId = FirebaseAuth.instance.currentUser?.uid ?? '';
    final String _selectedRestaurantId = controller.selectedRestaurantId;

    return Scaffold(
      backgroundColor: Colors.grey[850],
      appBar: AppBar(
        backgroundColor: Colors.grey[800],
        title: Row(
          children: [
            Icon(
              Icons.add_business_rounded, // Replace with your preferred icon
              color: Colors.white,
            ),
            SizedBox(width: 8), // Space between icon and text
            Text(
              'MiniBites Partner App',
              style: TextStyle(
                color: Colors.white,
                fontSize: 19,
              ),
            ),
          ],
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
            children: [
        Padding(
        padding: const EdgeInsets.all(8.0),
        child: GestureDetector(
          onTap: () {
            // Add navigation if needed
          },
          child: Container(
            width: double.infinity,
            height: 150,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(8),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.2),
                  blurRadius: 4.0,
                  spreadRadius: 1.0,
                ),
              ],
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: Image.asset(
                'images/sadas.png',
                fit: BoxFit.cover,
              ),
            ),
          ),
        ),
      ),
       SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            children: [
              GridView.count(
                crossAxisCount: 2,
                shrinkWrap: true,
                physics: NeverScrollableScrollPhysics(),
                children: [
                  buildCard('Orders', '', Icons.shopping_cart, () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => SellerDashboardOrderPage(
                          restaurantId: _selectedRestaurantId,
                          sellerId: sellerId,
                        ),
                      ),
                    );
                  }, backgroundColor: Colors.grey.shade800, textColor: Colors.white),
                  buildCard('Payments', '', Icons.account_balance_wallet, () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => SellerDashboardEarningsPage(
                          restaurantId: _selectedRestaurantId,
                          sellerId: sellerId,
                        ),
                      ),
                    );
                  }, backgroundColor: Colors.grey.shade800, textColor: Colors.white),

                  buildCard('Ratings', '', Icons.star, () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => SellerDashboardRatingsPage(sellerId: sellerId),
                      ),
                    );

                  }, backgroundColor: Colors.grey.shade800, textColor: Colors.white),

                  buildCard('Restaurant', '', Icons.add_circle, () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => SellerDashboardAddYourMenuPage(),
                      ),
                    );
                  }, backgroundColor: Colors.grey.shade800, textColor: Colors.white),
                  buildCard('Live Support', '', Icons.support_agent, () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => LiveSupport(),
                      ),
                    );
                  }, backgroundColor: Colors.grey.shade800, textColor: Colors.white),
                  buildCard('Logout', '', Icons.exit_to_app, () async {
                    try {
                      await FirebaseAuth.instance.signOut();
                      Get.to(OnboardingScreen());
                    } catch (e) {
                      print('Sign out error: $e');
                    }
                  }, backgroundColor: Colors.grey.shade800, textColor: Colors.white),

                ],
              ),
            ],
          ),
        ),
      ),
    ]),
      ));
  }

  Widget buildCard(String title, String count, IconData icon, VoidCallback onTap, {Color backgroundColor = Colors.white, Color textColor = Colors.black}) {
    return GestureDetector(
      onTap: onTap,
      child: Card(
        color: backgroundColor,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 50, color: textColor),
            SizedBox(height: 10),
            Text(title, style: TextStyle(fontSize: 18, color: textColor)),
            SizedBox(height: 5),
            Text(count, style: TextStyle(fontSize: 16, color: textColor)),
          ],
        ),
      ),
    );
  }
}
