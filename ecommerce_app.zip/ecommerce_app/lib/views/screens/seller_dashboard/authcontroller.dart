// import 'package:get/get.dart';
//
// class AuthController extends GetxController {
//   // Observable to store the current user ID
//   var currentUserId = ''.obs;
//
//   // Method to set the current user ID
//   void setUserId(String userId) {
//     currentUserId.value = userId;
//   }
//
//   // Method to get the current user ID
//   String getUserId() {
//     return currentUserId.value;
//   }
// }
