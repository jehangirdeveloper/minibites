import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:minibites/controllers/seller_dashboard_controller/seller_dashboard_change_language_page_controller.dart';

class SellerDashboardChangeLanguagePage extends StatelessWidget {
  final SellerDashboardChangeLanguagePageController languageController = Get.put(SellerDashboardChangeLanguagePageController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.amber,
      appBar: AppBar(
        title: Text('Change Language'.tr),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              onPressed: () {
                languageController.changeLanguage('en');
              },
              style: ElevatedButton.styleFrom(
                foregroundColor: Colors.white,
                backgroundColor: Colors.blue, // Button background color
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8), // Rounded corners
                ),
                minimumSize: Size(200, 40), // Width and height
                padding: EdgeInsets.symmetric(horizontal: 7),
              ),
              child: Text('English'.tr),
            ),
            ElevatedButton(
              onPressed: () {
                languageController.changeLanguage('ur');
              },
              style: ElevatedButton.styleFrom(
                foregroundColor: Colors.white,
                backgroundColor: Colors.blue, // Button background color
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8), // Rounded corners
                ),
                minimumSize: Size(200, 40), // Width and height
                padding: EdgeInsets.symmetric(horizontal: 7),
              ),
              child: Text('Urdu'.tr),
            ),
          ],
        ),
      ),
    );
  }
}
