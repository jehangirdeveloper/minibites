import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';  // Import the rating bar package
import 'package:intl/intl.dart';  // Import to format DateTime to only date
import 'package:minibites/controllers/seller_dashboard_controller/seller_dashboard_ratings_page_controller.dart';

class SellerDashboardRatingsPage extends StatelessWidget {
  final String sellerId;

  SellerDashboardRatingsPage({required this.sellerId});

  @override
  Widget build(BuildContext context) {
    final controller = Get.put(SellerDashboardRatingsController(sellerId: sellerId));

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.amber,
        title: Text('Reviews'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0), // Add padding around the body
        child: Obx(() {
          if (controller.reviews.isEmpty) {
            return Center(
              child: Text(
                'No Reviews Available for this Restaurant',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.grey),
                textAlign: TextAlign.center,
              ),
            );
          } else {
            return ListView.builder(
              itemCount: controller.reviews.length,
              itemBuilder: (context, index) {
                final review = controller.reviews[index];
                final formattedDate = DateFormat('yyyy-MM-dd').format(review.createdAt);

                return Card(
                  margin: const EdgeInsets.only(bottom: 16), // Add margin between cards
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(15),
                  ),
                  elevation: 4,
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Expanded(
                              child: Text(
                                review.review,
                                style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.w600,
                                  color: Colors.black87,
                                ),
                              ),
                            ),
                            SizedBox(width: 8.0), // Space between review text and stars
                            // Stars (Rating Bar)
                            RatingBarIndicator(
                              rating: review.rating.toDouble(),
                              itemBuilder: (context, index) => Icon(
                                Icons.star,
                                color: Colors.amber,
                              ),
                              itemCount: 5,
                              itemSize: 20.0,
                              direction: Axis.horizontal,
                            ),
                          ],
                        ),
                        SizedBox(height: 8.0),
                        Divider(color: Colors.grey[300]), // Divider line
                        SizedBox(height: 8.0),
                        Text(
                          'Date: $formattedDate',
                          style: TextStyle(
                            fontSize: 14,
                            color: Colors.grey[600],
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            );
          }
        }),
      ),
    );
  }
}
