import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:minibites/controllers/seller_dashboard_controller/RestaurantController.dart';
import 'dart:io';
import 'package:minibites/models/seller_dashboard_pages/restaurant_model.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class SellerDashboardAddYourMenuPage extends StatefulWidget {
  @override
  _SellerDashboardAddYourMenuPageState createState() => _SellerDashboardAddYourMenuPageState();
}

class _SellerDashboardAddYourMenuPageState extends State<SellerDashboardAddYourMenuPage> {
  final RestaurantController restaurantController = Get.put(
      RestaurantController());

  final TextEditingController _restaurantNameController = TextEditingController();
  final TextEditingController _openingTimeController = TextEditingController();
  final TextEditingController _closingTimeController = TextEditingController();
  String? _selectedCountry; // Add this to handle country selection
  String? _selectedCity; // Add this to handle city selection
  File? _selectedImage;

  List<Map<String, dynamic>> menuForms = [];

  @override
  void initState() {
    super.initState();
    _restaurantNameController.text = restaurantController.restaurantName.value;
    restaurantController.restaurantName.listen((value) {
      _restaurantNameController.text = value;
    });
  }

  Future<void> _pickImage({required bool isMenuImage, int? index}) async {
    final pickedFile = await ImagePicker().pickImage(
        source: ImageSource.gallery);
    if (pickedFile != null) {
      setState(() {
        if (isMenuImage && index != null) {
          menuForms[index]['image'] = File(pickedFile.path);
        } else {
          _selectedImage = File(pickedFile.path);
        }
      });

      if (isMenuImage && index != null) {
        restaurantController.setMenuImage(menuForms[index]['image']);
      } else {
        restaurantController.setImage(_selectedImage!);
      }
    }
  }

  void _addMenuForm() {
    setState(() {
      menuForms.add({
        'menuNameController': TextEditingController(),
        'priceController': TextEditingController(),
        'image': null,
      });
    });
  }

  Future<String> getSellerId() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) throw Exception("User not authenticated");

    final sellerSnapshot = await FirebaseFirestore.instance
        .collection('sellers')
        .doc(user.uid)
        .get();

    if (!sellerSnapshot.exists) {
      throw Exception("Seller not found");
    }

    return sellerSnapshot.id;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Add Restaurant & Menu'),
        backgroundColor: Colors.amber,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text('Restaurant Name', style: Theme
                  .of(context)
                  .textTheme
                  .bodyMedium),
              SizedBox(height: 8),
              TextField(
                decoration: InputDecoration(border: OutlineInputBorder(),
                    hintText: 'Enter Restaurant Name'),
                controller: _restaurantNameController,
                onChanged: (value) =>
                    restaurantController.setRestaurantName(value),
              ),
              SizedBox(height: 20),
              Text('Opening Time', style: Theme
                  .of(context)
                  .textTheme
                  .bodyMedium),
              SizedBox(height: 8),
              TextField(
                decoration: InputDecoration(border: OutlineInputBorder(),
                    hintText: 'Enter Opening Time (e.g., 9:00 AM)'),
                controller: _openingTimeController,
              ),
              SizedBox(height: 20),
              Text('Closing Time', style: Theme
                  .of(context)
                  .textTheme
                  .bodyMedium),
              SizedBox(height: 8),
              TextField(
                decoration: InputDecoration(border: OutlineInputBorder(),
                    hintText: 'Enter Closing Time (e.g., 11:00 PM)'),
                controller: _closingTimeController,
              ),
              SizedBox(height: 20),
              // Country Dropdown
              Text('Country', style: Theme
                  .of(context)
                  .textTheme
                  .bodyMedium),
              SizedBox(height: 8),
              DropdownButton<String>(
                value: _selectedCountry,
                hint: Text('Select Country'),
                items: <String>['Pakistan'].map<DropdownMenuItem<String>>((
                    String value) {
                  return DropdownMenuItem<String>(
                    value: value,
                    child: Text(value),
                  );
                }).toList(),
                onChanged: (String? newValue) {
                  setState(() {
                    _selectedCountry = newValue;
                    _selectedCity = null; // Reset city when country changes
                  });
                },
              ),
              SizedBox(height: 20),

              // City Dropdown
              Text('City', style: Theme
                  .of(context)
                  .textTheme
                  .bodyMedium),
              SizedBox(height: 8),
              DropdownButton<String>(
                value: _selectedCity,
                hint: Text('Select City'),
                items: _getCityListForCountry(_selectedCountry).map<
                    DropdownMenuItem<String>>((String value) {
                  return DropdownMenuItem<String>(
                    value: value,
                    child: Text(value),
                  );
                }).toList(),
                onChanged: (String? newValue) {
                  setState(() {
                    _selectedCity = newValue;
                  });
                },
              ),
              SizedBox(height: 20),
              Obx(() {
                return DropdownButtonFormField<String>(
                  value: restaurantController.category.value.isNotEmpty
                      ? restaurantController.category.value
                      : null,
                  decoration: InputDecoration(border: OutlineInputBorder(),
                      hintText: 'Select Category'),
                  items: <String>[
                    'Pizza', 'Pasta', 'Haleem', 'Pulao', 'Biryani', 'Paratha Roll',
                    'BBQ', 'Burgers', 'Shawarma', 'Pak Food', 'Ice Cream',
                    'Chinese', 'Samosa', 'Desserts', 'Fish', 'Sweet Dish'
                  ].map((String value) {
                    return DropdownMenuItem<String>(
                      value: value,
                      child: Text(value),
                    );
                  }).toList(),
                  onChanged: (String? newValue) {
                    if (newValue != null) {
                      restaurantController.setCategory(newValue);
                    }
                  },
                );
              }),
              SizedBox(height: 20),
              GestureDetector(
                onTap: () => _pickImage(isMenuImage: false),
                child: _selectedImage != null
                    ? ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: Image.file(
                    _selectedImage!,
                    height: 150,
                    width: 150,
                    fit: BoxFit.cover,
                  ),
                )
                    : Container(
                  height: 150,
                  width: 150,
                  decoration: BoxDecoration(
                    color: Colors.grey[300],
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: Colors.grey),
                  ),
                  child: Icon(
                      Icons.add_a_photo, color: Colors.grey[600], size: 50),
                ),
              ),
              SizedBox(height: 20),
              ...menuForms
                  .asMap()
                  .entries
                  .map((entry) {
                int index = entry.key;
                var form = entry.value;
                return Card(
                  margin: EdgeInsets.only(bottom: 20),
                  elevation: 4,
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Menu Item ${index + 1}', style: Theme
                            .of(context)
                            .textTheme
                            .bodyMedium),
                        SizedBox(height: 8),
                        TextField(
                          decoration: InputDecoration(
                              border: OutlineInputBorder(),
                              hintText: 'Enter Menu Name'),
                          controller: form['menuNameController'],
                        ),
                        SizedBox(height: 16),
                        TextField(
                          decoration: InputDecoration(
                              border: OutlineInputBorder(),
                              hintText: 'Enter Price'),
                          controller: form['priceController'],
                          keyboardType: TextInputType.number,
                        ),
                        SizedBox(height: 16),
                        GestureDetector(
                          onTap: () =>
                              _pickImage(isMenuImage: true, index: index),
                          child: form['image'] != null
                              ? ClipRRect(
                            borderRadius: BorderRadius.circular(8),
                            child: Image.file(
                              form['image'],
                              height: 150,
                              width: 150,
                              fit: BoxFit.cover,
                            ),
                          )
                              : Container(
                            height: 150,
                            width: 150,
                            decoration: BoxDecoration(
                              color: Colors.grey[300],
                              borderRadius: BorderRadius.circular(8),
                              border: Border.all(color: Colors.grey),
                            ),
                            child: Icon(
                                Icons.add_a_photo, color: Colors.grey[600],
                                size: 50),
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              }).toList(),
              Center(
                child: ElevatedButton(
                  onPressed: _addMenuForm,
                  style: ElevatedButton.styleFrom(
                    foregroundColor: Colors.black,
                    backgroundColor: Colors.amber,
                    padding: EdgeInsets.symmetric(horizontal: 32, vertical: 12),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8)),
                  ),
                  child: Text('Add Menu Item'),
                ),
              ),
              SizedBox(height: 20),
              Center(
                child: ElevatedButton(
                  onPressed: () async {
                    try {
                      if (_selectedImage != null) {
                        await restaurantController.uploadImageAndGetUrl();
                        String sellerId = await getSellerId();

                        await restaurantController.addRestaurant(
                          sellerId,
                          restaurantController.restaurantName.value,
                          restaurantController.category.value,
                          restaurantController.imageUrl.value,
                          _openingTimeController.text,
                          // Add Opening Time
                          _closingTimeController.text,
                          // Add Closing Time
                          _selectedCountry!,
                          _selectedCity!,
                        );

                        for (var form in menuForms) {
                          if (form['image'] != null) {
                            await restaurantController
                                .uploadMenuImageAndGetUrl();
                            await restaurantController.submitMenuForm(
                              form['menuNameController'].text,
                              double.tryParse(form['priceController'].text) ??
                                  0.0,
                              form['image'],
                            );
                          }
                        }

                        setState(() {
                          restaurantController.restaurantName.value = '';
                          restaurantController.category.value = '';
                          restaurantController.imageUrl.value = '';
                          restaurantController.imageFile = null;
                          menuForms.clear();
                          _selectedImage = null;
                          _restaurantNameController.clear();
                          _openingTimeController.clear(); // Clear Opening Time
                          _closingTimeController.clear(); // Clear Closing Time
                        });

                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(content: Text(
                              'Restaurant and Menu Added Successfully')),
                        );

                        Future.delayed(Duration(seconds: 1), () {
                          setState(() {}); // Refresh the page
                        });
                      } else {
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(content: Text(
                              'Please upload a restaurant image')),
                        );
                      }
                    } catch (e) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text('Failed to add restaurant: $e')),
                      );
                    }
                  },
                  style: ElevatedButton.styleFrom(
                    foregroundColor: Colors.black,
                    backgroundColor: Colors.amber,
                    padding: EdgeInsets.symmetric(horizontal: 32, vertical: 12),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8)),
                  ),
                  child: Text('Submit Restaurant & Menu'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // Function to return a list of cities based on the selected country
  List<String> _getCityListForCountry(String? country) {
    switch (country) {
      case 'Pakistan':
        return ['Attock City',];
      default:
        return [];
    }
  }
}
