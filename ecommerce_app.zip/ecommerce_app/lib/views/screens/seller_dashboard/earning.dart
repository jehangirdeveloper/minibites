import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';

class Earning {
  final String id;
  final String orderId;
  final String restaurantName;
  final List<String> menuItems;
  final String restaurantId;
  final Timestamp dateTime;
  final double totalPayment;
  final String paymentStatus;
  final Timestamp timestamp;

  Earning({
    required this.id,
    required this.orderId,
    required this.restaurantName,
    required this.menuItems,
    required this.restaurantId,
    required this.dateTime,
    required this.totalPayment,
    required this.paymentStatus,
    required this.timestamp,
  });

  String get formattedDate {
    DateTime dateTime = timestamp.toDate();
    return DateFormat('dd-MM-yyyy hh:mm a').format(dateTime);
  }

  factory Earning.fromDocument(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;

    return Earning(
      id: doc.id,
      orderId: data['orderId'] ?? '',
      restaurantName: data['restaurantName'] ?? '',
      menuItems: List<String>.from(data['menuItems'] ?? []),
      restaurantId: data['restaurantId'] ?? '',
      dateTime: data['dateTime'] ?? Timestamp.now(),
      totalPayment: (data['totalPayment'] ?? 0).toDouble(),
      paymentStatus: data['paymentStatus'] ?? 'Pending',
      timestamp: data['timestamp'] ?? Timestamp.now(),
    );
  }
}
