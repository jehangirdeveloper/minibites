import 'package:flutter/material.dart';
import 'package:flutter_tawk/flutter_tawk.dart';

class LiveSupport extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Live Support'),
      ),
      body: Tawk(
        directChatLink: 'https://tawk.to/chat/66dded4050c10f7a00a5e17b/1i79edhgd', // Replace with your Tawk.to chat link
        visitor: TawkVisitor(
          name: 'MiniBites',
          email: 'deliveryboys@minibites.app',
        ),
        onLoad: () {
          print('Tawk chat loaded');
        },
        onLinkTap: (String url) {
          print('Link tapped: $url');
        },
        placeholder: Center(
          child: Text('Loading chat...'),
        ),
      ),
    );
  }
}
