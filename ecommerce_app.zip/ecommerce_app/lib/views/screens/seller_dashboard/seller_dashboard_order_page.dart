import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:minibites/controllers/seller_dashboard_controller/seller_dashboard_order_page_controller.dart';
import 'package:intl/intl.dart';

class SellerDashboardOrderPage extends StatefulWidget {
  final String restaurantId;
  final String sellerId;

  SellerDashboardOrderPage({
    required this.restaurantId,
    required this.sellerId,
  });

  @override
  _SellerDashboardOrderPageState createState() => _SellerDashboardOrderPageState();
}

class _SellerDashboardOrderPageState extends State<SellerDashboardOrderPage> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  late SellerDashboardOrderPageController controller;
  DateTimeRange? _selectedDateRange;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    controller = Get.put(SellerDashboardOrderPageController());
    controller.fetchOrders();
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  Future<void> _selectDateRange(BuildContext context) async {
    final DateTimeRange? pickedRange = await showDateRangePicker(
      context: context,
      firstDate: DateTime(2000),
      lastDate: DateTime(2101),
      initialDateRange: _selectedDateRange,
      builder: (BuildContext context, Widget? child) {
        return Theme(
          data: ThemeData.light().copyWith(
            primaryColor: Colors.blue,
            primaryColorDark: Colors.blue[700],
            dialogBackgroundColor: Colors.white,
            textTheme: TextTheme(
              titleMedium: TextStyle(color: Colors.blue, fontWeight: FontWeight.bold),
              bodyMedium: TextStyle(color: Colors.black87),
            ),
            buttonTheme: ButtonThemeData(
              buttonColor: Colors.blue,
              textTheme: ButtonTextTheme.primary,
            ),
            dividerColor: Colors.blueGrey[200],
          ),
          child: child!,
        );
      },
    );
    if (pickedRange != null && pickedRange != _selectedDateRange) {
      setState(() {
        _selectedDateRange = pickedRange;
        controller.fetchOrders(startDate: pickedRange.start, endDate: pickedRange.end);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.amber,
        title: Text('My Orders', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        actions: [
          IconButton(
            icon: Icon(Icons.calendar_today),
            onPressed: () => _selectDateRange(context),
          ),
        ],
        bottom: TabBar(
          controller: _tabController,
          tabs: [
            Tab(text: 'Pending'),
            Tab(text: 'Done'),
            Tab(text: 'Cancel'),
          ],
        ),
      ),
      body: Column(
        children: [
          if (_selectedDateRange != null)
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    'Start Date: ${DateFormat.yMd().format(_selectedDateRange!.start)}',
                    style: TextStyle(fontSize: 16),
                  ),
                  SizedBox(width: 20),
                  Text(
                    'End Date: ${DateFormat.yMd().format(_selectedDateRange!.end)}',
                    style: TextStyle(fontSize: 16),
                  ),
                ],
              ),
            ),
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: [
                buildOrderList('Pending'),
                buildOrderList('Done'),
                buildOrderList('Cancel'),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget buildOrderList(String status) {
    return Obx(() {
      final orders = controller.orders.where((order) {
        final isStatusMatch = order.status == status;
        final isDateInRange = _selectedDateRange == null ||
            (order.timestamp.isAfter(_selectedDateRange!.start) &&
                order.timestamp.isBefore(_selectedDateRange!.end.add(Duration(days: 1))));
        return isStatusMatch && isDateInRange;
      }).toList();

      if (orders.isEmpty) {
        return Center(child: Text('No $status orders.', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w500)));
      } else {
        return SingleChildScrollView(
          child: ListView.builder(
            physics: NeverScrollableScrollPhysics(),
            shrinkWrap: true,
            itemCount: orders.length,
            itemBuilder: (context, index) {
              final order = orders[index];
              final subtotal = getSubTotalPrice(order.items, order.quantities, order.prices);
              final totalPayment = subtotal * 0.85;

              return Card(
                elevation: 5,
                margin: EdgeInsets.symmetric(vertical: 10, horizontal: 15),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
                color: _getStatusColor(status),
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _buildOrderInfoRow('Order Number:', order.orderNumber),
                      _buildOrderInfoRow('Restaurant:', order.restaurantName),
                      _buildMenuSection(order.items, order.quantities),
                      _buildOrderInfoRow('Date:', order.formattedDate),
                      _buildOrderInfoRow('Total Payment:', 'Rs ${totalPayment.toStringAsFixed(2)}'),
                      SizedBox(height: 12),
                      _buildDropdownRow('Order Status:', order.status, ['Pending', 'Done', 'Cancel'], (newValue) {
                        if (newValue != null) {
                          controller.updateOrderStatus(order.id, newValue);
                        }
                      }),
                    ],
                  ),
                ),
              );
            },
          ),
        );
      }
    });
  }

  Widget _buildMenuSection(List<String> items, List<int> quantities) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Loop through the items and quantities to create the UI
        ...List.generate(items.length, (itemIndex) {
          return Padding(
            padding: const EdgeInsets.symmetric(vertical: 4),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'Menu:',
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                    ),
                    Container(
                      height: 20,
                      width: 1,
                      color: Colors.black,
                      margin: EdgeInsets.symmetric(horizontal: 45),
                    ),
                    // Updated Text widget with maxLines and overflow properties
                    Expanded(
                      child: Text(
                        '${items[itemIndex]} Quantity: ${quantities[itemIndex]}',
                        style: TextStyle(fontSize: 13),
                        maxLines: 6, // Maximum 2 lines dikhayega
                        overflow: TextOverflow.ellipsis, // Agar zyada lamba ho to '...' dikhayega
                      ),
                    ),
                  ],
                ),
                // Add a divider after each item except the last one
                if (itemIndex < items.length - 1)
                  Divider(height: 20, color: Colors.black),
              ],
            ),
          );
        }),
        // Optional: Add a divider at the end of the menu section if needed
        Divider(height: 20, color: Colors.black),
      ],
    );
  }

  double getSubTotalPrice(List<String> items, List<int> quantities, List<double> prices) {
    double subtotal = 0.0;
    for (int i = 0; i < items.length; i++) {
      subtotal += prices[i] * quantities[i];
    }
    return subtotal;
  }

  Color _getStatusColor(String status) {
    switch (status) {
      case 'Pending':
        return Colors.orange[100]!;
      case 'Done':
        return Colors.green[100]!;
      case 'Cancel':
        return Colors.red[100]!;
      default:
        return Colors.white;
    }
  }

  Widget _buildOrderInfoRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                flex: 2,
                child: Text(
                  label,
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
              ),
              Container(
                height: 20,
                width: 1,
                color: Colors.black,
                margin: EdgeInsets.symmetric(horizontal: 10),
              ),
              Expanded(
                flex: 3,
                child: Text(value),
              ),
            ],
          ),
          SizedBox(height: 5),
          Divider(
            color: Colors.black,
            thickness: 1,
            height: 20,
          ),
        ],
      ),
    );
  }

  Widget _buildItemList(List<String> items, List<int> quantities) {
    return Column(
      children: List.generate(items.length, (index) {
        return Padding(
          padding: const EdgeInsets.symmetric(vertical: 4),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Text(
                  'Menu: ${items[index]}',
                  style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
                ),
              ),
              SizedBox(width: 16), // Yahan par gap ko barhaya gaya hai
              Text('Quantity: ${quantities[index]}', style: TextStyle(fontSize: 16)),
            ],
          ),
        );
      }),
    );
  }


  Widget _buildDropdownRow(String label, String value, List<String> options, ValueChanged<String?> onChanged) {
    String selectedValue = options.contains(value) ? value : options.isNotEmpty ? options[0] : '';

    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label, style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
        Container(
          height: 20,
          width: 1,
          color: Colors.black,
          margin: EdgeInsets.symmetric(horizontal: 10),
        ),
        DropdownButton<String>(
          value: selectedValue,
          items: options.map((String option) {
            return DropdownMenuItem<String>(
              value: option,
              child: Text(option, style: TextStyle(fontSize: 16)),
            );
          }).toList(),
          onChanged: onChanged,
        ),
      ],
    );
  }
}
