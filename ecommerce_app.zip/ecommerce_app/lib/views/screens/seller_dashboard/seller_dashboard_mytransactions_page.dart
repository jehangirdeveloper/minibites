import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:minibites/controllers/seller_dashboard_controller/seller_dashboard_mytransactions_page_controller.dart';

class SellerDashboardMytransactionsPage extends StatelessWidget {
  final SellerDashboardMytransactionsPageController controller = Get.put(SellerDashboardMytransactionsPageController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('My Transactions'),
      ),
      body: Obx(() {
        if (controller.transactions.isEmpty) {
          return const Center(child: CircularProgressIndicator());
        } else {
          return ListView.builder(
            itemCount: controller.transactions.length,
            itemBuilder: (context, index) {
              final transaction = controller.transactions[index];
              return Card(
                margin: const EdgeInsets.all(8.0),
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            'Amount : ${transaction.amount}',
                            style: const TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 16.0,
                            ),
                          ),
                          Text(
                            transaction.date,
                            style: const TextStyle(
                              color: Colors.grey,
                              fontSize: 12.0,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 8.0),
                      Text('Order ID : ${transaction.orderId}'),
                      Text('Payment Method : ${transaction.paymentMethod}'),
                      Text('Message : ${transaction.message}'),
                    ],
                  ),
                ),
              );
            },
          );
        }
      }),
    );
  }
}
