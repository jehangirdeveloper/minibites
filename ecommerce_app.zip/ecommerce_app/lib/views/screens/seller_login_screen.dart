import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
// Firebase Messaging import ko hata diya
import 'package:minibites/controllers/seller_signup_usercontroller.dart';
import 'package:minibites/views/screens/seller_password_reset_screen.dart';
import 'package:minibites/views/screens/seller_sign_up_screen.dart';
import 'package:minibites/views/screens/seller_dashboard/seller_dashboard.dart';

class NotificationService {
  void getDeviceToken(String uid) async {
    // FirebaseMessaging instance ko istemal karte hain sirf device token hasil karne ke liye
    String? deviceToken = await FirebaseMessaging.instance.getToken();
    if (deviceToken != null) {
      print("Device Token: $deviceToken");
      // Is token ko apne backend ya Firestore mein save karein
      await saveDeviceTokenToFirestore(uid, deviceToken);
    } else {
      print("Device Token could not be retrieved.");
    }
  }

  Future<void> saveDeviceTokenToFirestore(String uid, String deviceToken) async {
    DocumentReference sellerDocRef = FirebaseFirestore.instance.collection('sellers').doc(uid);

    // Check if the document exists
    DocumentSnapshot sellerDoc = await sellerDocRef.get();

    if (sellerDoc.exists) {
      // Document exists, update the deviceToken
      await sellerDocRef.update({
        'deviceToken': deviceToken,
      });
    } else {
      // Document does not exist, create it with the deviceToken
      await sellerDocRef.set({
        'deviceToken': deviceToken,
        // Add other seller information if available
      }).catchError((e) {
        print("Error saving device token: $e");
      });
    }
  }
}

class SellerLoginScreen extends StatefulWidget {
  @override
  _SellerLoginScreenState createState() => _SellerLoginScreenState();
}

class _SellerLoginScreenState extends State<SellerLoginScreen> {
  final UserController userController = Get.put(UserController());
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  bool _obscurePassword = true;
  final NotificationService _notificationService = NotificationService(); // Notification service instance

  @override
  void initState() {
    super.initState();
  }

  Future<void> login(String email, String password) async {
    try {
      UserCredential userCredential = await FirebaseAuth.instance.signInWithEmailAndPassword(
        email: email,
        password: password,
      );

      User? user = userCredential.user;
      if (user == null) {
        Get.snackbar('Error', 'Could not retrieve user credentials');
        return;
      }

      // Device token hasil karne aur Firestore mein save karne ka function call karein
      _notificationService.getDeviceToken(user.uid);

      try {
        DocumentSnapshot userDoc = await _firestore.collection('sellers').doc(user.uid).get();
        if (userDoc.exists) {
          var sellerData = userDoc.data() as Map<String, dynamic>?;

          if (sellerData == null) {
            Get.snackbar('Error', 'Seller data is missing');
            return;
          }
          String sellerId = user.uid;

          // Navigate to Seller Dashboard
          Get.offAll(() => SellerDashboard(), arguments: {'sellerId': sellerId, ...sellerData});
        } else {
          Get.snackbar('Error', 'Seller not found in Firestore');
        }
      } catch (e) {
        Get.snackbar('Firestore Error', 'Failed to fetch seller data');
      }
    } on FirebaseAuthException catch (e) {
      Get.snackbar('Login Error', e.message ?? 'An unknown error occurred');
    }
  }

  void _togglePasswordVisibility() {
    setState(() {
      _obscurePassword = !_obscurePassword;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Login'),
        backgroundColor: Colors.amber,
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: SingleChildScrollView(
            child: Form(
              key: _formKey,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  SizedBox(height: 15),
                  Text(
                    'Login',
                    style: TextStyle(
                      fontSize: 25.0,
                      fontFamily: 'Horizon',
                    ),
                    textAlign: TextAlign.center,
                  ),
                  SizedBox(height: 20),
                  TextFormField(
                    onChanged: (value) => userController.email.value = value,
                    decoration: InputDecoration(
                      labelText: 'Enter Your Email',
                      prefixIcon: Icon(Icons.email),
                    ),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please enter your email';
                      }
                      return null;
                    },
                  ),
                  TextFormField(
                    onChanged: (value) => userController.password.value = value,
                    obscureText: _obscurePassword,
                    decoration: InputDecoration(
                      labelText: 'Enter Your Password',
                      prefixIcon: Icon(Icons.lock),
                      suffixIcon: IconButton(
                        icon: Icon(
                          _obscurePassword ? Icons.visibility_off : Icons.visibility,
                        ),
                        onPressed: _togglePasswordVisibility,
                      ),
                    ),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please enter your password';
                      }
                      return null;
                    },
                  ),
                  TextButton(
                    onPressed: () {
                      Get.to(() => SellerPasswordResetScreen());
                    },
                    child: Container(
                      alignment: Alignment.centerRight,
                      child: Text(
                        'Forgot Password?',
                        style: TextStyle(color: Colors.black, fontSize: 17),
                      ),
                    ),
                  ),
                  SizedBox(height: 20),
                  ElevatedButton(
                    onPressed: () {
                      if (_formKey.currentState?.validate() ?? false) {
                        login(userController.email.value, userController.password.value);
                      }
                    },
                    child: Text('Login'),
                    style: ElevatedButton.styleFrom(
                      padding: EdgeInsets.symmetric(vertical: 10, horizontal: 100),
                      foregroundColor: Colors.black,
                      backgroundColor: Colors.amber,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.all(Radius.circular(10)),
                      ),
                    ),
                  ),
                  TextButton(
                    onPressed: () {
                      Get.to(() => SellerSignUpScreen());
                    },
                    child: Text(
                      'Don\'t have an account? Sign Up',
                      style: TextStyle(color: Colors.black, fontSize: 17),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
