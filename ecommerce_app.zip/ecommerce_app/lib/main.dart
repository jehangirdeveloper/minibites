import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:get/get.dart';
import 'package:minibites/controllers/authcontroller.dart';
import 'package:minibites/controllers/buyer_dashboard_pages_controller/Cart_Controller.dart';
import 'package:minibites/controllers/buyer_dashboard_pages_controller/Crafted%20Cuisine_all_type_foods_controller/Crafted%20Cuisine_all_type_foods_menu_controller/bbq_page_menu_controller.dart';
import 'package:minibites/controllers/buyer_dashboard_pages_controller/Crafted%20Cuisine_all_type_foods_controller/Crafted%20Cuisine_all_type_foods_menu_controller/biryani_page_menu_controller.dart';
import 'package:minibites/controllers/buyer_dashboard_pages_controller/Crafted%20Cuisine_all_type_foods_controller/Crafted%20Cuisine_all_type_foods_menu_controller/burgers_page_menu_controller.dart';
import 'package:minibites/controllers/buyer_dashboard_pages_controller/Crafted%20Cuisine_all_type_foods_controller/Crafted%20Cuisine_all_type_foods_menu_controller/chinese_page_menu_controller.dart';
import 'package:minibites/controllers/buyer_dashboard_pages_controller/Crafted%20Cuisine_all_type_foods_controller/Crafted%20Cuisine_all_type_foods_menu_controller/desserts_page_menu_controller.dart';
import 'package:minibites/controllers/buyer_dashboard_pages_controller/Crafted%20Cuisine_all_type_foods_controller/Crafted%20Cuisine_all_type_foods_menu_controller/fast_food_menu_controller.dart';
import 'package:minibites/controllers/buyer_dashboard_pages_controller/Crafted%20Cuisine_all_type_foods_controller/Crafted%20Cuisine_all_type_foods_menu_controller/fish_page_menu_controller.dart';
import 'package:minibites/controllers/buyer_dashboard_pages_controller/Crafted%20Cuisine_all_type_foods_controller/Crafted%20Cuisine_all_type_foods_menu_controller/icecream_page_menu_controller.dart';
import 'package:minibites/controllers/buyer_dashboard_pages_controller/Crafted%20Cuisine_all_type_foods_controller/Crafted%20Cuisine_all_type_foods_menu_controller/pakistani_page_menu_controller.dart';
import 'package:minibites/controllers/buyer_dashboard_pages_controller/Crafted%20Cuisine_all_type_foods_controller/Crafted%20Cuisine_all_type_foods_menu_controller/paratha_page_menu_controller.dart';
import 'package:minibites/controllers/buyer_dashboard_pages_controller/Crafted%20Cuisine_all_type_foods_controller/Crafted%20Cuisine_all_type_foods_menu_controller/pasta_page_menu_controller.dart';
import 'package:minibites/controllers/buyer_dashboard_pages_controller/Crafted%20Cuisine_all_type_foods_controller/Crafted%20Cuisine_all_type_foods_menu_controller/pizza_page_menu_controller.dart';
import 'package:minibites/controllers/buyer_dashboard_pages_controller/Crafted%20Cuisine_all_type_foods_controller/Crafted%20Cuisine_all_type_foods_menu_controller/pulao_page_menu_controller.dart';
import 'package:minibites/controllers/buyer_dashboard_pages_controller/Crafted%20Cuisine_all_type_foods_controller/Crafted%20Cuisine_all_type_foods_menu_controller/samosa_page_menu_controller.dart';
import 'package:minibites/controllers/buyer_dashboard_pages_controller/Crafted%20Cuisine_all_type_foods_controller/Crafted%20Cuisine_all_type_foods_menu_controller/shawarma_page_menu_controller.dart';
import 'package:minibites/controllers/buyer_dashboard_pages_controller/Crafted%20Cuisine_all_type_foods_controller/Crafted%20Cuisine_all_type_foods_menu_controller/sweetdish_page_menu_controller.dart';
import 'package:minibites/controllers/buyer_dashboard_pages_controller/OrderTrackingController.dart';
import 'package:minibites/controllers/buyer_verify_email_controller.dart';
import 'package:minibites/firebase_options.dart';
import 'package:minibites/routes/routes.dart';
import 'package:minibites/views/screens/admin_dashboard/restaurantlistpage.dart';
import 'package:minibites/views/screens/buyer_dashboard/Crafted%20Cuisine_all_type_foods_pages/Crafted%20Cuisine_all_type_foods_menu_pages/fast_food_menu_screen.dart';
import 'package:minibites/views/screens/buyer_dashboard/Crafted%20Cuisine_all_type_foods_pages/Crafted%20Cuisine_all_type_foods_menu_pages/pizza_page_menu_screen.dart';
import 'package:minibites/views/screens/buyer_dashboard/Crafted%20Cuisine_all_type_foods_pages/Crafted%20Cuisine_all_type_foods_menu_pages/pulao_menu_screen.dart';
import 'package:minibites/views/screens/buyer_dashboard/Crafted%20Cuisine_all_type_foods_pages/fast_food_page.dart';
import 'package:minibites/views/screens/buyer_dashboard/Crafted%20Cuisine_all_type_foods_pages/pizza_page.dart';
import 'package:minibites/views/screens/buyer_dashboard/Crafted%20Cuisine_all_type_foods_pages/pulao_page.dart';
import 'package:minibites/views/screens/buyer_dashboard/buyer_dashboard.dart';
import 'package:minibites/views/screens/buyer_dashboard/review_page.dart';
import 'package:minibites/views/screens/reviewform.dart';
import 'package:minibites/views/screens/seller_dashboard/seller_dashboard.dart';
import 'package:minibites/views/screens/seller_dashboard/seller_dashboard_add_your_menu_page.dart';
import 'package:minibites/views/screens/seller_dashboard/seller_dashboard_order_page.dart';
import 'package:minibites/views/screens/seller_multi_step_form_screen.dart';
import 'package:minibites/views/screens/seller_welcome_screen.dart';
import 'package:minibites/views/screens/splash_screen.dart';
import 'package:minibites/controllers/seller_dashboard_controller/seller_dashboard_change_language_page_controller.dart';
import 'package:minibites/views/screens/seller_dashboard/seller_dashboard_change_language_page.dart';

Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  print('A background message just showed up: ${message.messageId}');
  if (message.data['type'] == 'review') {
    // Logic to handle review notification in background
  }
}

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );

  // Initialize controllers
  Get.put(CartController());
  Get.put(OrderTrackingController());
  // Add other controllers if needed here

  FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);

  FirebaseMessaging messaging = FirebaseMessaging.instance;

  // Request permissions for iOS (optional for Android)
  NotificationSettings settings = await messaging.requestPermission();
  print('User granted permission: ${settings.authorizationStatus}');

  FirebaseMessaging.onMessage.listen((RemoteMessage message) {
    print('Message data: ${message.data}');

    if (message.notification != null) {
      print('Notification title: ${message.notification!.title}');
      print('Notification body: ${message.notification!.body}');
    }
  });

  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  final SellerDashboardChangeLanguagePageController languageController = Get.put(SellerDashboardChangeLanguagePageController());

  @override
  Widget build(BuildContext context) {
    return Obx(() {
      return GetMaterialApp(
        title: 'MiniBites',
        debugShowCheckedModeBanner: false,
        locale: languageController.selectedLocale.value,
        translations: AppTranslations(),
        supportedLocales: [
          Locale('en', ''),
          Locale('ur', ''),
        ],
        home: SplashScreen(),
        getPages: AppRoutes.appRoutes(),
      );
    });
  }
}

class AppTranslations extends Translations {
  @override
  Map<String, Map<String, String>> get keys => {
    'en': {
      'Change Language': 'Change Language',
      'English': 'English',
      'Urdu': 'Urdu',
    },
    'ur': {
      'Change Language': 'زبان تبدیل کریں',
      'English': 'انگریزی',
      'Urdu': 'اردو',
    },
  };
}
